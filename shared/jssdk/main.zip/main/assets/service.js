var service = (function() {
  "use strict";
  function isUnsafeProperty(key) {
    return key === "__proto__";
  }
  function isDeepKey(key) {
    switch (typeof key) {
      case "number":
      case "symbol": {
        return false;
      }
      case "string": {
        return key.includes(".") || key.includes("[") || key.includes("]");
      }
    }
  }
  function toKey(value) {
    if (typeof value === "string" || typeof value === "symbol") {
      return value;
    }
    if (Object.is(value?.valueOf?.(), -0)) {
      return "-0";
    }
    return String(value);
  }
  function toString(value) {
    if (value == null) {
      return "";
    }
    if (typeof value === "string") {
      return value;
    }
    if (Array.isArray(value)) {
      return value.map(toString).join(",");
    }
    const result = String(value);
    if (result === "0" && Object.is(Number(value), -0)) {
      return "-0";
    }
    return result;
  }
  function toPath(deepKey) {
    if (Array.isArray(deepKey)) {
      return deepKey.map(toKey);
    }
    if (typeof deepKey === "symbol") {
      return [deepKey];
    }
    deepKey = toString(deepKey);
    const result = [];
    const length = deepKey.length;
    if (length === 0) {
      return result;
    }
    let index2 = 0;
    let key = "";
    let quoteChar = "";
    let bracket = false;
    if (deepKey.charCodeAt(0) === 46) {
      result.push("");
      index2++;
    }
    while (index2 < length) {
      const char = deepKey[index2];
      if (quoteChar) {
        if (char === "\\" && index2 + 1 < length) {
          index2++;
          key += deepKey[index2];
        } else if (char === quoteChar) {
          quoteChar = "";
        } else {
          key += char;
        }
      } else if (bracket) {
        if (char === '"' || char === "'") {
          quoteChar = char;
        } else if (char === "]") {
          bracket = false;
          result.push(key);
          key = "";
        } else {
          key += char;
        }
      } else {
        if (char === "[") {
          bracket = true;
          if (key) {
            result.push(key);
            key = "";
          }
        } else if (char === ".") {
          if (key) {
            result.push(key);
            key = "";
          }
        } else {
          key += char;
        }
      }
      index2++;
    }
    if (key) {
      result.push(key);
    }
    return result;
  }
  function get$1(object, path, defaultValue) {
    if (object == null) {
      return defaultValue;
    }
    switch (typeof path) {
      case "string": {
        if (isUnsafeProperty(path)) {
          return defaultValue;
        }
        const result = object[path];
        if (result === void 0) {
          if (isDeepKey(path)) {
            return get$1(object, toPath(path), defaultValue);
          } else {
            return defaultValue;
          }
        }
        return result;
      }
      case "number":
      case "symbol": {
        if (typeof path === "number") {
          path = toKey(path);
        }
        const result = object[path];
        if (result === void 0) {
          return defaultValue;
        }
        return result;
      }
      default: {
        if (Array.isArray(path)) {
          return getWithPath(object, path, defaultValue);
        }
        if (Object.is(path?.valueOf(), -0)) {
          path = "-0";
        } else {
          path = String(path);
        }
        if (isUnsafeProperty(path)) {
          return defaultValue;
        }
        const result = object[path];
        if (result === void 0) {
          return defaultValue;
        }
        return result;
      }
    }
  }
  function getWithPath(object, path, defaultValue) {
    if (path.length === 0) {
      return defaultValue;
    }
    let current = object;
    for (let index2 = 0; index2 < path.length; index2++) {
      if (current == null) {
        return defaultValue;
      }
      if (isUnsafeProperty(path[index2])) {
        return defaultValue;
      }
      current = current[path[index2]];
    }
    if (current === void 0) {
      return defaultValue;
    }
    return current;
  }
  function isObject(value) {
    return value !== null && (typeof value === "object" || typeof value === "function");
  }
  function isEqualsSameValueZero(value, other) {
    return value === other || Number.isNaN(value) && Number.isNaN(other);
  }
  const IS_UNSIGNED_INTEGER = /^(?:0|[1-9]\d*)$/;
  function isIndex(value, length = Number.MAX_SAFE_INTEGER) {
    switch (typeof value) {
      case "number": {
        return Number.isInteger(value) && value >= 0 && value < length;
      }
      case "symbol": {
        return false;
      }
      case "string": {
        return IS_UNSIGNED_INTEGER.test(value);
      }
    }
  }
  function isSymbol(value) {
    return typeof value === "symbol" || value instanceof Symbol;
  }
  const regexIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
  const regexIsPlainProp = /^\w*$/;
  function isKey(value, object) {
    if (Array.isArray(value)) {
      return false;
    }
    if (typeof value === "number" || typeof value === "boolean" || value == null || isSymbol(value)) {
      return true;
    }
    return typeof value === "string" && (regexIsPlainProp.test(value) || !regexIsDeepProp.test(value)) || object != null && Object.hasOwn(object, value);
  }
  const assignValue = (object, key, value) => {
    const objValue = object[key];
    if (!(Object.hasOwn(object, key) && isEqualsSameValueZero(objValue, value)) || value === void 0 && !(key in object)) {
      object[key] = value;
    }
  };
  function updateWith(obj, path, updater, customizer) {
    if (obj == null && !isObject(obj)) {
      return obj;
    }
    let resolvedPath;
    if (isKey(path, obj)) {
      resolvedPath = [path];
    } else if (Array.isArray(path)) {
      resolvedPath = path;
    } else {
      resolvedPath = toPath(path);
    }
    const updateValue = updater(get$1(obj, resolvedPath));
    let current = obj;
    for (let i = 0; i < resolvedPath.length && current != null; i++) {
      const key = toKey(resolvedPath[i]);
      if (isUnsafeProperty(key)) {
        continue;
      }
      let newValue;
      if (i === resolvedPath.length - 1) {
        newValue = updateValue;
      } else {
        const objValue = current[key];
        const customizerResult = customizer?.(objValue, key, obj);
        newValue = customizerResult !== void 0 ? customizerResult : isObject(objValue) ? objValue : isIndex(resolvedPath[i + 1]) ? [] : {};
      }
      assignValue(current, key, newValue);
      current = current[key];
    }
    return obj;
  }
  function set$1(obj, path, value) {
    return updateWith(obj, path, () => value, () => void 0);
  }
  function isFunction(value) {
    return typeof value === "function";
  }
  function isString(value) {
    return typeof value === "string";
  }
  function isNil(value) {
    return value === null || value === void 0;
  }
  function get(data, path) {
    return get$1(data, path);
  }
  function set(data, path, value) {
    set$1(data, path, value);
  }
  function uuid() {
    return Math.random().toString(36).slice(2, 7);
  }
  const isWebWorker = (() => {
    if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) {
      return true;
    } else {
      return false;
    }
  })();
  function resolvePath(basePath, relativePath) {
    if (relativePath.startsWith("/")) {
      return relativePath.slice(1);
    }
    const currParts = basePath.split("/");
    const relativeParts = relativePath.split("/");
    for (const element of relativeParts) {
      const part = element;
      if (part === "..") {
        if (currParts.length > 0) {
          currParts.pop();
        }
      } else if (part !== "." && part !== "") {
        currParts.push(part);
      }
    }
    return currParts.join("/");
  }
  function parsePath(currPath, url) {
    const basePath = currPath.split("/").slice(0, -1).join("/");
    const parts = url.split("?");
    const pagePath = parts[0];
    const paramStr = parts[1];
    let newUrl = resolvePath(basePath, pagePath);
    if (paramStr) {
      newUrl += `?${paramStr}`;
    }
    return newUrl;
  }
  function suffixPixel(value) {
    const isNumber = typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value);
    return isNumber ? `${value}px` : value;
  }
  function cloneDeep(value) {
    if (value === null || typeof value !== "object") {
      return value;
    }
    const seen = /* @__PURE__ */ new WeakMap();
    function clone(item) {
      if (item === null || typeof item !== "object") {
        return item;
      }
      if (item instanceof Date) {
        return new Date(item);
      }
      if (item instanceof RegExp) {
        return new RegExp(item.source, item.flags);
      }
      if (Array.isArray(item)) {
        if (seen.has(item)) {
          return seen.get(item);
        }
        const arr = [];
        seen.set(item, arr);
        arr.push(...item.map(clone));
        return arr;
      }
      if (seen.has(item)) {
        return seen.get(item);
      }
      const obj = Object.create(Object.getPrototypeOf(item));
      seen.set(item, obj);
      return Object.assign(obj, ...Object.keys(item).map((key) => ({
        [key]: clone(item[key])
      })));
    }
    return clone(value);
  }
  const JSModules = {};
  const MODULES_STATUS_UNLOAD = 1;
  const MODULES_STATUS_LOADED = 2;
  function modDefine(id, factory) {
    if (!JSModules[id]) {
      JSModules[id] = {
        factory,
        status: MODULES_STATUS_UNLOAD,
        exports: void 0
      };
    }
  }
  function modRequire(id, callback2, errorCallback) {
    if (typeof id !== "string") {
      throw new TypeError("require args must be a string");
    }
    const mod = JSModules[id];
    if (!mod) {
      throw new Error(`module ${id} not found`);
    }
    if (mod.status === MODULES_STATUS_UNLOAD) {
      mod.status = MODULES_STATUS_LOADED;
      const module = {
        exports: {}
      };
      let res;
      try {
        if (mod.factory) {
          res = mod.factory.call(null, modRequire, module, module.exports);
        }
      } catch (e) {
        mod.status = MODULES_STATUS_UNLOAD;
        const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
        console.error(`require ${id} error: ${em}`);
        if (isFunction(errorCallback)) {
          errorCallback({ mod: id, errMsg: e.message });
        }
      }
      mod.exports = module.exports === void 0 ? res : module.exports;
    }
    if (isFunction(callback2)) {
      callback2(mod.exports);
    }
    return mod.exports;
  }
  modRequire.async = async (id) => {
    return new Promise((resolve, reject) => {
      try {
        resolve(modRequire(id));
      } catch (e) {
        reject(new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
      }
    });
  };
  class Callback {
    constructor() {
      this.callbacks = {};
    }
    store(callback2, keep) {
      if (keep) {
        for (const [k, v] of Object.entries(this.callbacks)) {
          if (v.callback === callback2) {
            return k;
          }
        }
      }
      const id = uuid();
      this.callbacks[id] = { callback: callback2, keep };
      return id;
    }
    /**
     * [Container] triggerCallback -> [Service] invoke
     * @param {*} id
     * @param {*} args
     */
    invoke(id, args) {
      if (id === void 0) {
        return;
      }
      const obj = this.callbacks[id];
      if (obj && isFunction(obj.callback)) {
        obj.callback(args);
        if (!obj.keep) {
          delete this.callbacks[id];
        }
      }
    }
    remove(id) {
      if (id) {
        Object.keys(this.callbacks).forEach((k) => {
          if (id === k) {
            delete this.callbacks[k];
          }
        });
      } else {
        Object.entries(this.callbacks).forEach(([k, v]) => {
          if (v.keep) {
            delete this.callbacks[k];
          }
        });
      }
    }
  }
  const callback = new Callback();
  function mitt(n) {
    return { all: n = n || /* @__PURE__ */ new Map(), on: function(t, e) {
      var i = n.get(t);
      i ? i.push(e) : n.set(t, [e]);
    }, off: function(t, e) {
      var i = n.get(t);
      i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
    }, emit: function(t, e) {
      var i = n.get(t);
      i && i.slice().map(function(n2) {
        n2(e);
      }), (i = n.get("*")) && i.slice().map(function(n2) {
        n2(t, e);
      });
    } };
  }
  class Message {
    constructor() {
      this.event = mitt();
      this.init();
    }
    init() {
      if (isWebWorker) {
        globalThis.onmessage = (e) => {
          this.handleMsg(e.data);
        };
      } else {
        DiminaServiceBridge.onMessage = this.handleMsg.bind(this);
      }
    }
    handleMsg(msg) {
      console.log("[service] receive msg: ", isWebWorker ? msg : JSON.stringify(msg));
      const { type, body } = msg;
      this.event.emit(type, body);
    }
    // 向逻辑层注册消息监听
    on(type, callback2) {
      this.event.on(type, callback2);
    }
    off(type) {
      this.event.off(type);
    }
    // 逻辑层透过容器层中转向渲染层发送消息
    send(msg) {
      if (isWebWorker) {
        Message.prototype.send = function(msg2) {
          msg2.method = "publish";
          globalThis.postMessage(msg2);
        };
      } else {
        Message.prototype.send = function(msg2) {
          return DiminaServiceBridge.publish(msg2.body.bridgeId || "", msg2);
        };
      }
      return this.send(msg);
    }
    // 逻辑层向容器层发送消息
    invoke(msg) {
      if (isWebWorker) {
        Message.prototype.invoke = function(msg2) {
          msg2.method = "invoke";
          globalThis.postMessage(msg2);
        };
      } else {
        Message.prototype.invoke = function(msg2) {
          return DiminaServiceBridge.invoke(msg2);
        };
      }
      return this.invoke(msg);
    }
  }
  const message = new Message();
  class Router {
    #stacks = [];
    #initId = "";
    setInitId(id) {
      this.#initId = id;
    }
    push(pageInfo, stackId) {
      this.stack(stackId).push(pageInfo);
    }
    pop() {
      if (this.stack().length > 0) {
        this.stack().pop();
      }
    }
    getPageInfo() {
      return this.stack().at(-1) || { id: this.#initId };
    }
    /**
     * 推入一个新页面栈
     */
    pushStack(stackId) {
      const newStack = {
        id: stackId,
        pages: []
      };
      this.#stacks.push(newStack);
      return newStack;
    }
    /**
     * 当前新页面栈退出
     */
    popStack(stackId) {
      if (stackId) {
        const index2 = this.#stacks.findIndex((stack) => stack.id === stackId);
        if (index2 !== -1) {
          this.#stacks.splice(index2, 1);
        }
      } else if (this.#stacks.length > 0) {
        this.#stacks.pop();
      }
    }
    /**
     * 获取当前页面栈
     */
    stack(stackId) {
      if (stackId) {
        let currentStack = this.#stacks.find((stack) => stack.id === stackId);
        if (!currentStack) {
          currentStack = this.pushStack(stackId);
        }
        return currentStack.pages;
      } else {
        const currentStack = this.#stacks.at(-1);
        if (currentStack) {
          return currentStack.pages;
        } else {
          return this.pushStack(Date.now()).pages;
        }
      }
    }
  }
  const router = new Router();
  function invokeAPI(name, data, target = "container") {
    let params;
    if (data === void 0 || typeof data === "string" || Array.isArray(data)) {
      params = data;
    } else {
      if (isFunction(data)) {
        params = {
          success: callback.store(data, true)
        };
      } else {
        const { success, fail, complete, keep, ...rest } = data;
        params = rest;
        if (isFunction(success)) {
          params.success = callback.store(success, keep);
        } else {
          params.success = success;
        }
        if (isFunction(fail)) {
          params.fail = callback.store(fail, keep);
        }
        if (isFunction(complete)) {
          params.complete = callback.store(complete, keep);
        }
      }
    }
    const msg = {
      type: "invokeAPI",
      target,
      body: {
        name,
        bridgeId: router.getPageInfo().id,
        params
      }
    };
    if (target === "container") {
      return message.invoke(msg);
    } else {
      return message.send(msg);
    }
  }
  function switchTab(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("switchTab", opts);
  }
  function reLaunch(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("reLaunch", opts);
  }
  function redirectTo(opts) {
    const url = parsePath(router.getPageInfo().route, opts.url);
    if (router.getPageInfo().route === url) {
      return;
    }
    opts.url = url;
    invokeAPI("redirectTo", opts);
  }
  function navigateTo(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("navigateTo", opts);
  }
  function navigateBack(opts) {
    invokeAPI("navigateBack", opts);
  }
  const __vite_glob_0_37 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    navigateBack,
    navigateTo,
    reLaunch,
    redirectTo,
    switchTab
  }, Symbol.toStringTag, { value: "Module" }));
  function onError(opts) {
    invokeAPI("onError", opts);
  }
  function offError(opts) {
    invokeAPI("offError", opts);
  }
  function onAppShow(opts) {
    invokeAPI("onAppShow", opts);
  }
  function onAppHide(opts) {
    invokeAPI("onAppHide", opts);
  }
  function offAppShow(opts) {
    invokeAPI("offAppShow", opts);
  }
  function offAppHide(opts) {
    invokeAPI("offAppHide", opts);
  }
  function onUnhandledRejection() {
  }
  function onPageNotFound() {
  }
  function onAppRoute() {
  }
  const __vite_glob_0_0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    offAppHide,
    offAppShow,
    offError,
    onAppHide,
    onAppRoute,
    onAppShow,
    onError,
    onPageNotFound,
    onUnhandledRejection
  }, Symbol.toStringTag, { value: "Module" }));
  function env$1() {
    return {
      USER_DATA_PATH: "difile://"
    };
  }
  const builtInAPIs = /* @__PURE__ */ new Set([
    "nextTick",
    "getUpdateManager",
    "getPerformance"
  ]);
  function canIUse(schema) {
    if (builtInAPIs.has(schema)) {
      return true;
    }
    try {
      return invokeAPI("canIUse", schema);
    } catch (error) {
      console.warn(`[canIUse] check ${schema} error:`, error);
      return false;
    }
  }
  const __vite_glob_0_1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    canIUse,
    env: env$1
  }, Symbol.toStringTag, { value: "Module" }));
  function getPerformance() {
    return Performance.getInstance();
  }
  class Performance {
    static #instance = null;
    // 私有构造函数，防止外部直接实例化
    constructor() {
      if (Performance.#instance) {
        throw new Error(
          "Cannot instantiate more than one Performance instance."
        );
      }
      this.entryList = new EntryList();
      Performance.#instance = this;
    }
    // 静态方法，用于获取单例实例
    static getInstance() {
      if (!Performance.#instance) {
        Performance.#instance = new Performance();
      }
      return Performance.#instance;
    }
    createObserver(listener) {
      const observer = new Observer(listener);
      if (listener) {
        const id = callback.store((res) => {
          const list = res?.data?.entryList && JSON.parse(res?.data?.entryList) || [];
          if (list) {
            this.entryList.push(list);
            observer.notify(list);
          }
        }, true);
        invokeAPI("addPerformanceObserver", {
          success: id
        }, "render");
      }
      return observer;
    }
    getEntries() {
      return this.entryList.getEntries();
    }
    getEntriesByName(name, entryType) {
      return this.entryList.getEntriesByName(name, entryType);
    }
    getEntriesByType(entryType) {
      return this.entryList.getEntriesByType(entryType);
    }
    setBufferSize(size) {
      this.entryList.maxEntrySize = size;
    }
  }
  class EntryList {
    constructor() {
      this._list = [];
      this.maxEntrySize = 30;
    }
    push(entries) {
      for (const entry of entries) {
        if (this._list.length >= this.maxEntrySize) {
          this._list.shift();
        }
        this._list.push(entry);
      }
    }
    getEntriesByName(name, entryType) {
      return this._entryFilter(name, entryType);
    }
    getEntriesByType(entryType) {
      return this._entryFilter(null, entryType);
    }
    _entryFilter(name, entryType) {
      return this._list.filter((entry) => {
        if (name && name !== entry.name) {
          return false;
        }
        if (entryType && entryType !== entry.entryType) {
          return false;
        }
        return true;
      });
    }
    getEntries() {
      return this._list;
    }
  }
  class Observer {
    constructor(callback2) {
      this.entryTypes = [];
      this.callback = callback2;
    }
    observe(options) {
      this.connected = true;
      this.entryTypes = options.entryTypes;
    }
    notify(data) {
      if (this.connected) {
        const entryList = new EntryList();
        entryList.push(data.filter((entry) => {
          let flag = false;
          if (this.entryTypes && this.entryTypes.length > 0) {
            this.entryTypes.forEach((value) => {
              if (entry.entryType === value) {
                flag = true;
              }
            });
          }
          return flag;
        }));
        this.callback(entryList);
      }
    }
    disconnect() {
      this.connected = false;
    }
  }
  const __vite_glob_0_2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getPerformance
  }, Symbol.toStringTag, { value: "Module" }));
  function preDownloadSubpackage(opts) {
    invokeAPI("preDownloadSubpackage", opts);
  }
  function loadSubpackage(opts) {
    invokeAPI("loadSubpackage", opts);
  }
  const __vite_glob_0_3 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    loadSubpackage,
    preDownloadSubpackage
  }, Symbol.toStringTag, { value: "Module" }));
  function openSystemBluetoothSetting(opts) {
    invokeAPI("openSystemBluetoothSetting", opts);
  }
  function getWindowInfo(opts) {
    return invokeAPI("getWindowInfo", opts);
  }
  function openAppAuthorizeSetting(opts) {
    invokeAPI("openAppAuthorizeSetting", opts);
  }
  function getSystemInfo(opts) {
    return new Promise((resolve) => {
      resolve(invokeAPI("getSystemInfo", opts));
    });
  }
  function getSystemInfoSync() {
    if (globalThis.injectInfo) {
      return globalThis.injectInfo.systemInfo;
    }
    return invokeAPI("getSystemInfoSync");
  }
  function getSystemInfoAsync(opts) {
    invokeAPI("getSystemInfoAsync", opts);
  }
  const __vite_glob_0_4 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getSystemInfo,
    getSystemInfoAsync,
    getSystemInfoSync,
    getWindowInfo,
    openAppAuthorizeSetting,
    openSystemBluetoothSetting
  }, Symbol.toStringTag, { value: "Module" }));
  function getUpdateManager() {
    return UpdateManager.getInstance();
  }
  class UpdateManager {
    // 私有静态变量，用于存储单例实例
    static #instance = null;
    // 私有构造函数，防止外部直接实例化
    constructor() {
      if (UpdateManager.#instance) {
        throw new Error(
          "Cannot instantiate more than one UpdateManager instance."
        );
      }
      this.hasApplyUpdate = false;
      this.updateFailFlag = null;
      this.updateFailCbQueue = [];
      this.updateReadyCbQueue = [];
      this.updateReadyStatus = null;
      this.updateReadyFlag = false;
      this.updateStatus = null;
      this.updateStatusCbQueue = [];
      message.on("onUpdateStatusChange", (msg) => {
        const { event, strategy } = msg;
        if (event === "updatefail") {
          this.updateFailFlag = {};
          this.flashUpdateFailCb();
        } else if (event === "updateready") {
          this.updateReadyFlag = true;
          this.updateReadyStatus = { strategy };
          this.flushUpdateReadyCb();
        } else if (event === "noupdate") {
          this.updateStatus = {
            hasUpdate: true
          };
          this.flushUpdateStatusCb();
        } else if (event === "updating") {
          this.updateStatus = {
            hasUpdate: false
          };
          this.flushUpdateStatusCb();
        }
      });
      UpdateManager.#instance = this;
    }
    flashUpdateFailCb() {
      this.updateFailCbQueue.forEach((cb) => {
        typeof cb === "function" && cb();
      });
      this.updateFailCbQueue.length = 0;
    }
    flushUpdateStatusCb() {
      this.updateStatusCbQueue.forEach((cb) => {
        typeof cb === "function" && cb(this.updateStatus);
      });
      this.updateStatusCbQueue.length = 0;
    }
    flushUpdateReadyCb() {
      this.updateReadyCbQueue.forEach((cb) => {
        typeof cb === "function" && cb(this.updateReadyStatus);
      });
      this.updateReadyCbQueue.length = 0;
    }
    // 静态方法，用于获取单例实例
    static getInstance() {
      if (!UpdateManager.#instance) {
        UpdateManager.#instance = new UpdateManager();
      }
      return UpdateManager.#instance;
    }
    /**
     * 强制小程序重启并使用新版本。在小程序新版本下载完成后（即收到 onUpdateReady 回调）调用。
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.applyUpdate.html
     */
    applyUpdate() {
      if (this.updateReadyFlag && this.hasApplyUpdate) {
        console.error("[applyUpdate]: applyUpdate has been called");
      } else if (!this.updateReadyFlag) {
        console.error("[applyUpdate]: update is not ready");
      } else {
        invokeAPI("applyUpdate");
      }
    }
    /**
     * 监听向微信后台请求检查更新结果事件。微信在小程序每次启动（包括热启动）时自动检查更新，不需由开发者主动触发。
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onCheckForUpdate.html
     */
    onCheckForUpdate(cb) {
      this.updateStatus ? typeof cb === "function" && cb(this.updateStatus) : this.updateStatusCbQueue.push(cb);
    }
    /**
     * 监听小程序更新失败事件。小程序有新版本，客户端主动触发下载（无需开发者触发），下载失败（可能是网络原因等）后回调
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateFailed.html
     */
    onUpdateFailed(cb) {
      this.updateFailFlag ? typeof cb === "function" && cb(this.updateFailFlag) : this.updateFailCbQueue.push(cb);
    }
    /**
     * 监听小程序有版本更新事件。客户端主动触发下载（无需开发者触发），下载成功后回调
     *	https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateReady.html
     */
    onUpdateReady(cb) {
      this.updateReadyFlag ? typeof cb === "function" && cb(this.updateReadyStatus) : this.updateReadyCbQueue.push(cb);
    }
  }
  const __vite_glob_0_5 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getUpdateManager
  }, Symbol.toStringTag, { value: "Module" }));
  function createCameraContext() {
    return new CameraContext();
  }
  class CameraContext {
    constructor() {
      this.bridgeId = router.getPageInfo().id;
    }
    takePhoto(data) {
      invokeAPI("takePhoto", data);
    }
    startRecord() {
      invokeAPI("startRecord");
    }
    stopRecord() {
      invokeAPI("stopRecord");
    }
  }
  const __vite_glob_0_6 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createCameraContext
  }, Symbol.toStringTag, { value: "Module" }));
  function reportAnalytics(...opts) {
    invokeAPI("reportAnalytics", opts);
  }
  function reportEvent(eventId, data) {
    invokeAPI("reportAnalytics", { eventId, data });
  }
  const __vite_glob_0_7 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    reportAnalytics,
    reportEvent
  }, Symbol.toStringTag, { value: "Module" }));
  function writeBLECharacteristicValue(opts) {
    invokeAPI("writeBLECharacteristicValue", opts);
  }
  function setBLEMTU(opts) {
    invokeAPI("setBLEMTU", opts);
  }
  function readBLECharacteristicValue(opts) {
    invokeAPI("readBLECharacteristicValue", opts);
  }
  function onBLEConnectionStateChange(opts) {
    invokeAPI("onBLEConnectionStateChange", opts);
  }
  function onBLECharacteristicValueChange(opts) {
    invokeAPI("onBLECharacteristicValueChange", opts);
  }
  function offBLEConnectionStateChange(opts) {
    invokeAPI("offBLEConnectionStateChange", opts);
  }
  function offBLECharacteristicValueChange() {
    invokeAPI("offBLECharacteristicValueChange");
  }
  function notifyBLECharacteristicValueChange(opts) {
    invokeAPI("notifyBLECharacteristicValueChange", opts);
  }
  function getBLEDeviceServices(opts) {
    invokeAPI("getBLEDeviceServices", opts);
  }
  function getBLEDeviceRSSI(opts) {
    invokeAPI("getBLEDeviceRSSI", opts);
  }
  function getBLEDeviceCharacteristics(opts) {
    invokeAPI("getBLEDeviceCharacteristics", opts);
  }
  function createBLEConnection(opts) {
    invokeAPI("createBLEConnection", opts);
  }
  function closeBLEConnection(opts) {
    invokeAPI("closeBLEConnection", opts);
  }
  const __vite_glob_0_8 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    closeBLEConnection,
    createBLEConnection,
    getBLEDeviceCharacteristics,
    getBLEDeviceRSSI,
    getBLEDeviceServices,
    notifyBLECharacteristicValueChange,
    offBLECharacteristicValueChange,
    offBLEConnectionStateChange,
    onBLECharacteristicValueChange,
    onBLEConnectionStateChange,
    readBLECharacteristicValue,
    setBLEMTU,
    writeBLECharacteristicValue
  }, Symbol.toStringTag, { value: "Module" }));
  function stopBluetoothDevicesDiscovery(opts) {
    invokeAPI("stopBluetoothDevicesDiscovery", opts);
  }
  function startBluetoothDevicesDiscovery(opts) {
    invokeAPI("startBluetoothDevicesDiscovery", opts);
  }
  function openBluetoothAdapter(opts) {
    invokeAPI("openBluetoothAdapter", opts);
  }
  function onBluetoothDeviceFound(opts) {
    invokeAPI("onBluetoothDeviceFound", opts);
  }
  function onBluetoothAdapterStateChange(opts) {
    invokeAPI("onBluetoothAdapterStateChange", opts);
  }
  function offBluetoothDeviceFound() {
    invokeAPI("offBluetoothDeviceFound");
  }
  function offBluetoothAdapterStateChange() {
    invokeAPI("offBluetoothAdapterStateChange");
  }
  function getConnectedBluetoothDevices(opts) {
    invokeAPI("getConnectedBluetoothDevices", opts);
  }
  function getBluetoothDevices(opts) {
    invokeAPI("getBluetoothDevices", opts);
  }
  function getBluetoothAdapterState(opts) {
    invokeAPI("getBluetoothAdapterState", opts);
  }
  function closeBluetoothAdapter(opts) {
    invokeAPI("closeBluetoothAdapter", opts);
  }
  const __vite_glob_0_9 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    closeBluetoothAdapter,
    getBluetoothAdapterState,
    getBluetoothDevices,
    getConnectedBluetoothDevices,
    offBluetoothAdapterStateChange,
    offBluetoothDeviceFound,
    onBluetoothAdapterStateChange,
    onBluetoothDeviceFound,
    openBluetoothAdapter,
    startBluetoothDevicesDiscovery,
    stopBluetoothDevicesDiscovery
  }, Symbol.toStringTag, { value: "Module" }));
  function setClipboardData(opts) {
    invokeAPI("setClipboardData", opts);
  }
  function getClipboardData(opts) {
    invokeAPI("getClipboardData", opts);
  }
  const __vite_glob_0_10 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getClipboardData,
    setClipboardData
  }, Symbol.toStringTag, { value: "Module" }));
  function chooseContact(opts) {
    invokeAPI("chooseContact", opts);
  }
  function addPhoneContact(opts) {
    invokeAPI("addPhoneContact", opts);
  }
  const __vite_glob_0_11 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    addPhoneContact,
    chooseContact
  }, Symbol.toStringTag, { value: "Module" }));
  function hideKeyboard(opts) {
    invokeAPI("hideKeyboard", opts);
  }
  const __vite_glob_0_12 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideKeyboard
  }, Symbol.toStringTag, { value: "Module" }));
  function onMemoryWarning(opts) {
    invokeAPI("onMemoryWarning", opts);
  }
  function offMemoryWarning(opts) {
    invokeAPI("offMemoryWarning", opts);
  }
  const __vite_glob_0_13 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    offMemoryWarning,
    onMemoryWarning
  }, Symbol.toStringTag, { value: "Module" }));
  function getNetworkType(opts) {
    invokeAPI("getNetworkType", opts);
  }
  const __vite_glob_0_14 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getNetworkType
  }, Symbol.toStringTag, { value: "Module" }));
  function makePhoneCall(opts) {
    invokeAPI("makePhoneCall", opts);
  }
  const __vite_glob_0_15 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    makePhoneCall
  }, Symbol.toStringTag, { value: "Module" }));
  function scanCode(opts) {
    invokeAPI("scanCode", opts);
  }
  const __vite_glob_0_16 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    scanCode
  }, Symbol.toStringTag, { value: "Module" }));
  function vibrateShort(opts) {
    invokeAPI("vibrateShort", opts);
  }
  function vibrateLong(opts) {
    invokeAPI("vibrateLong", opts);
  }
  const __vite_glob_0_17 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    vibrateLong,
    vibrateShort
  }, Symbol.toStringTag, { value: "Module" }));
  function extBridge({ event, module, data = {}, success, fail, complete }, extraCallback) {
    let overrideSuccess;
    let overrideFail;
    let overrideComplete;
    if (isFunction(extraCallback)) {
      overrideSuccess = extraCallback;
      overrideFail = extraCallback;
    } else {
      overrideSuccess = success;
      overrideFail = fail;
      overrideComplete = complete;
    }
    invokeAPI(event, {
      module,
      data,
      keep: data.isSustain ?? true,
      success: overrideSuccess,
      fail: overrideFail,
      complete: overrideComplete
    });
  }
  function extOnBridge({ event, module, callBack, isSustain = true }) {
    if (!module || module === "DMServiceBridgeModule") {
      console.error(`[ERROR]: extOnBridge 参数 module ${module ? `值${module}不合法` : "为空"}`);
      return;
    }
    if (!event) {
      console.error("[ERROR]: extOnBridge 参数 event 为空");
      return;
    }
    if (!callBack) {
      console.error("[ERROR]: extOnBridge 参数 callBack 为空");
      return;
    }
    const eventName = `${module}_${event}`;
    invokeAPI(eventName, {
      keep: isSustain,
      success: callBack
    });
  }
  function extOffBridge({ event, module, callBack }) {
    if (!module || module === "DMServiceBridgeModule") {
      console.error(`[ERROR]: extOffBridge 参数 module ${module ? `值${module}不合法` : "为空"}`);
      return;
    }
    if (!event) {
      console.error("[ERROR]: extOffBridge 参数 event 为空");
      return;
    }
    const eventName = `${module}_${event}`;
    invokeAPI(eventName, {
      success: callBack
    });
  }
  function onLoginStatusChanged(callback2) {
    message.on("notifyLoginStatusChanged", (msg) => {
      callback2?.(msg);
    });
  }
  function offLoginStatusChanged() {
    message.off("notifyLoginStatusChanged");
  }
  const __vite_glob_0_18 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    extBridge,
    extOffBridge,
    extOnBridge,
    offLoginStatusChanged,
    onLoginStatusChanged
  }, Symbol.toStringTag, { value: "Module" }));
  const lifecycleMethods = ["onLaunch", "onShow", "onHide"];
  class App {
    constructor(appModule, options) {
      this.appModule = appModule;
      this.options = options;
      this.init();
    }
    init() {
      this.initLifecycle();
      this.initCustomMethods();
      this.invokeSomeLifecycle();
    }
    initLifecycle() {
      lifecycleMethods.forEach((method) => {
        const lifecycleMethod = this.appModule.moduleInfo[method];
        if (!isFunction(lifecycleMethod)) {
          return;
        }
        this[method] = lifecycleMethod.bind(this);
      });
    }
    // 开发者自定义函数
    initCustomMethods() {
      const moduleInfo = this.appModule.moduleInfo;
      for (const attr in moduleInfo) {
        if (!lifecycleMethods.includes(attr) && isFunction(moduleInfo[attr])) {
          this[attr] = moduleInfo[attr].bind(this);
        }
      }
    }
    invokeSomeLifecycle() {
      this.onLaunch?.(this.options);
      this.onShow?.(this.options);
    }
    appShow() {
      this.onShow?.(this.options);
    }
    appHide() {
      this.onHide?.();
    }
  }
  function createSelectorQuery() {
    return new SelectorQuery();
  }
  class SelectorQuery {
    constructor() {
      this.__componentId = router.getPageInfo().id;
      this.__taskQueue = [];
      this.__cbQueue = [];
    }
    /**
     * 将选择器的选取范围更改为自定义组件 component 内。（初始时，选择器仅选取页面范围的节点，不会选取任何自定义组件中的节点）。
     * @param {Component} com
     * @returns {SelectorQuery} SelectorQuery
     */
    in(com) {
      this.__componentId = com.__id__;
      return this;
    }
    /**
     * 在当前页面下选择第一个匹配选择器 selector 的节点。返回一个 NodesRef 对象实例，可以用于获取节点信息。
     * @param {string} selector
     * @returns {NodesRef} NodesRef
     */
    select(selector) {
      return new NodesRef(this, this.__componentId, selector, true);
    }
    /**
     * 在当前页面下选择匹配选择器 selector 的所有节点。
     * @param {string} selector
     * @returns {NodesRef} NodesRef
     */
    selectAll(selector) {
      return new NodesRef(this, this.__componentId, selector, false);
    }
    /**
     * 选择显示区域。可用于获取显示区域的尺寸、滚动位置等信息。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.selectViewport.html
     * @returns {NodesRef} NodesRef
     */
    selectViewport() {
      return new NodesRef(this, router.getPageInfo().id, "", true);
    }
    /**
     *
     * @param {*} selector
     * @param {*} moduleId
     * @param {*} single
     * @param {*} fields
     * @param {*} callback
     */
    __push(selector, moduleId, single, fields, callback2) {
      this.__taskQueue.push({
        moduleId,
        selector,
        single,
        fields
      });
      this.__cbQueue.push(callback2);
    }
    /**
     * 执行所有的请求。请求结果按请求次序构成数组，在callback的第一个参数中返回。
     * @param {Function} callback
     */
    exec(callback2) {
      const self = this;
      const data = {
        tasks: this.__taskQueue,
        success: (res) => {
          res.forEach((nodeInfo, index2) => {
            const cb = self.__cbQueue[index2];
            if (isFunction(cb)) {
              cb.call(self, nodeInfo);
            }
          });
          if (isFunction(callback2)) {
            callback2.call(self, res);
          }
        }
      };
      invokeAPI("selectorQuery", data, "render");
    }
  }
  class NodesRef {
    constructor(selectorQuery, componentId, selector, single) {
      this.__selectorQuery = selectorQuery;
      this.__moduleId = componentId;
      this.__selector = selector;
      this.__single = single;
    }
    /**
     * 获取节点的相关信息。需要获取的字段在fields中指定。返回值是 nodesRef 对应的 selectorQuery
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.fields.html
     */
    fields(fields, callback2) {
      this.__selectorQuery.__push(this.__selector, this.__moduleId, this.__single, fields, callback2);
      return this.__selectorQuery;
    }
    /**
     * 添加节点的布局位置的查询请求。相对于显示区域，以像素为单位。其功能类似于 DOM 的 getBoundingClientRect。返回 NodesRef 对应的 SelectorQuery
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.boundingClientRect.html
     */
    boundingClientRect(callback2) {
      return this.fields(
        {
          id: true,
          dataset: true,
          rect: true,
          size: true
        },
        callback2
      );
    }
    /**
     * 添加节点的 Context 对象查询请求。
     * 目前支持 VideoContext、CanvasContext、LivePlayerContext、EditorContext和 MapContext 的获取。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.context.html
     */
    context(callback2) {
      return this.fields(
        {
          context: true
        },
        callback2
      );
    }
    /**
     * 获取 Node 节点实例
     * 目前支持 Canvas 和 ScrollViewContext 的获取。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.node.html
     */
    node(callback2) {
      return this.fields(
        {
          node: true
        },
        callback2
      );
    }
    /**
     * 添加节点的滚动位置查询请求。以像素为单位。节点必须是 scroll-view 或者 viewport，返回 NodesRef 对应的 SelectorQuery。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.scrollOffset.html
     */
    scrollOffset(callback2) {
      return this.fields(
        {
          id: true,
          dataset: true,
          scrollOffset: true
        },
        callback2
      );
    }
  }
  const __vite_glob_0_51 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createSelectorQuery
  }, Symbol.toStringTag, { value: "Module" }));
  function createIntersectionObserver(component, options = {}) {
    const {
      thresholds = [0],
      // 设定默认值 [0]
      initialRatio = 0,
      // 设定默认值 0
      observeAll = false
      // 设定默认值 false
    } = options;
    return new IntersectionObserver(component, { thresholds, initialRatio, observeAll });
  }
  class IntersectionObserver {
    constructor(component, options) {
      this._component = component;
      this._options = options;
      this._relativeInfo = [];
      this._observerId = null;
      this._disconnected = false;
    }
    /**
     * 使用选择器指定一个节点，作为参照区域之一
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeTo.html
     */
    relativeTo(selector, margins = { left: 0, right: 0, top: 0, bottom: 0 }) {
      if (this._observerId !== null) {
        throw new Error('Relative nodes cannot be added after "observe" call in IntersectionObserver');
      }
      this._relativeInfo.push({
        selector,
        margins: ["left", "right", "top", "bottom"].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
      });
      return this;
    }
    /**
     * 指定页面显示区域作为参照区域之一
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeToViewport.html
     */
    relativeToViewport(margins = { left: 0, right: 0, top: 0, bottom: 0 }) {
      if (this._observerId !== null) {
        throw new Error('Relative nodes cannot be added after "observe" call in IntersectionObserver');
      }
      this._relativeInfo.push({
        selector: null,
        margins: ["left", "right", "top", "bottom"].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
      });
      return this;
    }
    /**
     * 指定目标节点并开始监听相交状态变化情况
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.observe.html
     */
    observe(targetSelector, listener) {
      const self = this;
      const id = callback.store((res) => {
        if (!self._disconnected) {
          self._observerId = res.observerId;
        }
        if (res.info) {
          listener.call(self, res.info);
        }
      }, true);
      invokeAPI("addIntersectionObserver", {
        moduleId: this._component.__id__,
        targetSelector,
        relativeInfo: this._relativeInfo,
        options: this._options,
        success: id
      }, "render");
    }
    /**
     * 停止监听。回调函数将不再触发
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.disconnect.html
     */
    disconnect() {
      invokeAPI("removeIntersectionObserver", {
        observerId: this._observerId
      }, "render");
      this._disconnected = true;
    }
  }
  const __vite_glob_0_50 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createIntersectionObserver
  }, Symbol.toStringTag, { value: "Module" }));
  function addComputedData(self) {
    if (self.__mpxProxy?.options?.computed) {
      Object.keys(self.__mpxProxy.options.computed).forEach((ck) => {
        if (ck !== "_l" && ck !== "_fl") {
          if (!Object.hasOwn(self.data, ck)) {
            self.data[ck] = null;
          }
        }
      });
    }
  }
  function filterData(obj) {
    if (isNil(obj)) {
      return obj;
    }
    return Object.entries(obj).reduce((acc, [key, value]) => {
      if (key.startsWith("$") || key.startsWith("_l") || key.startsWith("_fl")) {
        return acc;
      } else if (isFunction(value)) {
        console.warn("[service] 值不支持函数引用", key);
        return acc;
      } else if (Array.isArray(value)) {
        acc[key] = value.map((item) => {
          if (typeof item === "object" && item !== null) {
            if (item instanceof Date) {
              return item.getTime();
            }
            return filterData(item);
          }
          return item;
        });
      } else if (value && typeof value === "object" && !Array.isArray(value)) {
        if (value instanceof Date) {
          acc[key] = value.getTime();
        } else {
          acc[key] = filterData(value);
        }
      } else {
        acc[key] = value;
      }
      return acc;
    }, {});
  }
  function serializeProps(properties) {
    if (properties) {
      const props = {};
      for (const key in properties) {
        const item = properties[key];
        props[key] = props[key] || {};
        const transType = item && typeof item === "object" && Object.hasOwn(item, "type") ? convertToStringType(item.type) : convertToStringType(item);
        let array = null;
        if (Array.isArray(transType)) {
          array = [...transType];
        } else {
          array = [transType];
        }
        if (item && item.optionalTypes) {
          const oTransType = convertToStringType(item.optionalTypes);
          if (Array.isArray(oTransType)) {
            array = [...oTransType];
          } else {
            array.push(oTransType);
          }
        }
        props[key].type = array;
        if (props[key].type.length > 0) {
          if (item && isFunction(item.value)) {
            props[key].default = item.value();
          } else if (item) {
            props[key].default = item.value;
          }
        }
      }
      return props;
    }
  }
  const TYPE_TO_STRING_MAP = /* @__PURE__ */ new Map([
    [String, "s"],
    [Number, "n"],
    [Boolean, "b"],
    [Object, "o"],
    [Array, "a"],
    [Function, "f"]
  ]);
  function convertToStringType(type) {
    if (Array.isArray(type)) {
      return type.map((item) => convertToStringType(item));
    } else {
      if (type === null || type === "") {
        return null;
      }
      const stringType = TYPE_TO_STRING_MAP.get(type);
      if (stringType) {
        return stringType;
      }
      console.warn(`[service] ignore unknown props type ${type}`);
      return null;
    }
  }
  function filterInvokeObserver(changedKey, observers, data, ctx, oldVal) {
    for (const observerKey in observers) {
      const observerFn = observers[observerKey];
      const keys = observerKey.split(",").map((k) => k.trim());
      if (keys.includes(changedKey)) {
        const args = keys.map((key) => get(data, key));
        if (keys.length === 1 && keys[0] === changedKey) {
          observerFn.call(ctx, ...args, oldVal);
        } else {
          observerFn.call(ctx, ...args);
        }
        continue;
      }
      if (observerKey === "**") {
        observerFn.call(ctx, data);
        continue;
      }
      const observerKeyParts = observerKey.split(".");
      const changedKeyParts = changedKey.split(".");
      let matched = true;
      for (let i = 0; i < observerKeyParts.length; i++) {
        if (observerKeyParts[i] === "**" || changedKeyParts[i] === void 0) {
          break;
        } else if (observerKeyParts[i] !== changedKeyParts[i]) {
          matched = false;
          break;
        }
      }
      if (matched) {
        let targetData = data;
        for (const part of observerKeyParts) {
          if (part !== "**") {
            targetData = targetData[part];
          }
        }
        if (observerKey === changedKey) {
          observerFn.call(ctx, targetData, oldVal);
        } else {
          observerFn.call(ctx, targetData);
        }
        continue;
      }
      const arrayMatch = observerKey.match(/^(.+)\[(\d+)\]$/);
      if (arrayMatch) {
        const arrayKey = arrayMatch[1];
        const index2 = Number.parseInt(arrayMatch[2], 10);
        if (arrayKey === changedKey.split("[")[0] && data[arrayKey] && data[arrayKey][index2] !== void 0) {
          observerFn.call(ctx, data[arrayKey][index2]);
          continue;
        }
      }
      if (changedKey.startsWith(observerKey)) {
        const targetData = observerKey.split(".").reduce((acc, key) => acc && acc[key], data);
        if (targetData !== void 0) {
          observerFn.call(ctx, targetData);
          continue;
        }
      }
    }
  }
  function mergeBehaviors(obj, behaviors) {
    if (!Array.isArray(behaviors)) {
      return;
    }
    const processedBehaviors = /* @__PURE__ */ new WeakMap();
    function deepMergeData(target, source) {
      const result = { ...target };
      for (const key in source) {
        if (Object.hasOwn(source, key)) {
          const targetValue = result[key];
          const sourceValue = source[key];
          if (targetValue && typeof targetValue === "object" && !Array.isArray(targetValue) && sourceValue && typeof sourceValue === "object" && !Array.isArray(sourceValue)) {
            result[key] = deepMergeData(targetValue, sourceValue);
          } else {
            result[key] = sourceValue;
          }
        }
      }
      return result;
    }
    function merge(target, behavior) {
      if (typeof behavior === "string") {
        handleBuiltinBehavior(target, behavior);
        return;
      }
      if (!behavior || typeof behavior !== "object") {
        return;
      }
      if (processedBehaviors.has(behavior)) {
        return;
      }
      processedBehaviors.set(behavior, true);
      if (Array.isArray(behavior.behaviors)) {
        behavior.behaviors.forEach((b) => merge(target, b));
      }
      if (behavior.properties) {
        target.properties = { ...behavior.properties, ...target.properties };
      }
      if (behavior.data) {
        if (!target.data) {
          target.data = {};
        }
        target.data = deepMergeData(behavior.data, target.data);
      }
      const lifetimes = ["created", "attached", "ready", "detached"];
      target.behaviorLifetimes = target.behaviorLifetimes || {};
      for (const lifetime of lifetimes) {
        if (isFunction(behavior[lifetime])) {
          target.behaviorLifetimes[lifetime] = target.behaviorLifetimes[lifetime] || [];
          target.behaviorLifetimes[lifetime].push(behavior[lifetime]);
        }
      }
      if (behavior.observers) {
        target.behaviorObservers = target.behaviorObservers || {};
        for (const observerKey in behavior.observers) {
          if (!target.behaviorObservers[observerKey]) {
            target.behaviorObservers[observerKey] = [];
          }
          target.behaviorObservers[observerKey].push(behavior.observers[observerKey]);
        }
      }
      if (behavior.methods) {
        target.methods = { ...behavior.methods, ...target.methods };
      }
      if (behavior.relations) {
        target.relations = { ...target.relations, ...behavior.relations };
      }
      if (behavior.export) {
        target.export = behavior.export;
      }
      if (behavior.pageLifetimes) {
        target.behaviorPageLifetimes = target.behaviorPageLifetimes || {};
        const pageLifetimes2 = ["show", "hide", "resize"];
        for (const lifetime of pageLifetimes2) {
          if (isFunction(behavior.pageLifetimes[lifetime])) {
            target.behaviorPageLifetimes[lifetime] = target.behaviorPageLifetimes[lifetime] || [];
            target.behaviorPageLifetimes[lifetime].push(behavior.pageLifetimes[lifetime]);
          }
        }
      }
    }
    function handleBuiltinBehavior(target, behaviorName) {
      switch (behaviorName) {
        case "wx://component-export":
          break;
        case "wx://form-field":
          break;
        case "wx://form-field-button":
          break;
        default:
          console.warn(`[service] 未知的内置 behavior: ${behaviorName}`);
      }
    }
    behaviors.forEach((behavior) => merge(obj, behavior));
  }
  function isChildComponent(component, parentId, allComponents) {
    let parent = component;
    while (parent && parent.__parentId__) {
      if (parent.__parentId__ === parentId) {
        return true;
      }
      parent = allComponents.find((item) => item.__id__ === parent.__parentId__);
    }
    return false;
  }
  function matchComponent(selector, item) {
    if (!selector || !item) {
      return false;
    }
    if (selector.startsWith("#")) {
      const id = selector.slice(1);
      return item.id === id;
    }
    if (selector.startsWith(".")) {
      const className = selector.slice(1);
      return item.__targetInfo__?.class && item.__targetInfo__.class.split(" ").includes(className);
    }
    if (selector.startsWith("[") && selector.endsWith("]")) {
      const attrMatch = selector.slice(1, -1).match(/^(\w+)(?:=["']?([^"']*)["']?)?$/);
      if (attrMatch) {
        const [, attrName, attrValue] = attrMatch;
        const dataset = item.__targetInfo__?.dataset || {};
        if (attrValue === void 0) {
          return Object.hasOwn(dataset, attrName);
        }
        return dataset[attrName] === attrValue;
      }
      return false;
    }
    if (item.is) {
      const componentName = item.is.split("/").pop();
      return componentName === selector || item.is === selector;
    }
    return false;
  }
  function hasDependencyChanged(bindingInfo, changedData) {
    if (!bindingInfo || !Array.isArray(bindingInfo.dependencies)) {
      return false;
    }
    for (const dep of bindingInfo.dependencies) {
      if (dep in changedData) {
        return true;
      }
      for (const changedKey of Object.keys(changedData)) {
        if (changedKey.startsWith(dep + ".") || changedKey.startsWith(dep + "[")) {
          return true;
        }
        if (dep.startsWith(changedKey + ".") || dep.startsWith(changedKey + "[")) {
          return true;
        }
      }
    }
    return false;
  }
  function evaluateExpression(bindingInfo, parentData) {
    if (!bindingInfo || !bindingInfo.expression) {
      return void 0;
    }
    if (bindingInfo.isSimple) {
      return get(parentData, bindingInfo.expression);
    }
    try {
      const func = new Function("data", `with(data) { return ${bindingInfo.expression} }`);
      return func(parentData);
    } catch (error) {
      console.warn("[service] 计算表达式失败:", bindingInfo.expression, error);
      return void 0;
    }
  }
  function syncUpdateChildrenProps(parent, allInstances, changedData) {
    const children = Object.values(allInstances || {});
    for (const child of children) {
      if (!isChildComponent(child, parent.__id__, children) || child.__parentId__ !== parent.__id__) {
        continue;
      }
      const childProperties = child.__info__?.properties || {};
      const updateData = {};
      for (const propName in childProperties) {
        const bindingInfo = parent.__childPropsBindings__?.[child.__id__]?.[propName];
        if (!bindingInfo) {
          continue;
        }
        if (hasDependencyChanged(bindingInfo, changedData)) {
          const newValue = evaluateExpression(bindingInfo, parent.data);
          updateData[propName] = newValue;
        }
      }
      if (Object.keys(updateData).length > 0) {
        child.tO?.(updateData, false);
      }
    }
  }
  const componentLifetimes = ["created", "attached", "ready", "moved", "detached", "error"];
  const pageLifetimes = ["show", "hide", "resize", "routeDone"];
  class Component {
    constructor(module, opts) {
      this.initd = false;
      this.opts = opts;
      if (opts.targetInfo) {
        this.id = opts.targetInfo.id;
        this.dataset = opts.targetInfo.dataset;
        this.__targetInfo__ = opts.targetInfo;
      }
      this.is = opts.path;
      this.route = opts.path;
      this.query = opts.query;
      this.renderer = "webview";
      this.bridgeId = opts.bridgeId;
      if (!this.id) {
        this.id = opts.bridgeId;
      }
      this.behaviors = module.behaviors;
      this.data = cloneDeep(module.noReferenceData);
      Object.defineProperty(this, "properties", {
        get() {
          return this.data;
        },
        enumerable: true,
        configurable: false
      });
      this.__isComponent__ = module.isComponent;
      this.__type__ = module.type;
      this.__id__ = this.opts.moduleId;
      this.__info__ = module.moduleInfo;
      this.__eventAttr__ = opts.eventAttr;
      this.__pageId__ = opts.pageId;
      this.__parentId__ = opts.parentId;
      this.__relations__ = /* @__PURE__ */ new Map();
      this.__relationPaths__ = /* @__PURE__ */ new Map();
      this.__groupSetDataMode__ = false;
      this.__groupSetDataBuffer__ = {};
      this.__childPropsBindings__ = {};
    }
    init() {
      if (this.__isComponent__) {
        for (const key in this.__info__.properties) {
          if (!Object.hasOwn(this.opts.properties, key) || this.opts.properties[key] === void 0) {
            this.data[key] = this.__info__.properties[key]?.value ?? null;
          } else {
            this.data[key] = this.opts.properties[key];
          }
        }
      }
      this.#initLifecycle();
      this.#initCustomMethods();
      this.#initRelations();
      this.#initComponentExport();
      this.#invokeInitLifecycle().then(() => {
        addComputedData(this);
        message.send({
          type: this.__id__,
          target: "render",
          body: {
            bridgeId: this.bridgeId,
            path: this.is,
            data: this.data
          }
        });
      });
    }
    /**
     * 初始化组件导出功能
     * 处理 wx://component-export behavior
     */
    #initComponentExport() {
      if (this.hasBehavior("wx://component-export")) {
        if (this.__info__.export && isFunction(this.__info__.export)) {
          this.export = this.__info__.export.bind(this);
        }
      }
    }
    /**
     * 初始化组件间关系
     */
    #initRelations() {
      const relations = this.__info__.relations;
      if (!relations || typeof relations !== "object") {
        return;
      }
      for (const [relationPath] of Object.entries(relations)) {
        const resolvedPath = this.#resolveRelationPath(relationPath);
        this.__relationPaths__.set(relationPath, resolvedPath);
        if (!this.__relations__.has(relationPath)) {
          this.__relations__.set(relationPath, []);
        }
      }
    }
    /**
     * 解析关系路径，将相对路径转换为绝对路径
     */
    #resolveRelationPath(relationPath) {
      if (relationPath.startsWith("./")) {
        const lastSlashIndex = this.is.lastIndexOf("/");
        if (lastSlashIndex === -1) {
          return relationPath.substring(2);
        }
        const currentDir = this.is.substring(0, lastSlashIndex);
        return `${currentDir}/${relationPath.substring(2)}`;
      } else if (relationPath.startsWith("../")) {
        const pathParts = this.is.split("/");
        const relationParts = relationPath.split("/");
        let currentParts = pathParts.slice(0, -1);
        for (const part of relationParts) {
          if (part === "..") {
            currentParts.pop();
          } else if (part !== ".") {
            currentParts.push(part);
          }
        }
        return currentParts.join("/");
      } else {
        return relationPath;
      }
    }
    /**
     * 检查组件关系并建立连接
     */
    #checkAndLinkRelations() {
      const relations = this.__info__.relations;
      if (!relations) return;
      const allInstances = Object.values(runtime.instances[this.bridgeId] || {});
      for (const [relationPath, relationConfig] of Object.entries(relations)) {
        const { type, target } = relationConfig;
        const resolvedPath = this.__relationPaths__.get(relationPath);
        const matchingComponents = allInstances.filter((instance) => {
          if (target) {
            return instance.hasBehavior && instance.hasBehavior(target);
          } else {
            return instance.is === resolvedPath || instance.is.endsWith(`/${resolvedPath}`);
          }
        });
        const relatedComponents = matchingComponents.filter((instance) => {
          return this.#checkRelationType(instance, type);
        });
        for (const relatedComponent of relatedComponents) {
          this.#linkRelation(relationPath, relatedComponent, relationConfig);
        }
      }
      this.#notifyOthersToCheckRelations();
    }
    /**
     * 通知其他组件重新检查关系
     */
    #notifyOthersToCheckRelations() {
      const allInstances = Object.values(runtime.instances[this.bridgeId] || {});
      for (const instance of allInstances) {
        if (instance !== this && instance._checkRelationsWithTarget) {
          instance._checkRelationsWithTarget(this);
        }
      }
    }
    /**
     * 检查与特定目标组件的关系
     */
    _checkRelationsWithTarget(targetInstance) {
      const relations = this.__info__.relations;
      if (!relations) return;
      for (const [relationPath, relationConfig] of Object.entries(relations)) {
        const { type, target } = relationConfig;
        const resolvedPath = this.__relationPaths__.get(relationPath);
        let matches = false;
        if (target) {
          matches = targetInstance.hasBehavior && targetInstance.hasBehavior(target);
        } else {
          matches = targetInstance.is === resolvedPath || targetInstance.is.endsWith(`/${resolvedPath}`);
        }
        if (matches && this.#checkRelationType(targetInstance, type)) {
          this.#linkRelation(relationPath, targetInstance, relationConfig);
        }
      }
    }
    /**
     * 检查关系类型是否匹配
     */
    #checkRelationType(targetInstance, relationType) {
      const allInstances = Object.values(runtime.instances[this.bridgeId] || {});
      switch (relationType) {
        case "parent":
          return targetInstance.__id__ === this.__parentId__;
        case "child":
          return targetInstance.__parentId__ === this.__id__;
        case "ancestor":
          return this.#isAncestor(targetInstance.__id__, this.__id__, allInstances);
        case "descendant":
          return this.#isAncestor(this.__id__, targetInstance.__id__, allInstances);
        default:
          return false;
      }
    }
    /**
     * 检查 ancestorId 是否是 descendantId 的祖先
     */
    #isAncestor(ancestorId, descendantId, allInstances) {
      let current = allInstances.find((instance) => instance.__id__ === descendantId);
      while (current && current.__parentId__) {
        if (current.__parentId__ === ancestorId) {
          return true;
        }
        current = allInstances.find((instance) => instance.__id__ === current.__parentId__);
      }
      return false;
    }
    /**
     * 建立关系连接
     */
    #linkRelation(relationPath, targetInstance, relationConfig) {
      const relationNodes = this.__relations__.get(relationPath) || [];
      if (relationNodes.includes(targetInstance)) {
        return;
      }
      relationNodes.push(targetInstance);
      this.__relations__.set(relationPath, relationNodes);
      if (isFunction(relationConfig.linked)) {
        try {
          relationConfig.linked.call(this, targetInstance);
        } catch (error) {
          console.error("[service] relation linked error:", error);
        }
      }
    }
    /**
     * 移除关系连接
     */
    #unlinkRelation(relationPath, targetInstance, relationConfig) {
      const relationNodes = this.__relations__.get(relationPath) || [];
      const index2 = relationNodes.indexOf(targetInstance);
      if (index2 === -1) {
        return;
      }
      relationNodes.splice(index2, 1);
      this.__relations__.set(relationPath, relationNodes);
      if (isFunction(relationConfig.unlinked)) {
        try {
          relationConfig.unlinked.call(this, targetInstance);
        } catch (error) {
          console.error("[service] relation unlinked error:", error);
        }
      }
    }
    /**
     * 处理关系变化
     */
    #handleRelationChange(relationPath, targetInstance, relationConfig) {
      if (isFunction(relationConfig.linkChanged)) {
        try {
          relationConfig.linkChanged.call(this, targetInstance);
        } catch (error) {
          console.error("[service] relation linkChanged error:", error);
        }
      }
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/performance/tips/runtime_setData.html
     * @param {*} data
     */
    setData(data) {
      const fData = filterData(data);
      for (const key in fData) {
        set(this.data, key, fData[key]);
      }
      if (!this.initd) {
        return;
      }
      if (this.__groupSetDataMode__) {
        for (const key in fData) {
          this.__groupSetDataBuffer__[key] = fData[key];
        }
        return;
      }
      syncUpdateChildrenProps(this, runtime.instances[this.bridgeId], fData);
      message.send({
        type: "u",
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          moduleId: this.__id__,
          data: fData
        }
      });
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
     */
    #initLifecycle() {
      componentLifetimes.forEach((method) => {
        const lifecycleMethod = this.__info__.lifetimes?.[method] || this.__info__[method];
        if (!isFunction(lifecycleMethod)) {
          return;
        }
        this[method] = lifecycleMethod.bind(this);
      });
      if (this.__isComponent__) {
        pageLifetimes.forEach((method) => {
          const lifecycleMethod = this.__info__.pageLifetimes?.[method];
          if (!isFunction(lifecycleMethod)) {
            return;
          }
          if (method === "show") {
            method = "onShow";
          } else if (method === "hide") {
            method = "onHide";
          }
          this[method] = lifecycleMethod.bind(this);
        });
      }
    }
    /**
     * 开发者自定义函数
     * Component 构造器的主要区别是：方法需要放在 methods: { } 里面
     */
    #initCustomMethods() {
      const methods = this.__info__.methods;
      for (const attr in methods) {
        if (isFunction(methods[attr])) {
          this[attr] = methods[attr].bind(this);
        }
      }
    }
    async #invokeInitLifecycle() {
      if (this.__isComponent__) {
        await this.componentCreated();
        await this.componentAttached();
      } else {
        await this.componentCreated();
        await this.componentAttached();
        await this.onLoad?.(this.opts.query || {});
      }
      this.initd = true;
    }
    /**
     * 触发观察者函数
     * triggerObserver
     */
    tO(data, triggerObservers = true) {
      const observersToExecute = [];
      for (const [prop, val] of Object.entries(data)) {
        const oldVal = this.data[prop];
        this.data[prop] = val;
        if (triggerObservers) {
          if (this.__info__.observers) {
            observersToExecute.push(() => filterInvokeObserver(prop, this.__info__.observers, data, this, oldVal));
          }
          const observer = this.__info__.properties?.[prop]?.observer;
          if (isString(observer)) {
            observersToExecute.push(() => this[observer]?.(val, oldVal));
          } else if (isFunction(observer)) {
            observersToExecute.push(() => observer.call(this, val, oldVal));
          }
        }
      }
      observersToExecute.forEach((fn) => fn());
    }
    getPageId() {
      return this.__id__;
    }
    /**
     * 检查组件是否具有 behavior （检查时会递归检查被直接或间接引入的所有behavior）
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
     */
    hasBehavior(behavior) {
      const _hasBehavior = function(behaviors) {
        if (!Array.isArray(behaviors)) {
          return false;
        }
        if (behaviors.includes(behavior)) {
          return true;
        }
        for (const b of behaviors) {
          if (b && b.behaviors && _hasBehavior(b.behaviors)) {
            return true;
          }
        }
        return false;
      };
      return _hasBehavior(this.behaviors);
    }
    /**
     * 创建一个 SelectorQuery 对象，选择器选取范围为这个组件实例内
     */
    createSelectorQuery() {
      return createSelectorQuery().in(this);
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
     * 使用选择器选取子组件实例对象，返回匹配到的第一个组件实例对象
     */
    selectComponent(selector) {
      const children = Object.values(runtime.instances[this.bridgeId]);
      const matchedComponent = children.find(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      );
      if (!matchedComponent) {
        return null;
      }
      if (matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) {
        return matchedComponent.export();
      }
      return matchedComponent;
    }
    /**
     * 使用选择器选取子组件实例对象，返回匹配到的全部组件实例对象组成的数组
     */
    selectAllComponents(selector) {
      const children = Object.values(runtime.instances[this.bridgeId]);
      return children.filter(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      );
    }
    /**
     * 选取当前组件节点所在的组件实例（即组件的引用者），返回它的组件实例对象
     */
    selectOwnerComponent() {
      const children = Object.values(runtime.instances[this.bridgeId]);
      for (const item of children) {
        if (item.id === this.__parentId__) {
          return item;
        }
      }
      return null;
    }
    /**
     * 创建一个 IntersectionObserver 对象，选择器选取范围为这个组件实例内
     * https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#createIntersectionObserver-Object-options
     */
    createIntersectionObserver(options) {
      return createIntersectionObserver(this, options);
    }
    /**
     * 立刻执行 callback，其中的多个 setData 之间不会触发界面绘制
     * （只有某些特殊场景中需要，如用于在不同组件同时 setData 时进行界面绘制同步）
     * https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#groupSetData-Function-callback
     * @param {Function} callback 回调函数，在此函数中进行的多个 setData 调用会被合并
     */
    groupSetData(callback2) {
      if (!isFunction(callback2)) {
        console.warn("[service] groupSetData callback must be a function");
        return;
      }
      this.__groupSetDataMode__ = true;
      this.__groupSetDataBuffer__ = {};
      try {
        callback2.call(this);
      } catch (error) {
        console.error("[service] groupSetData callback error:", error);
      } finally {
        this.__groupSetDataMode__ = false;
        if (this.__groupSetDataBuffer__ && Object.keys(this.__groupSetDataBuffer__).length > 0) {
          const bufferedData = this.__groupSetDataBuffer__;
          this.__groupSetDataBuffer__ = {};
          message.send({
            type: "u",
            target: "render",
            body: {
              bridgeId: this.bridgeId,
              moduleId: this.__id__,
              data: bufferedData
            }
          });
        }
      }
    }
    /**
     * TODO: 创建一个 MediaQueryObserver 对象
     */
    createMediaQueryObserver() {
      console.warn("[service] 暂不支持 createMediaQueryObserver");
    }
    /**
     * 获取这个关系所对应的所有关联节点
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/relations.html
     */
    getRelationNodes(relationPath) {
      if (!relationPath) {
        console.warn("[service] getRelationNodes 需要传入关系路径参数");
        return [];
      }
      const relationNodes = this.__relations__.get(relationPath) || [];
      return [...relationNodes];
    }
    /**
     * TODO: 执行关键帧动画
     */
    animate() {
      console.warn("[service] 暂不支持 animate");
    }
    /**
     * TODO: 清除关键帧动画
     */
    clearAnimation() {
      console.warn("[service] 暂不支持 clearAnimation");
    }
    /**
     * 触发组件所在页面的事件逻辑
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html
     * @param {*} methodName
     * @param {*} detail // detail对象，提供给事件监听函数
     * @param {*} options // 触发事件的选项
     */
    async triggerEvent(methodName, detail, options = {}) {
      const type = methodName.trim();
      await runtime.triggerEvent({
        bridgeId: this.bridgeId,
        moduleId: this.__pageId__,
        methodName: this.__eventAttr__[type],
        event: {
          type,
          detail,
          currentTarget: {
            id: this.id,
            dataset: this.dataset
          },
          target: {
            id: this.id,
            dataset: this.dataset
          }
        }
      });
      if (options.bubbles) {
        const parentInstance = runtime.instances[this.bridgeId][this.__parentId__];
        await parentInstance?.triggerEvent(methodName, detail);
      }
      if (options.composed) ;
      if (options.capturePhase) ;
    }
    pageReady() {
      if (!this.__isComponent__) {
        this.ready?.();
      }
    }
    /**
     * 页面退出时执行
     */
    pageUnload() {
      if (!this.__isComponent__) {
        this.onUnload?.();
      }
    }
    pageScrollTop(opts) {
      if (!this.__isComponent__) {
        const { scrollTop } = opts;
        this.onPageScroll?.({ scrollTop });
      }
    }
    // --- 组件所在页面的生命周期 ---
    /**
     * 组件所在的页面被展示时执行
     */
    pageShow() {
      this.onShow?.();
    }
    /**
     * 组件所在的页面被隐藏时执行
     */
    pageHide() {
      this.onHide?.();
    }
    /**
     * 组件所在的页面尺寸变化时执行
     * @param {object} size
     */
    pageResize(size) {
      this.resize?.(size);
    }
    // 组件所在页面路由动画完成时执行
    componentRouteDone() {
      this.routeDone?.();
    }
    // --- 组件的生命周期 ---
    /**
     * 在组件实例刚刚被创建时执行
     */
    async componentCreated() {
      this.__info__.behaviorLifetimes?.created?.forEach((method) => method.call(this));
      await this.created?.();
    }
    /**
     * 在组件实例进入页面节点树时执行
     */
    async componentAttached() {
      this.__info__.behaviorLifetimes?.attached?.forEach((method) => method.call(this));
      await this.attached?.();
      this.#checkAndLinkRelations();
    }
    /**
     * 在组件在视图层布局完成后执行
     */
    componentReadied() {
      this.__info__.behaviorLifetimes?.ready?.forEach((method) => method.call(this));
      this.ready?.();
    }
    /**
     * 在组件实例被移动到节点树另一个位置时执行
     */
    componentMoved() {
      this.moved?.();
      const relations = this.__info__.relations;
      if (relations) {
        for (const [relationPath, relationConfig] of Object.entries(relations)) {
          const relationNodes = this.__relations__.get(relationPath) || [];
          for (const node of relationNodes) {
            this.#handleRelationChange(relationPath, node, relationConfig);
          }
        }
      }
    }
    /**
     * 在组件实例被从页面节点树移除时执行
     */
    componentDetached() {
      const relations = this.__info__.relations;
      if (relations) {
        for (const [relationPath, relationConfig] of Object.entries(relations)) {
          const relationNodes = this.__relations__.get(relationPath) || [];
          const nodesToUnlink = [...relationNodes];
          for (const node of nodesToUnlink) {
            this.#unlinkRelation(relationPath, node, relationConfig);
          }
        }
      }
      this.#notifyOthersToUnlinkThis();
      this.__info__.behaviorLifetimes?.detached?.forEach((method) => method.call(this));
      this.detached?.();
      this.initd = false;
    }
    /**
     * 通知其他组件移除对当前组件的引用
     */
    #notifyOthersToUnlinkThis() {
      const allInstances = Object.values(runtime.instances[this.bridgeId] || {});
      for (const instance of allInstances) {
        if (instance === this || !instance.__relations__) continue;
        for (const [relationPath, relationNodes] of instance.__relations__.entries()) {
          const index2 = relationNodes.indexOf(this);
          if (index2 !== -1) {
            relationNodes.splice(index2, 1);
            instance.__relations__.set(relationPath, relationNodes);
            const relationConfig = instance.__info__.relations?.[relationPath];
            if (relationConfig && isFunction(relationConfig.unlinked)) {
              try {
                relationConfig.unlinked.call(instance, this);
              } catch (error) {
                console.error("[service] relation unlinked error:", error);
              }
            }
          }
        }
      }
    }
    /**
     * 每当组件方法抛出错误时执行
     * @param {*} error
     */
    componentError(error) {
      this.error?.(error);
    }
  }
  class ComponentModule {
    static type = "component";
    /**
     *
     * @param {{data: object, lifetimes: object, pageLifetimes: object, methods: object, options: object, properties: object}} moduleInfo
     */
    constructor(moduleInfo, extraInfo) {
      this.moduleInfo = moduleInfo;
      this.extraInfo = extraInfo;
      this.type = ComponentModule.type;
      this.isComponent = this.extraInfo.component;
      this.behaviors = this.moduleInfo.behaviors;
      this.usingComponents = this.extraInfo.usingComponents;
      mergeBehaviors(this.moduleInfo, this.behaviors);
      this.noReferenceData = filterData(this.moduleInfo.data || {});
    }
    getProps() {
      let props = serializeProps(this.moduleInfo.properties);
      if (Array.isArray(this.moduleInfo.externalClasses) && this.moduleInfo.externalClasses.length > 0) {
        if (!props) {
          props = {};
        }
        for (const externalClass of this.moduleInfo.externalClasses) {
          props[externalClass] = {
            type: ["s"],
            cls: true
          };
        }
      }
      return props;
    }
  }
  class Page {
    constructor(module, opts) {
      this.initd = false;
      this.opts = opts;
      this.is = opts.path;
      this.route = opts.path;
      this.bridgeId = opts.bridgeId;
      this.id = opts.bridgeId;
      this.query = opts.query;
      this.data = cloneDeep(module.noReferenceData);
      this.__type__ = module.type;
      this.__id__ = opts.moduleId;
      this.__info__ = module.moduleInfo;
      this.__childPropsBindings__ = {};
    }
    init() {
      this.#initMembers();
      this.#invokeInitLifecycle().then(() => {
        addComputedData(this);
        message.send({
          type: this.__id__,
          target: "render",
          body: {
            bridgeId: this.bridgeId,
            path: this.is,
            data: this.data
          }
        });
      });
    }
    setData(data) {
      const fData = filterData(data);
      for (const key in fData) {
        set(this.data, key, fData[key]);
      }
      if (!this.initd) {
        return;
      }
      syncUpdateChildrenProps(this, runtime.instances[this.bridgeId], fData);
      message.send({
        type: "u",
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          moduleId: this.__id__,
          data: fData
        }
      });
    }
    /**
     * 创建一个 SelectorQuery 对象，选择器选取范围为这个页面实例内
     */
    createSelectorQuery() {
      return createSelectorQuery().in(this);
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
     * 使用选择器选取页面中的组件实例对象，返回匹配到的第一个组件实例对象
     */
    selectComponent(selector) {
      const children = Object.values(runtime.instances[this.bridgeId] || {});
      const matchedComponent = children.find(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      );
      if (!matchedComponent) {
        return null;
      }
      if (matchedComponent.hasBehavior && matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) {
        return matchedComponent.export();
      }
      return matchedComponent;
    }
    /**
     * 使用选择器选取页面中的组件实例对象，返回匹配到的全部组件实例对象组成的数组
     */
    selectAllComponents(selector) {
      const children = Object.values(runtime.instances[this.bridgeId] || {});
      const matchedComponents = children.filter(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      );
      return matchedComponents.map((component) => {
        if (component.hasBehavior && component.hasBehavior("wx://component-export") && component.export) {
          return component.export();
        }
        return component;
      });
    }
    // 开发者自定义函数
    #initMembers() {
      for (const attr in this.__info__) {
        const member = this.__info__[attr];
        if (isFunction(member)) {
          this[attr] = member.bind(this);
        } else {
          this[attr] = member;
        }
      }
    }
    async #invokeInitLifecycle() {
      await this.onLoad?.(this.opts.query || {});
      this.initd = true;
    }
    /**
     * 页面显示/切入前台时触发。该时机不能保证页面渲染完成，如有页面/组件元素相关操作建议在 onReady 中处理
     */
    pageShow() {
      this.onShow?.();
    }
    pageHide() {
      this.onHide?.();
    }
    pageReady() {
      this.onReady?.();
    }
    pageUnload() {
      this.onUnload?.();
      this.initd = false;
    }
    pageScrollTop(opts) {
      const { scrollTop } = opts;
      this.onPageScroll?.({ scrollTop });
    }
  }
  class PageModule {
    static type = "page";
    constructor(moduleInfo, extraInfo) {
      this.moduleInfo = moduleInfo;
      this.extraInfo = extraInfo;
      this.type = PageModule.type;
      this.usingComponents = this.extraInfo.usingComponents;
      this.noReferenceData = filterData(this.moduleInfo.data || {});
    }
  }
  class AppModule {
    static type = "app";
    constructor(moduleInfo) {
      this.moduleInfo = moduleInfo;
    }
  }
  class Loader {
    constructor() {
      this.staticModules = {};
    }
    /**
     * [Container] loadResource -> [Service] loadResource
     * @param {*} opts
     */
    loadResource(opts) {
      const { appId, bridgeId, pagePath, root, baseUrl } = opts;
      if (isWebWorker) {
        this.isScriptLoaded = this.isScriptLoaded || {};
        if (!this.isScriptLoaded[root]) {
          const logicResourcePath = `${baseUrl}${appId}/${root}/logic.js`;
          globalThis.importScripts(logicResourcePath);
          this.isScriptLoaded[root] = true;
        }
      }
      router.setInitId(bridgeId);
      modRequire("app");
      modRequire(pagePath);
      message.invoke({
        type: "serviceResourceLoaded",
        target: "service",
        body: {
          bridgeId
        }
      });
    }
    /**
     * 创建逻辑层 App 映射实例
     * @param {*} moduleInfo
     */
    createAppModule(moduleInfo) {
      const appModule = new AppModule(moduleInfo);
      this.staticModules[AppModule.type] = appModule;
    }
    /**
     *创建逻辑层 Page/Component 映射实例
     * [Container]loadResource -> [Service]loadResource -> globalThis.Page/globalThis.Component -> create
     * @param {*} moduleInfo {{data: object, method: object}} 模块逻辑信息
     * @param {*} extraInfo {{path: string, component: boolean, usingComponents: object}} 模块额外信息
     * @param {*} type {{type: string}} type
     */
    createModule(moduleInfo, extraInfo, type) {
      const { path, usingComponents } = extraInfo;
      if (this.staticModules[path]) {
        return;
      }
      if (usingComponents) {
        for (const componentPath of Object.values(usingComponents)) {
          modRequire(componentPath);
        }
      }
      if (type === PageModule.type) {
        const pageModule = new PageModule(moduleInfo, extraInfo);
        this.staticModules[path] = pageModule;
      } else if (type === ComponentModule.type) {
        const componentModule = new ComponentModule(moduleInfo, extraInfo);
        this.staticModules[path] = componentModule;
      } else {
        console.error(`[service] createModule ${type} error`);
      }
    }
    getPropsByPath(usingComponents) {
      const res = {};
      this.getComponentProps(res, usingComponents);
      return res;
    }
    getComponentProps(res, usingComponents) {
      if (!usingComponents) {
        return;
      }
      for (const componentPath of Object.values(usingComponents)) {
        const component = this.staticModules[componentPath];
        if (!component || res[componentPath]) {
          continue;
        }
        res[componentPath] = component.getProps();
        this.getComponentProps(res, component.usingComponents);
      }
    }
    getAppModule() {
      return this.staticModules[AppModule.type];
    }
    getModuleByPath(path) {
      return this.staticModules[path];
    }
  }
  const loader = new Loader();
  class Runtime {
    constructor() {
      this.app = null;
      this.instances = {};
    }
    createApp(opts) {
      if (this.app) {
        console.log("[service] app instance already existed");
        return;
      }
      const { scene, pagePath: path, query } = opts;
      const appModule = loader.getAppModule();
      if (!appModule) {
        console.log("[service] app instance is not exist");
        return;
      }
      console.log("[service] create app instance");
      this.app = new App(appModule, {
        scene,
        path,
        query
      });
    }
    appShow() {
      this.app?.appShow();
    }
    appHide() {
      this.app?.appHide();
    }
    stackShow(stackId) {
      router.pushStack(stackId);
    }
    stackHide(stackId) {
      router.popStack(stackId);
    }
    /**
     * 渲染层创建映射实例
     * [Render]componentCreated -> [Container]createInstance ->[Service]createInstance
     * @param {*} opts
     */
    createInstance(opts) {
      const { bridgeId, moduleId, path, query, eventAttr, pageId, parentId, properties, targetInfo, stackId } = opts;
      const module = loader.getModuleByPath(path);
      if (!module) {
        console.error(`[service] ${path} not exist`);
        return;
      }
      console.log(`[service] create instance ${path}`);
      this.instances[bridgeId] = this.instances[bridgeId] || {};
      if (module.type === ComponentModule.type) {
        const component = new Component(module, {
          bridgeId,
          moduleId,
          path,
          query,
          eventAttr,
          pageId,
          parentId,
          properties,
          targetInfo
        });
        this.instances[bridgeId][moduleId] = component;
        if (!module.isComponent) {
          router.push(component, stackId);
        }
        component.init();
        return component;
      } else if (module.type === PageModule.type) {
        const page = new Page(module, {
          bridgeId,
          moduleId,
          path,
          query
        });
        this.instances[bridgeId][moduleId] = page;
        router.push(page, stackId);
        page.init();
        return page;
      } else {
        console.error(`[service] ${module.type} instance is not exist.`);
      }
    }
    moduleReady(opts) {
      const { bridgeId, moduleId, propBindings } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (propBindings && instance.__parentId__) {
        const parent = this.instances[bridgeId]?.[instance.__parentId__];
        if (parent) {
          if (!parent.__childPropsBindings__) {
            parent.__childPropsBindings__ = {};
          }
          parent.__childPropsBindings__[moduleId] = propBindings;
        }
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentReadied();
        instance.__componentReadied__ = true;
        const pageInstance = this.getPageInstance(bridgeId);
        if (pageInstance) {
          this.checkAndCallPageReady(bridgeId, pageInstance.__id__);
        }
      }
    }
    moduleUnmounted(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentDetached();
      }
      delete this.instances[bridgeId][moduleId];
    }
    pageShow(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      if (!instances) {
        return;
      }
      const pageInstances = [];
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === PageModule.type) {
          pageInstances.push(instance);
        } else if (instance.__type__ === ComponentModule.type) {
          if (!instance.__isComponent__) {
            pageInstances.push(instance);
          } else {
            instance.pageShow();
          }
        }
      });
      pageInstances.forEach((instance) => {
        instance.pageShow();
      });
    }
    pageReady(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      this.pageShow(opts);
      instance.__pageReadyPending__ = true;
      this.checkAndCallPageReady(bridgeId, moduleId);
    }
    /**
     * 检查并调用页面的 onReady
     * 确保所有组件的 ready 都已执行完毕
     */
    /**
     * 获取指定 bridgeId 下的页面实例
     */
    getPageInstance(bridgeId) {
      const instances = this.instances[bridgeId];
      if (!instances) {
        return null;
      }
      return Object.values(instances).find((instance) => {
        return instance && (instance.__type__ === PageModule.type || instance.__type__ === ComponentModule.type && !instance.__isComponent__);
      });
    }
    checkAndCallPageReady(bridgeId, moduleId) {
      const instance = this.instances[bridgeId][moduleId];
      if (!instance || !instance.__pageReadyPending__) {
        return;
      }
      const instances = this.instances[bridgeId];
      if (!instances) {
        instance.__pageReadyPending__ = false;
        instance.pageReady();
        return;
      }
      const pendingComponents = Object.values(instances).filter((componentInstance) => {
        return componentInstance && componentInstance.__type__ === ComponentModule.type && componentInstance.__isComponent__ && componentInstance.initd && !componentInstance.__componentReadied__;
      });
      if (pendingComponents.length === 0) {
        instance.__pageReadyPending__ = false;
        instance.pageReady();
      }
    }
    pageHide(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      const pageInstances = [];
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === PageModule.type) {
          pageInstances.push(instance);
        } else if (instance.__type__ === ComponentModule.type) {
          if (!instance.__isComponent__) {
            pageInstances.push(instance);
          } else {
            instance.pageHide();
          }
        }
      });
      pageInstances.forEach((instance) => {
        if (!instance) {
          return;
        }
        instance.pageHide();
      });
    }
    pageUnload(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      if (!instances) {
        return;
      }
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === ComponentModule.type) {
          instance.componentDetached();
        }
        instance.pageUnload();
      });
      router.pop();
      delete this.instances[bridgeId];
    }
    pageScroll(opts) {
      const { bridgeId, moduleId, scrollTop } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      instance.pageScrollTop({ scrollTop });
    }
    pageResize(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      instance.pageResize();
    }
    componentError(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentError();
      }
    }
    componentRouteDone(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentRouteDone();
      }
    }
    /**
     * 调用业务 js 方法
     * @param {*} opts
     */
    async triggerEvent(opts) {
      const { bridgeId, moduleId, methodName, event } = opts;
      if (methodName === void 0) {
        return;
      }
      const instances = this.instances[bridgeId];
      if (!instances) {
        console.warn(`[service] No instances found for bridgeId: ${bridgeId}`);
        return;
      }
      const instance = instances[moduleId];
      if (!instance) {
        console.warn(`[service] triggerEvent ${bridgeId} ${moduleId} ${methodName}, instance is not exist`);
        return;
      }
      if (isFunction(instance[methodName])) {
        return await instance[methodName](event);
      } else {
        console.warn(`[service] triggerEvent ${bridgeId} ${moduleId}, is: ${instance.is}, method: ${methodName} is not exist`);
      }
    }
  }
  const runtime = new Runtime();
  function getLaunchOptionsSync() {
    return runtime.app?.options;
  }
  function getEnterOptionsSync() {
    return runtime.app?.options;
  }
  const __vite_glob_0_19 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getEnterOptionsSync,
    getLaunchOptionsSync
  }, Symbol.toStringTag, { value: "Module" }));
  function getLocation(opts) {
    invokeAPI("getLocation", opts);
  }
  function startLocationUpdate(opts) {
    invokeAPI("startLocationUpdate", opts);
  }
  function openLocation(opts) {
    invokeAPI("openLocation", opts);
  }
  function stopLocationUpdate(opts) {
    invokeAPI("stopLocationUpdate", opts);
  }
  function onLocationChange(listener) {
    if (listener) {
      const id = callback.store(listener, true);
      invokeAPI("onLocationChange", {
        success: id
      });
    }
  }
  function offLocationChange(listener) {
    if (listener) {
      const id = callback.store(listener, true);
      invokeAPI("offLocationChange", {
        success: id
      });
      callback.remove(id);
    } else {
      invokeAPI("offLocationChange");
      callback.remove();
    }
  }
  const __vite_glob_0_20 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getLocation,
    offLocationChange,
    onLocationChange,
    openLocation,
    startLocationUpdate,
    stopLocationUpdate
  }, Symbol.toStringTag, { value: "Module" }));
  function createMapContext(mapId, obj) {
    return new MapContext({ mapId, obj });
  }
  class MapContext {
    constructor(opts) {
      this.opts = opts;
    }
    addMarkers(data) {
      invokeAPI("addMarkers", data);
    }
    removeMarkers(data) {
      invokeAPI("removeMarkers", data);
    }
    includePoints(data) {
      invokeAPI("includePoints", data);
    }
    setCenterOffset(data) {
      invokeAPI("setCenterOffset", data);
    }
    getCenterLocation(data) {
      invokeAPI("getCenterLocation", data);
    }
    getScale(data) {
      invokeAPI("getScale", data);
    }
    moveToLocation(data) {
      invokeAPI("moveToLocation", data);
    }
    translateMarker(data) {
      invokeAPI("translateMarker", data);
    }
    addArc(data) {
      invokeAPI("addArc", data);
    }
    removeArc(data) {
      invokeAPI("removeArc", data);
    }
  }
  const __vite_glob_0_21 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createMapContext
  }, Symbol.toStringTag, { value: "Module" }));
  function saveImageToPhotosAlbum(opts) {
    invokeAPI("saveImageToPhotosAlbum", opts);
  }
  function previewImage(opts) {
    invokeAPI("previewImage", opts);
  }
  function compressImage(opts) {
    invokeAPI("compressImage", opts);
  }
  function chooseImage(opts) {
    invokeAPI("chooseImage", opts);
  }
  const __vite_glob_0_22 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    chooseImage,
    compressImage,
    previewImage,
    saveImageToPhotosAlbum
  }, Symbol.toStringTag, { value: "Module" }));
  function chooseVideo(opts) {
    invokeAPI("chooseVideo", opts);
  }
  function chooseMedia(opts) {
    invokeAPI("chooseMedia", opts);
  }
  const __vite_glob_0_23 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    chooseMedia,
    chooseVideo
  }, Symbol.toStringTag, { value: "Module" }));
  function restartMiniProgram(opts) {
    invokeAPI("restartMiniProgram", opts);
  }
  function navigateToMiniProgram(opts) {
    invokeAPI("navigateToMiniProgram", opts);
  }
  function navigateBackMiniProgram(opts) {
    invokeAPI("navigateBackMiniProgram", opts);
  }
  function exitMiniProgram(opts) {
    invokeAPI("exitMiniProgram", opts);
  }
  const __vite_glob_0_24 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    exitMiniProgram,
    navigateBackMiniProgram,
    navigateToMiniProgram,
    restartMiniProgram
  }, Symbol.toStringTag, { value: "Module" }));
  function downloadFile(opts) {
    invokeAPI("downloadFile", opts);
  }
  const __vite_glob_0_25 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    downloadFile
  }, Symbol.toStringTag, { value: "Module" }));
  function request(opts) {
    invokeAPI("request", opts);
  }
  const __vite_glob_0_26 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    request
  }, Symbol.toStringTag, { value: "Module" }));
  function uploadFile(opts) {
    invokeAPI("uploadFile", opts);
  }
  const __vite_glob_0_27 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    uploadFile
  }, Symbol.toStringTag, { value: "Module" }));
  class SocketTask {
    constructor(socketId) {
      this.socketId = socketId;
      this._readyState = 0;
    }
    /**
     * 通过 WebSocket 连接发送数据
     * @param {Object} opts 
     */
    send(opts = {}) {
      const { data, success, fail, complete, ...rest } = opts;
      const params = {
        socketId: this.socketId,
        data,
        ...rest
      };
      if (isFunction(success)) {
        params.success = callback.store(success);
      }
      if (isFunction(fail)) {
        params.fail = callback.store(fail);
      }
      if (isFunction(complete)) {
        params.complete = callback.store(complete);
      }
      return invokeAPI("sendSocketMessage", params);
    }
    /**
     * 关闭 WebSocket 连接
     * @param {Object} opts 
     */
    close(opts = {}) {
      const { code = 1e3, reason = "", success, fail, complete, ...rest } = opts;
      const params = {
        socketId: this.socketId,
        code,
        reason,
        ...rest
      };
      if (isFunction(success)) {
        params.success = callback.store(success);
      }
      if (isFunction(fail)) {
        params.fail = callback.store(fail);
      }
      if (isFunction(complete)) {
        params.complete = callback.store(complete);
      }
      return invokeAPI("closeSocket", params);
    }
    /**
     * 监听 WebSocket 连接打开事件
     * @param {Function} callback 回调函数
     */
    onOpen(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("onSocketOpen", {
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 WebSocket 连接打开事件
     * @param {Function} callback 回调函数
     */
    offOpen(callbackFn) {
      return invokeAPI("offSocketOpen", {
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 WebSocket 接受到服务器的消息事件
     * @param {Function} callback 回调函数
     */
    onMessage(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("onSocketMessage", {
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 WebSocket 接受到服务器的消息事件
     * @param {Function} callback 回调函数
     */
    offMessage(callbackFn) {
      return invokeAPI("offSocketMessage", {
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 WebSocket 错误事件
     * @param {Function} callback 回调函数
     */
    onError(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("onSocketError", {
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 WebSocket 错误事件
     * @param {Function} callback 回调函数
     */
    offError(callbackFn) {
      return invokeAPI("offSocketError", {
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 WebSocket 连接关闭事件
     * @param {Function} callback 回调函数
     */
    onClose(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("onSocketClose", {
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 WebSocket 连接关闭事件
     * @param {Function} callback 回调函数
     */
    offClose(callbackFn) {
      return invokeAPI("offSocketClose", {
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 获取 WebSocket 连接状态
     * @returns {number} 连接状态
     */
    get readyState() {
      return this._readyState;
    }
    /**
     * WebSocket 的连接状态常量
     */
    static get CONNECTING() {
      return 0;
    }
    static get OPEN() {
      return 1;
    }
    static get CLOSING() {
      return 2;
    }
    static get CLOSED() {
      return 3;
    }
  }
  function connectSocket(opts = {}) {
    const {
      url,
      header = {},
      protocols = [],
      tcpNoDelay = false,
      perMessageDeflate = false,
      timeout,
      forceCellularNetwork = false,
      success,
      fail,
      complete,
      ...rest
    } = opts;
    if (!url) {
      const error = new Error("url is required");
      if (isFunction(fail)) {
        fail(error);
      }
      if (isFunction(complete)) {
        complete(error);
      }
      throw error;
    }
    const socketId = `socket_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const socketTask = new SocketTask(socketId);
    const params = {
      socketId,
      url,
      header,
      protocols,
      tcpNoDelay,
      perMessageDeflate,
      timeout,
      forceCellularNetwork,
      ...rest
    };
    if (isFunction(success)) {
      params.success = callback.store((res) => {
        socketTask._readyState = SocketTask.OPEN;
        success(res);
      });
    }
    if (isFunction(fail)) {
      params.fail = callback.store((error) => {
        socketTask._readyState = SocketTask.CLOSED;
        fail(error);
      });
    }
    if (isFunction(complete)) {
      params.complete = callback.store(complete);
    }
    invokeAPI("connectSocket", params);
    return socketTask;
  }
  function sendSocketMessage(opts) {
    return invokeAPI("sendSocketMessage", opts);
  }
  function closeSocket(opts) {
    return invokeAPI("closeSocket", opts);
  }
  function onSocketOpen(callbackFn) {
    return invokeAPI("onSocketOpen", { callback: callback.store(callbackFn, true) });
  }
  function onSocketMessage(callbackFn) {
    return invokeAPI("onSocketMessage", { callback: callback.store(callbackFn, true) });
  }
  function onSocketError(callbackFn) {
    return invokeAPI("onSocketError", { callback: callback.store(callbackFn, true) });
  }
  function onSocketClose(callbackFn) {
    return invokeAPI("onSocketClose", { callback: callback.store(callbackFn, true) });
  }
  const __vite_glob_0_28 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    closeSocket,
    connectSocket,
    onSocketClose,
    onSocketError,
    onSocketMessage,
    onSocketOpen,
    sendSocketMessage
  }, Symbol.toStringTag, { value: "Module" }));
  function getAccountInfoSync() {
    return invokeAPI("getAccountInfoSync");
  }
  const __vite_glob_0_29 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getAccountInfoSync
  }, Symbol.toStringTag, { value: "Module" }));
  function authorize(opts) {
    invokeAPI("authorize", opts);
  }
  const __vite_glob_0_30 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    authorize
  }, Symbol.toStringTag, { value: "Module" }));
  function login$1(opts) {
    invokeAPI("login", opts);
  }
  const __vite_glob_0_31 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    login: login$1
  }, Symbol.toStringTag, { value: "Module" }));
  function login(opts) {
    invokeAPI("login", opts);
  }
  const __vite_glob_0_32 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    login
  }, Symbol.toStringTag, { value: "Module" }));
  function getPrivacySetting(opts) {
    invokeAPI("getPrivacySetting", opts);
  }
  const __vite_glob_0_33 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getPrivacySetting
  }, Symbol.toStringTag, { value: "Module" }));
  function openSetting(opts) {
    invokeAPI("openSetting", opts);
  }
  function getSetting(opts) {
    invokeAPI("getSetting", opts);
  }
  const __vite_glob_0_34 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getSetting,
    openSetting
  }, Symbol.toStringTag, { value: "Module" }));
  function getUserInfo(opts) {
    invokeAPI("getUserInfo", opts);
  }
  const __vite_glob_0_35 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getUserInfo
  }, Symbol.toStringTag, { value: "Module" }));
  function requestPayment(opts) {
    invokeAPI("requestPayment", opts);
  }
  const __vite_glob_0_36 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    requestPayment
  }, Symbol.toStringTag, { value: "Module" }));
  function showShareMenu(opts) {
    invokeAPI("shareShareMenu", opts);
  }
  function showShareImageMenu(opts) {
    invokeAPI("showShareImageMenu", opts);
  }
  function hideShareMenu(opts) {
    invokeAPI("hideShareMenu", opts);
  }
  const __vite_glob_0_38 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideShareMenu,
    showShareImageMenu,
    showShareMenu
  }, Symbol.toStringTag, { value: "Module" }));
  function setStorageSync(...opts) {
    invokeAPI("setStorageSync", opts);
  }
  function getStorageSync(opts) {
    return invokeAPI("getStorageSync", opts);
  }
  function removeStorageSync(...opts) {
    return invokeAPI("removeStorageSync", opts);
  }
  function clearStorageSync() {
    invokeAPI("clearStorageSync");
  }
  function setStorage(opts) {
    invokeAPI("setStorage", opts);
  }
  function getStorage(opts) {
    invokeAPI("getStorage", opts);
  }
  function removeStorage(opts) {
    invokeAPI("removeStorage", opts);
  }
  function clearStorage() {
    invokeAPI("clearStorage");
  }
  function getStorageInfoSync(...opts) {
    return invokeAPI("getStorageInfoSync", opts);
  }
  function getStorageInfo(opts) {
    invokeAPI("getStorageInfo", opts);
  }
  const __vite_glob_0_39 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    clearStorage,
    clearStorageSync,
    getStorage,
    getStorageInfo,
    getStorageInfoSync,
    getStorageSync,
    removeStorage,
    removeStorageSync,
    setStorage,
    setStorageSync
  }, Symbol.toStringTag, { value: "Module" }));
  function base64ToArrayBuffer(base64Str) {
    const b64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const b64Table = new Array(256);
    for (let i2 = 0; i2 < b64Chars.length; i2++) {
      b64Table[b64Chars.charCodeAt(i2)] = i2;
    }
    base64Str = base64Str.replace(/\s+/g, "").replace(/=+$/, "");
    const len = base64Str.length;
    const byteLength = Math.floor(len * 3 / 4);
    const buffer = new ArrayBuffer(byteLength);
    const bytes = new Uint8Array(buffer);
    let i = 0;
    let j = 0;
    while (i < len) {
      const c1 = b64Table[base64Str.charCodeAt(i++)];
      const c2 = b64Table[base64Str.charCodeAt(i++)];
      const c3 = i < len ? b64Table[base64Str.charCodeAt(i++)] : 0;
      const c4 = i < len ? b64Table[base64Str.charCodeAt(i++)] : 0;
      const byte1 = c1 << 2 | c2 >> 4;
      const byte2 = (c2 & 15) << 4 | c3 >> 2;
      const byte3 = (c3 & 3) << 6 | c4;
      bytes[j++] = byte1;
      if (j < byteLength) bytes[j++] = byte2;
      if (j < byteLength) bytes[j++] = byte3;
    }
    return buffer;
  }
  function ArrayBufferToBase64(buffer) {
    const uint8Array = new Uint8Array(buffer);
    const b64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let result = "";
    let i = 0;
    const len = uint8Array.length;
    while (i < len) {
      const byte1 = uint8Array[i++] || 0;
      const byte2 = i < len ? uint8Array[i++] : 0;
      const byte3 = i < len ? uint8Array[i++] : 0;
      const enc1 = byte1 >> 2;
      const enc2 = (byte1 & 3) << 4 | byte2 >> 4;
      const enc3 = (byte2 & 15) << 2 | byte3 >> 6;
      const enc4 = byte3 & 63;
      result += b64Chars[enc1];
      result += b64Chars[enc2];
      result += i > len + 1 ? "=" : b64Chars[enc3];
      result += i > len ? "=" : b64Chars[enc4];
    }
    return result;
  }
  const UDP_CONSTANTS = {
    ERROR_CODES: {
      BIND_FAILED: 10001,
      SEND_FAILED: 10002,
      CLOSE_FAILED: 10003
    },
    // 状态常量
    UNBOUND: 0,
    BOUND: 1,
    CLOSING: 2,
    CLOSED: 3
  };
  class UDPSocket {
    constructor(ret) {
      this.mid = ret.mid;
      this.socketId = ret.socketId;
      this._readyState = 0;
    }
    /**
     * 绑定端口和地址（核心修复：原型方法 + 可序列化参数 + 回调处理）
     * @param {number} port 端口号（不传则随机）
     * @param {string} address 绑定地址，默认 0.0.0.0
     */
    bind(port, address = "0.0.0.0", opts = {}) {
      console.log(`【UDP UdpSocketApi】绑定端口: ${port || "随机端口"}，地址：${address}`);
      const params = {
        mid: this.mid,
        socketId: this.socketId,
        port,
        address
      };
      const ret = invokeAPI("udpsocket.bind", params);
      console.log(`【UDP UdpSocketApi】 返回参数:`, ret);
      if (ret.port) {
        this._readyState = UDP_CONSTANTS.BOUND;
      }
      return ret.port;
    }
    /**
     * 关闭 UDP Socket 连接
     * @param {Object} [opts] 扩展参数（success/fail/complete 回调）
     */
    close(opts = {}) {
      const { success, fail, complete } = opts;
      console.log(`【UDP UdpSocketApi】关闭 socket 实例：${this.socketId}`);
      const params = {
        socketId: this.socketId
      };
      if (isFunction(success)) {
        params.success = callback.store(() => {
          this._readyState = UDPSocket.CLOSED;
          success({ socketId: this.socketId });
        });
      }
      if (isFunction(fail)) {
        params.fail = callback.store(fail);
      }
      if (isFunction(complete)) {
        params.complete = callback.store(complete);
      }
      return invokeAPI("udpsocket.close", params);
    }
    /**
     * 连接到指定的 UDP 服务器（补全实现）
     * @param {Object} opts 配置（address/port + 回调）
     */
    connect(opts = {}) {
      const { address, port, success, fail, complete } = opts;
      const params = {
        mid: this.mid,
        socketId: this.socketId,
        address,
        port
      };
      if (isFunction(success)) params.success = callback.store(success);
      if (isFunction(fail)) params.fail = callback.store(fail);
      if (isFunction(complete)) params.complete = callback.store(complete);
      return invokeAPI("udpsocket.connect", params);
    }
    /**
     * 发送 UDP 消息（修复参数传递 + 回调处理）
     * @param {Object} options 配置（address/port/data + 回调）
     */
    send(options = {}) {
      const { address, port, message: message2, length, offset, setBroadcast } = options;
      console.log(`【UDP UdpSocketApi】发送消息到 ${address}:${port}，数据：`, message2);
      let isArrayBuffer = false;
      let messageArrayBuffer = null;
      if (typeof message2 === "string") {
        console.log("【UDP UdpSocketApi】发送 消息是字符串:", message2);
        isArrayBuffer = false;
      } else {
        console.log("【UDP UdpSocketApi】发送 消息是ArrayBuffer,长度为:", message2.byteLength);
        messageArrayBuffer = ArrayBufferToBase64(message2);
        isArrayBuffer = true;
        if (!length) {
          length = message2.byteLength;
        }
      }
      const params = {
        mid: this.mid,
        socketId: this.socketId,
        isArrayBuffer,
        length,
        //选填 长度
        offset,
        //偏移量，默认0
        setBroadcast,
        //是否广播发送，默认false
        address,
        //必填
        port,
        //必填
        message: isArrayBuffer ? messageArrayBuffer : message2
        //必填
      };
      const ret = invokeAPI("udpsocket.send", params);
      console.log(`【UDP UdpSocketApi】发送消息返回 :`, ret);
      return ret;
    }
    /**
     * 设置 TTL（补全实现）
     * @param {number} ttl TTL 值
     * @param {Object} [opts] 回调参数
     */
    setTTL(ttl, opts = {}) {
      const { success, fail, complete } = opts;
      const params = {
        mid: this.mid,
        socketId: this.socketId,
        ttl
      };
      if (isFunction(success)) params.success = callback.store(success);
      if (isFunction(fail)) params.fail = callback.store(fail);
      if (isFunction(complete)) params.complete = callback.store(complete);
      return invokeAPI("udpsocket.setTTL", params);
    }
    /**
     * 监听 Socket 关闭事件（对齐 WebSocket onClose 实现）
     * @param {Function} callbackFn 回调函数
     */
    onClose(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("udpsocket.onClose", {
          mid: this.mid,
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 Socket 关闭事件
     * @param {Function} callbackFn 回调函数
     */
    offClose(callbackFn) {
      return invokeAPI("udpsocket.offClose", {
        mid: this.mid,
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 Socket 错误事件
     * @param {Function} callbackFn 回调函数
     */
    onError(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("udpsocket.onError", {
          mid: this.mid,
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 Socket 错误事件
     * @param {Function} callbackFn 回调函数
     */
    offError(callbackFn) {
      return invokeAPI("udpsocket.offError", {
        mid: this.mid,
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 Socket 监听成功事件
     * @param {Function} callbackFn 回调函数
     */
    onListening(callbackFn) {
      if (isFunction(callbackFn)) {
        return invokeAPI("udpsocket.onListening", {
          mid: this.mid,
          socketId: this.socketId,
          callback: callback.store(callbackFn, true)
        });
      }
    }
    /**
     * 取消监听 Socket 监听成功事件
     * @param {Function} callbackFn 回调函数
     */
    offListening(callbackFn) {
      return invokeAPI("udpsocket.offListening", {
        mid: this.mid,
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 监听 Socket 接收消息事件
     * @param {Function} callbackFn 回调函数
     */
    onMessage(callbackFn) {
      if (!isFunction(callbackFn)) {
        console.log(`【UDP UdpSocketApi】监听消息事件 参数不是函数`);
        return {
          code: 400,
          mid: this.mid,
          socketId: this.socketId,
          message: "callbackFn 必须是函数"
        };
      }
      const params = {
        mid: this.mid,
        socketId: this.socketId,
        success: callback.store((res) => {
          console.log(`【UDP UdpSocketApi】监听消息回调:`, res);
          const arrayBuffer = base64ToArrayBuffer(res.message);
          console.log("【UDP UdpSocketApi】 ArrayBuffer:", arrayBuffer);
          res.message = arrayBuffer;
          callbackFn(res);
        }, true)
      };
      const ret = invokeAPI("udpsocket.onMessage", params);
      console.log(`【UDP UdpSocketApi】监听消息事件`, ret);
      return ret;
    }
    /**
     * 取消监听 Socket 接收消息事件
     * @param {Function} callbackFn 回调函数
     */
    offMessage(callbackFn) {
      return invokeAPI("udpsocket.offMessage", {
        socketId: this.socketId,
        callback: callbackFn
      });
    }
    /**
     * 写入数据（对齐微信 API，复用 send 逻辑）
     * @param {Object} options 配置参数
     */
    write(options) {
      return this.send(options);
    }
    /**
     * 获取当前连接状态
     */
    get readyState() {
      return this._readyState;
    }
  }
  function createUDPSocket(params) {
    console.log("【UDP UdpSocketApi】创建 UDPSocket 实例");
    const ret = invokeAPI("createUDPSocket", params);
    const socketInstance = new UDPSocket(ret);
    console.log("【UDP UdpSocketApi】创建返回", ret);
    return socketInstance;
  }
  const __vite_glob_0_40 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    UDP_CONSTANTS,
    createUDPSocket
  }, Symbol.toStringTag, { value: "Module" }));
  function createAnimation(opts = {}) {
    return new Animation(opts);
  }
  class Animation {
    constructor({ duration = 400, timingFunction = "linear", delay = 0, transformOrigin = "50% 50% 0" } = {}) {
      this.actions = [];
      this.currentTransform = {};
      this.currentStepAnimates = [];
      this.option = {
        transition: {
          duration,
          timingFunction,
          delay
        },
        transformOrigin
      };
    }
    /**
     * 导出动画队列。export 方法每次调用后会清掉之前的动画操作。
     * https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.export.html
     */
    export() {
      const actions = this.actions;
      this.actions = [];
      return { actions };
    }
    /**
     * 表示一组动画完成。可以在一组动画中调用任意多个动画方法，一组动画中的所有动画会同时开始，一组动画完成后才会进行下一组动画。
     * https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.step.html
     */
    step(option = {}) {
      for (const stepAnimate of this.currentStepAnimates) {
        if (stepAnimate.type === "style") {
          this.currentTransform[`${stepAnimate.type}.${stepAnimate.args[0]}`] = stepAnimate;
        } else {
          this.currentTransform[stepAnimate.type] = stepAnimate;
        }
      }
      this.actions.push({
        animates: Object.keys(this.currentTransform).reduce((prev, current) => {
          return [].concat(...prev, [this.currentTransform[current]]);
        }, []),
        option: {
          transformOrigin: option.transformOrigin !== void 0 ? option.transformOrigin : this.option.transformOrigin,
          transition: {
            duration: option.duration !== void 0 ? option.duration : this.option.transition.duration,
            timingFunction: option.timingFunction !== void 0 ? option.timingFunction : this.option.transition.timingFunction,
            delay: option.delay !== void 0 ? option.delay : this.option.transition.delay
          }
        }
      });
      this.currentStepAnimates = [];
      return this;
    }
    backgroundColor(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["background-color", value]
      });
      return this;
    }
    bottom(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["bottom", suffixPixel(value)]
      });
      return this;
    }
    height(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["height", suffixPixel(value)]
      });
      return this;
    }
    left(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["left", suffixPixel(value)]
      });
      return this;
    }
    matrix(a = 1, b = 0, c = 0, d = 1, tx = 1, ty = 1) {
      this.currentStepAnimates.push({
        type: "matrix",
        args: [a, b, c, d, tx, ty]
      });
      return this;
    }
    matrix3d(a1 = 1, b1 = 0, c1 = 0, d1 = 0, a2 = 0, b2 = 1, c2 = 0, d2 = 0, a3 = 0, b3 = 0, c3 = 1, d3 = 0, a4 = 0, b4 = 0, c4 = 0, d4 = 1) {
      this.currentStepAnimates.push({
        type: "matrix3d",
        args: [
          a1,
          b1,
          c1,
          d1,
          a2,
          b2,
          c2,
          d2,
          a3,
          b3,
          c3,
          d3,
          a4,
          b4,
          c4,
          d4
        ]
      });
      return this;
    }
    opacity(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["opacity", value]
      });
      return this;
    }
    right(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["right", suffixPixel(value)]
      });
      return this;
    }
    rotate(angle = 0) {
      this.currentStepAnimates.push({
        type: "rotate",
        args: [angle]
      });
      return this;
    }
    rotate3d(x = 0, y = 0, z = 0, angle = 0) {
      this.currentStepAnimates.push({
        type: "rotate3d",
        args: [x, y, z, angle]
      });
      return this;
    }
    rotateX(angle) {
      this.currentStepAnimates.push({
        type: "rotateX",
        args: [angle]
      });
      return this;
    }
    rotateY(angle) {
      this.currentStepAnimates.push({
        type: "rotateY",
        args: [angle]
      });
      return this;
    }
    rotateZ(angle) {
      this.currentStepAnimates.push({
        type: "rotateZ",
        args: [angle]
      });
      return this;
    }
    scale(x = 1, y = 1) {
      this.currentStepAnimates.push({
        type: "scale",
        args: [x, y]
      });
      return this;
    }
    scale3d(sx = 1, sy = 1, sz = 1) {
      this.currentStepAnimates.push({
        type: "scale3d",
        args: [sx, sy, sz]
      });
      return this;
    }
    scaleX(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleX",
        args: [scale]
      });
      return this;
    }
    scaleY(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleY",
        args: [scale]
      });
      return this;
    }
    scaleZ(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleZ",
        args: [scale]
      });
      return this;
    }
    skew(ax = 0, ay = 0) {
      this.currentStepAnimates.push({
        type: "skew",
        args: [ax, ay]
      });
      return this;
    }
    skewX(angle = 0) {
      this.currentStepAnimates.push({
        type: "skewX",
        args: [angle]
      });
      return this;
    }
    skewY(angle = 0) {
      this.currentStepAnimates.push({
        type: "skewY",
        args: [angle]
      });
      return this;
    }
    top(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["top", suffixPixel(value)]
      });
      return this;
    }
    translate(tx = 0, ty = 0) {
      this.currentStepAnimates.push({
        type: "translate",
        args: [tx, ty]
      });
      return this;
    }
    translate3d(tx = 0, ty = 0, tz = 0) {
      this.currentStepAnimates.push({
        type: "translate3d",
        args: [tx, ty, tz]
      });
      return this;
    }
    translateX(translation = 0) {
      this.currentStepAnimates.push({
        type: "translateX",
        args: [translation]
      });
      return this;
    }
    translateY(translation = 0) {
      this.currentStepAnimates.push({
        type: "translateY",
        args: [translation]
      });
      return this;
    }
    width(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["width", suffixPixel(value)]
      });
      return this;
    }
  }
  const __vite_glob_0_41 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createAnimation
  }, Symbol.toStringTag, { value: "Module" }));
  function setBackgroundTextStyle(opts) {
    invokeAPI("setBackgroundTextStyle", opts);
  }
  function setBackgroundColor(opts) {
    invokeAPI("setBackgroundColor", opts);
  }
  const __vite_glob_0_42 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    setBackgroundColor,
    setBackgroundTextStyle
  }, Symbol.toStringTag, { value: "Module" }));
  let nextTickCallbackList = [];
  let nextTickTimer = null;
  function callNextTick() {
    const cbs = nextTickCallbackList;
    nextTickCallbackList = [];
    nextTickTimer = null;
    for (let i = 0; i < cbs.length; i++) {
      cbs[i]();
    }
  }
  function nextTick(callback2) {
    if (isFunction(callback2)) {
      nextTickCallbackList.push(callback2);
      if (!nextTickTimer) {
        nextTickTimer = setTimeout(callNextTick, 0);
      }
    }
  }
  const __vite_glob_0_43 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    nextTick
  }, Symbol.toStringTag, { value: "Module" }));
  function showToast(opts) {
    invokeAPI("showToast", opts);
  }
  function hideToast(opts) {
    invokeAPI("hideToast", opts);
  }
  function showModal(opts) {
    invokeAPI("showModal", opts);
  }
  function showLoading(opts) {
    invokeAPI("showLoading", opts);
  }
  function showActionSheet(opts) {
    invokeAPI("showActionSheet", opts);
  }
  function hideLoading(opts) {
    invokeAPI("hideLoading", opts);
  }
  function enableAlertBeforeUnload(opts) {
    invokeAPI("enableAlertBeforeUnload", opts);
  }
  function disableAlertBeforeUnload(opts) {
    invokeAPI("disableAlertBeforeUnload", opts);
  }
  const __vite_glob_0_44 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    disableAlertBeforeUnload,
    enableAlertBeforeUnload,
    hideLoading,
    hideToast,
    showActionSheet,
    showLoading,
    showModal,
    showToast
  }, Symbol.toStringTag, { value: "Module" }));
  function getMenuButtonBoundingClientRect() {
    if (globalThis.injectInfo) {
      return globalThis.injectInfo.menuRect;
    }
    return invokeAPI("getMenuButtonBoundingClientRect");
  }
  const __vite_glob_0_45 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getMenuButtonBoundingClientRect
  }, Symbol.toStringTag, { value: "Module" }));
  function showNavigationBarLoading(opts) {
    invokeAPI("showNavigationBarLoading", opts);
  }
  function setNavigationBarTitle(opts) {
    invokeAPI("setNavigationBarTitle", opts);
  }
  function setNavigationBarColor(opts) {
    invokeAPI("setNavigationBarColor", opts);
  }
  function hideNavigationBarLoading(opts) {
    invokeAPI("hideNavigationBarLoading", opts);
  }
  const __vite_glob_0_46 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideNavigationBarLoading,
    setNavigationBarColor,
    setNavigationBarTitle,
    showNavigationBarLoading
  }, Symbol.toStringTag, { value: "Module" }));
  function stopPullDownRefresh(opts) {
    invokeAPI("stopPullDownRefresh", opts);
  }
  function startPullDownRefresh(opts) {
    invokeAPI("startPullDownRefresh", opts);
  }
  const __vite_glob_0_47 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    startPullDownRefresh,
    stopPullDownRefresh
  }, Symbol.toStringTag, { value: "Module" }));
  function pageScrollTo(opts) {
    invokeAPI("pageScrollTo", opts);
  }
  const __vite_glob_0_48 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    pageScrollTo
  }, Symbol.toStringTag, { value: "Module" }));
  function onWindowResize(listener) {
    if (listener) {
      invokeAPI("onWindowResize", {
        success: listener
      });
    }
  }
  const __vite_glob_0_49 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    onWindowResize
  }, Symbol.toStringTag, { value: "Module" }));
  const apiInfo = /* @__PURE__ */ Object.assign({ "./core/base/app-event/index.js": __vite_glob_0_0, "./core/base/index.js": __vite_glob_0_1, "./core/base/performance/index.js": __vite_glob_0_2, "./core/base/subpackage/index.js": __vite_glob_0_3, "./core/base/system/index.js": __vite_glob_0_4, "./core/base/update/index.js": __vite_glob_0_5, "./core/camera/index.js": __vite_glob_0_6, "./core/data-analysis/index.js": __vite_glob_0_7, "./core/device/bluetooth-ble/index.js": __vite_glob_0_8, "./core/device/bluetooth/index.js": __vite_glob_0_9, "./core/device/clipboard/index.js": __vite_glob_0_10, "./core/device/contact/index.js": __vite_glob_0_11, "./core/device/keyboard/index.js": __vite_glob_0_12, "./core/device/memory/index.js": __vite_glob_0_13, "./core/device/network/index.js": __vite_glob_0_14, "./core/device/phone/index.js": __vite_glob_0_15, "./core/device/scan/index.js": __vite_glob_0_16, "./core/device/vibrate/index.js": __vite_glob_0_17, "./core/ext/index.js": __vite_glob_0_18, "./core/life-cycle/index.js": __vite_glob_0_19, "./core/location/index.js": __vite_glob_0_20, "./core/map/index.js": __vite_glob_0_21, "./core/media/image/index.js": __vite_glob_0_22, "./core/media/video/index.js": __vite_glob_0_23, "./core/navigate/index.js": __vite_glob_0_24, "./core/network/download/index.js": __vite_glob_0_25, "./core/network/request/index.js": __vite_glob_0_26, "./core/network/upload/index.js": __vite_glob_0_27, "./core/network/websocket/index.js": __vite_glob_0_28, "./core/open-api/account-info/index.js": __vite_glob_0_29, "./core/open-api/authorize/index.js": __vite_glob_0_30, "./core/open-api/index.js": __vite_glob_0_31, "./core/open-api/login/index.js": __vite_glob_0_32, "./core/open-api/privacy/index.js": __vite_glob_0_33, "./core/open-api/setting/index.js": __vite_glob_0_34, "./core/open-api/user-info/index.js": __vite_glob_0_35, "./core/payment/index.js": __vite_glob_0_36, "./core/route/index.js": __vite_glob_0_37, "./core/share/index.js": __vite_glob_0_38, "./core/storage/index.js": __vite_glob_0_39, "./core/udp/index.js": __vite_glob_0_40, "./core/ui/animation/index.js": __vite_glob_0_41, "./core/ui/background/index.js": __vite_glob_0_42, "./core/ui/custom-component/index.js": __vite_glob_0_43, "./core/ui/interaction/index.js": __vite_glob_0_44, "./core/ui/menu/index.js": __vite_glob_0_45, "./core/ui/navigation-bar/index.js": __vite_glob_0_46, "./core/ui/pull-down-refresh/index.js": __vite_glob_0_47, "./core/ui/scroll/index.js": __vite_glob_0_48, "./core/ui/window/index.js": __vite_glob_0_49, "./core/wxml/intersection-observer/index.js": __vite_glob_0_50, "./core/wxml/selector-query/index.js": __vite_glob_0_51 });
  const api = {};
  for (const f of Object.values(apiInfo)) {
    for (const [k, v] of Object.entries(f)) {
      api[k] = v;
    }
  }
  const handler = {
    get(target, prop, receiver) {
      const origMethod = Reflect.get(target, prop, receiver);
      if (typeof origMethod === "function") {
        return origMethod;
      }
      if (origMethod !== void 0 || prop === "webpackJsonp") {
        return origMethod;
      }
      return (...args) => {
        return invokeAPI(prop, ...args);
      };
    },
    set(target, prop, value, receiver) {
      return Reflect.set(target, prop, value, receiver);
    }
  };
  const globalApi = new Proxy(api, handler);
  class Env {
    constructor() {
      this.init();
    }
    init() {
      globalThis.dd = globalThis.wx = globalApi;
      globalThis.modRequire = modRequire;
      globalThis.modDefine = modDefine;
      globalThis.global = {};
      globalThis.App = (moduleInfo) => loader.createAppModule(moduleInfo);
      globalThis.Page = (moduleInfo) => {
        loader.createModule(moduleInfo, globalThis.__extraInfo, PageModule.type);
      };
      globalThis.Component = (moduleInfo) => {
        loader.createModule(moduleInfo, globalThis.__extraInfo, ComponentModule.type);
      };
      globalThis.Behavior = (behaviorInfo) => {
        return behaviorInfo;
      };
      globalThis.getApp = () => loader.getAppModule()?.moduleInfo;
      globalThis.getCurrentPages = () => router.stack();
    }
  }
  const env = new Env();
  const actionMap = { navigateBack, navigateTo, reLaunch, redirectTo, switchTab };
  class Service {
    constructor() {
      console.log("[service] init");
      this.env = env;
      this.message = message;
      this.init();
    }
    init() {
      this.message.on("loadResource", (msg) => {
        const { appId, bridgeId, pagePath, root = ".", baseUrl = "/", injectInfo } = msg;
        globalThis.injectInfo = injectInfo;
        loader.loadResource({ appId, bridgeId, pagePath, root, baseUrl });
      });
      this.message.on("t", async (msg) => {
        const { bridgeId, moduleId, methodName, event, success } = msg;
        if (methodName === void 0) {
          return;
        }
        const data = await runtime.triggerEvent({ bridgeId, moduleId, methodName, event });
        if (data !== void 0) {
          this.message.send({
            type: "triggerCallback",
            target: "render",
            body: {
              bridgeId,
              moduleId,
              success,
              data
            }
          });
        }
      });
      this.message.on("triggerCallback", (msg) => {
        const { id, args } = msg;
        callback.invoke(id, args);
      });
      this.onAppMsg();
      this.onModuleMsg();
    }
    onAppMsg() {
      this.message.on("resourceLoaded", (msg) => {
        const { bridgeId, scene, pagePath, query, stackId } = msg;
        runtime.createApp({ scene, pagePath, query });
        const module = loader.getModuleByPath(pagePath);
        if (!module) {
          console.error(`[service] resourceLoaded: module not found, pagePath: ${pagePath}`);
          return;
        }
        const initialProps = loader.getPropsByPath(module.usingComponents);
        const pageId = `page_${uuid()}`;
        runtime.createInstance({ bridgeId, moduleId: pageId, path: pagePath, query, stackId });
        message.send({
          type: "firstRender",
          target: "render",
          body: {
            bridgeId,
            pageId,
            pagePath,
            initialProps,
            query
          }
        });
      });
      this.message.on("appShow", () => {
        runtime.appShow();
      });
      this.message.on("appHide", () => {
        runtime.appHide();
      });
      this.message.on("stackShow", ({ stackId }) => {
        runtime.stackShow(stackId);
      });
      this.message.on("stackHide", ({ stackId }) => {
        runtime.stackHide(stackId);
      });
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/page-life-cycle.html
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
     */
    onModuleMsg() {
      this.message.on("mC", (msg) => {
        runtime.createInstance(msg);
      });
      this.message.on("mR", (msg) => {
        runtime.moduleReady(msg);
      });
      this.message.on("mU", (msg) => {
        runtime.moduleUnmounted(msg);
      });
      this.message.on("pageUnload", (msg) => {
        runtime.pageUnload(msg);
      });
      this.message.on("pageShow", (msg) => {
        runtime.pageShow(msg);
      });
      this.message.on("pageReady", (msg) => {
        runtime.pageReady(msg);
      });
      this.message.on("pageHide", (msg) => {
        runtime.pageHide(msg);
      });
      this.message.on("pagePullDownRefresh", () => {
      });
      this.message.on("pageReachBottom", () => {
      });
      this.message.on("pageShareAppMessage", () => {
      });
      this.message.on("pageScroll", (msg) => {
        runtime.pageScroll(msg);
      });
      this.message.on("pageResize", (msg) => {
        runtime.pageResize(msg);
      });
      this.message.on("onTabItemTap", () => {
      });
      this.message.on("pageRouteDone", (msg) => {
        const { bridgeId } = msg;
        runtime.componentRouteDone({ bridgeId });
      });
      this.message.on("componentError", (msg) => {
        runtime.componentError(msg);
      });
      this.message.on("h5SdkAction", async (msg = {}) => {
        const actionName = msg?.name?.replace(/h5/i, "");
        const { url } = msg?.params?.data?.params || {};
        msg.params && (msg.params.data = {
          ...msg.params?.data,
          ...msg.params?.data?.params || {}
        });
        if (actionName === "postMessage" && msg.parentWebViewId) {
          const { moduleId, attrs, params } = msg;
          const event = { detail: { data: [params?.data?.params?.data] } };
          const methodName = attrs.message;
          const parentWebViewId = msg.parentWebViewId;
          const data = await runtime.triggerEvent({ bridgeId: parentWebViewId, moduleId, methodName, event });
          if (data !== void 0) {
            this.message.send({
              type: "triggerCallback",
              target: "service",
              body: {
                bridgeId: parentWebViewId,
                moduleId,
                success: params?.success,
                data
              }
            });
          }
        }
        actionMap[actionName]?.({ url, ...msg.params });
      });
    }
  }
  const index = new Service();
  return index;
})();

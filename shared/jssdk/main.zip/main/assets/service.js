var service = (function() {
	//#region \0rolldown/runtime.js
	var __defProp = Object.defineProperty;
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	//#endregion
	//#region ../common/dist/common.js
	function isFunction(value) {
		return typeof value === "function";
	}
	function isString(value) {
		return typeof value === "string";
	}
	function isNil(value) {
		return value === null || value === void 0;
	}
	function deepEqual(a, b) {
		if (a === b) return true;
		if (typeof a !== "object" || typeof b !== "object" || a == null || b == null) return false;
		const keysA = Object.keys(a);
		const keysB = Object.keys(b);
		if (keysA.length !== keysB.length) return false;
		return keysA.every((key) => deepEqual(a[key], b[key]));
	}
	function isUnsafeProperty(key) {
		return key === "__proto__";
	}
	function isDeepKey(key) {
		switch (typeof key) {
			case "number":
			case "symbol": return false;
			case "string": return key.includes(".") || key.includes("[") || key.includes("]");
		}
	}
	function toKey(value) {
		if (typeof value === "string" || typeof value === "symbol") return value;
		if (Object.is(value?.valueOf?.(), -0)) return "-0";
		return String(value);
	}
	function toPath(value) {
		if (Array.isArray(value)) return value.map(toKey);
		if (typeof value === "symbol") return [value];
		value = toPathString(value);
		const result = [];
		const length = value.length;
		if (length === 0) return result;
		let index = 0;
		let key = "";
		let quoteChar = "";
		let bracket = false;
		if (value.charCodeAt(0) === 46) {
			result.push("");
			index++;
		}
		while (index < length) {
			const char = value[index];
			if (quoteChar) if (char === "\\" && index + 1 < length) {
				index++;
				key += value[index];
			} else if (char === quoteChar) quoteChar = "";
			else key += char;
			else if (bracket) if (char === "\"" || char === "'") quoteChar = char;
			else if (char === "]") {
				bracket = false;
				result.push(key);
				key = "";
			} else key += char;
			else if (char === "[") {
				bracket = true;
				if (key) {
					result.push(key);
					key = "";
				}
			} else if (char === ".") {
				if (key) {
					result.push(key);
					key = "";
				}
			} else key += char;
			index++;
		}
		if (key) result.push(key);
		return result;
	}
	function toPathString(value) {
		if (value == null) return "";
		if (typeof value === "string") return value;
		if (Array.isArray(value)) return value.map(toPathString).join(",");
		const result = String(value);
		if (result === "0" && Object.is(Number(value), -0)) return "-0";
		return result;
	}
	function getWithPath(object, path, defaultValue) {
		if (path.length === 0) return defaultValue;
		let current = object;
		for (let index = 0; index < path.length; index++) {
			if (current == null) return defaultValue;
			if (isUnsafeProperty(path[index])) return defaultValue;
			current = current[path[index]];
		}
		if (current === void 0) return defaultValue;
		return current;
	}
	function get(data, path) {
		if (data == null) return;
		switch (typeof path) {
			case "string": {
				if (isUnsafeProperty(path)) return;
				const result = data[path];
				if (result === void 0) return isDeepKey(path) ? get(data, toPath(path)) : void 0;
				return result;
			}
			case "number":
			case "symbol": {
				if (typeof path === "number") path = toKey(path);
				const result = data[path];
				return result === void 0 ? void 0 : result;
			}
			default: {
				if (Array.isArray(path)) return getWithPath(data, path);
				path = Object.is(path?.valueOf(), -0) ? "-0" : String(path);
				if (isUnsafeProperty(path)) return;
				const result = data[path];
				return result === void 0 ? void 0 : result;
			}
		}
	}
	function uuid() {
		return Math.random().toString(36).slice(2, 7);
	}
	function toCamelCase(attr) {
		return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
			return group.toUpperCase();
		});
	}
	function camelCaseToUnderscore(str) {
		return str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
	}
	var isBrowser = typeof window !== "undefined" && typeof navigator !== "undefined";
	isBrowser && /Android/i.test(navigator.userAgent);
	isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent);
	isBrowser && /OpenHarmony|harmony/.test(navigator.userAgent);
	isBrowser && /Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
	var isWebWorker = (() => {
		if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) return true;
		else return false;
	})();
	function resolvePath(basePath, relativePath) {
		if (relativePath.startsWith("/")) return relativePath.slice(1);
		const currParts = basePath.split("/");
		const relativeParts = relativePath.split("/");
		for (const element of relativeParts) {
			const part = element;
			if (part === "..") {
				if (currParts.length > 0) currParts.pop();
			} else if (part !== "." && part !== "") currParts.push(part);
		}
		return currParts.join("/");
	}
	function parsePath(currPath, url) {
		const basePath = currPath.split("/").slice(0, -1).join("/");
		const parts = url.split("?");
		const pagePath = parts[0];
		const paramStr = parts[1];
		let newUrl = resolvePath(basePath, pagePath);
		if (paramStr) newUrl += `?${paramStr}`;
		return newUrl;
	}
	function suffixPixel(value) {
		return typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value) ? `${value}px` : value;
	}
	/**
	* 高效的深拷贝实现
	* @param {*} value - 要拷贝的值
	* @returns {*} 拷贝后的值
	*/
	function cloneDeep(value) {
		if (value === null || typeof value !== "object") return value;
		const seen = /* @__PURE__ */ new WeakMap();
		function clone(item) {
			if (item === null || typeof item !== "object") return item;
			if (item instanceof Date) return new Date(item);
			if (item instanceof RegExp) return new RegExp(item.source, item.flags);
			if (Array.isArray(item)) {
				if (seen.has(item)) return seen.get(item);
				const arr = [];
				seen.set(item, arr);
				arr.push(...item.map(clone));
				return arr;
			}
			if (seen.has(item)) return seen.get(item);
			const obj = Object.create(Object.getPrototypeOf(item));
			seen.set(item, obj);
			return Object.assign(obj, ...Object.keys(item).map((key) => ({ [key]: clone(item[key]) })));
		}
		return clone(value);
	}
	var JSModules = {};
	var MODULES_STATUS_UNLOAD = 1;
	var MODULES_STATUS_LOADED = 2;
	function modDefine(id, factory) {
		if (!JSModules[id]) JSModules[id] = {
			factory,
			status: MODULES_STATUS_UNLOAD,
			exports: void 0
		};
	}
	function modRequire(id, callback, errorCallback) {
		if (typeof id !== "string") throw new TypeError("require args must be a string");
		const mod = JSModules[id];
		if (!mod) throw new Error(`module ${id} not found`);
		if (mod.status === MODULES_STATUS_UNLOAD) {
			mod.status = MODULES_STATUS_LOADED;
			const module = { exports: {} };
			let res;
			try {
				if (mod.factory) res = mod.factory.call(null, modRequire, module, module.exports);
			} catch (e) {
				mod.status = MODULES_STATUS_UNLOAD;
				const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
				console.error(`require ${id} error: ${em}`);
				if (isFunction(errorCallback)) errorCallback({
					mod: id,
					errMsg: e.message
				});
			}
			mod.exports = module.exports === void 0 ? res : module.exports;
		}
		if (isFunction(callback)) callback(mod.exports);
		return mod.exports;
	}
	modRequire.async = async (id) => {
		return new Promise((resolve, reject) => {
			try {
				resolve(modRequire(id));
			} catch (e) {
				reject(/* @__PURE__ */ new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
			}
		});
	};
	var Callback = class {
		constructor() {
			this.callbacks = {};
		}
		store(callback, keep, evtId = uuid()) {
			if (keep) {
				for (const [k, v] of Object.entries(this.callbacks)) if (v.callback === callback) return k;
			}
			this.callbacks[evtId] = {
				callback,
				keep
			};
			return evtId;
		}
		/**
		* [Container] triggerCallback -> [Service] invoke
		* @param {*} evtId
		* @param {*} args
		*/
		invoke(evtId, args) {
			if (evtId === void 0) return;
			const obj = this.callbacks[evtId];
			if (obj && isFunction(obj.callback)) {
				obj.callback(args);
				if (!obj.keep) delete this.callbacks[evtId];
			}
		}
		remove(evtId) {
			if (evtId) Object.keys(this.callbacks).forEach((k) => {
				if (evtId === k) delete this.callbacks[k];
			});
			else Object.entries(this.callbacks).forEach(([k, v]) => {
				if (v.keep) delete this.callbacks[k];
			});
		}
	};
	var callback_default = new Callback();
	var DATA_FUNCTION_REFERENCE_KEY = "__dimina_data_function_reference__";
	var DATA_FUNCTION_REFERENCE_VERSION = 1;
	function createDataFunctionReference(id) {
		return {
			[DATA_FUNCTION_REFERENCE_KEY]: id,
			version: DATA_FUNCTION_REFERENCE_VERSION
		};
	}
	function isDataFunctionReference(value) {
		return value !== null && typeof value === "object" && value.version === DATA_FUNCTION_REFERENCE_VERSION && typeof value[DATA_FUNCTION_REFERENCE_KEY] === "string" && Object.keys(value).length === 2;
	}
	function getDataFunctionReferenceId(value) {
		return isDataFunctionReference(value) ? value[DATA_FUNCTION_REFERENCE_KEY] : void 0;
	}
	/**
	* Recursively transform functions and their bridge references without applying
	* JSON semantics to the surrounding data. This keeps Dates, typed arrays and
	* other bridge-supported values intact while making functions transferable.
	*/
	function transformDataFunctions(value, { mapFunction, mapReference } = {}, seen = /* @__PURE__ */ new WeakMap()) {
		if (typeof value === "function") return mapFunction ? mapFunction(value) : value;
		if (value === null || typeof value !== "object") return value;
		if (isDataFunctionReference(value)) return mapReference ? mapReference(value) : value;
		if (value instanceof Date || value instanceof RegExp || value instanceof ArrayBuffer || ArrayBuffer.isView(value)) return value;
		if (!Array.isArray(value)) {
			const prototype = Object.getPrototypeOf(value);
			if (prototype !== Object.prototype && prototype !== null) return value;
		}
		if (seen.has(value)) return seen.get(value);
		const transformed = Array.isArray(value) ? [] : {};
		seen.set(value, transformed);
		for (const key of Object.keys(value)) transformed[key] = transformDataFunctions(value[key], {
			mapFunction,
			mapReference
		}, seen);
		return transformed;
	}
	var SUPPORTED_PROPERTY_TYPES = /* @__PURE__ */ new Set([
		String,
		Number,
		Boolean,
		Object,
		Array,
		null
	]);
	function isPropertyType(type) {
		return SUPPORTED_PROPERTY_TYPES.has(type);
	}
	function getImplicitDefault(type) {
		if (type === String) return "";
		if (type === Number) return 0;
		if (type === Boolean) return false;
		if (type === Array) return [];
		return null;
	}
	function normalizeOptionalTypes(optionalTypes) {
		if (!Array.isArray(optionalTypes)) return [];
		return optionalTypes.filter(isPropertyType);
	}
	/**
	* 将小程序 properties 的简写/完整声明统一成可跨线程传输的语义结构。
	* 微信在声明阶段会为未显式提供 value 的属性按主类型补默认值。
	*/
	function normalizePropertyDefinition(definition) {
		let type;
		let optionalTypes = [];
		let value;
		if (isPropertyType(definition)) type = definition;
		else if (definition && typeof definition === "object") {
			type = definition.type;
			optionalTypes = normalizeOptionalTypes(definition.optionalTypes);
			value = definition.value;
		}
		if (!isPropertyType(type)) type = optionalTypes[0] ?? null;
		if (value === void 0) value = getImplicitDefault(type);
		return {
			type,
			optionalTypes,
			value: cloneDeep(value)
		};
	}
	function isExparserArray(value) {
		return Array.isArray(value);
	}
	function isPlainArray(value) {
		return isExparserArray(value) && value?.constructor?.name === Array.name;
	}
	/**
	* optionalTypes 只做严格类型匹配；命中后保持调用方传入值，不执行主类型转换。
	*/
	function matchesPropertyType(type, value) {
		if (type === String) return typeof value === "string";
		if (type === Number) return Number.isFinite(value);
		if (type === Boolean) return typeof value === "boolean";
		if (type === Object) return value !== null && value?.constructor === Object;
		if (type === Array) return isPlainArray(value);
		return value !== void 0;
	}
	function warnTypeConversion(warn, message) {
		if (typeof warn === "function") warn(message);
	}
	/**
	* 对齐微信 exparser 的 property convertValueToType 行为。
	* absent=true 表示模板没有传入该属性，此时使用组件声明的默认值。
	*/
	function resolvePropertyValue(schema, value, { absent = false, warn } = {}) {
		if (absent) return cloneDeep(schema.value);
		for (const optionalType of schema.optionalTypes || []) if (matchesPropertyType(optionalType, value)) return value;
		const type = schema.type;
		if (type === String) {
			if (value === null || value === void 0) {
				warnTypeConversion(warn, "property received type-uncompatible value: expected <String> but get null value. Used empty string instead.");
				return "";
			}
			if (typeof value === "object") warnTypeConversion(warn, "property received type-uncompatible value: expected <String> but got object-typed value. Forcely converted.");
			return String(value);
		}
		if (type === Number) {
			try {
				if (Number.isFinite(Number(value))) return Number(value);
			} catch {}
			warnTypeConversion(warn, `property received type-uncompatible value: expected <Number> but ${typeof value === "number" ? "got NaN or Infinity" : "got non-number value"}. Used 0 instead.`);
			return 0;
		}
		if (type === Boolean) return !!value;
		if (type === Array) {
			if (isExparserArray(value)) return value;
			warnTypeConversion(warn, "property received type-uncompatible value: expected <Array> but got non-array value. Used empty array instead.");
			return [];
		}
		if (type === Object) {
			if (typeof value === "object") return value;
			warnTypeConversion(warn, "property received type-uncompatible value: expected <Object> but got non-object value. Used null instead.");
			return null;
		}
		if (value === void 0) return null;
		return value;
	}
	//#endregion
	//#region src/core/host-env.js
	var HostEnv = class {
		constructor() {
			this.listeners = /* @__PURE__ */ new Set();
			this.reset();
		}
		reset() {
			this.active = false;
			this.snapshot = {
				systemInfo: null,
				menuRect: null
			};
		}
		init(snapshot = {}) {
			this.active = true;
			this.snapshot = {
				...this.snapshot,
				...snapshot
			};
		}
		update(patch = {}) {
			this.snapshot = {
				...this.snapshot,
				...patch
			};
			this.listeners.forEach((listener) => listener(patch, this.snapshot));
		}
		onUpdate(listener) {
			this.listeners.add(listener);
			return () => this.listeners.delete(listener);
		}
		get(key) {
			if (!this.active) return null;
			return this.snapshot[key] ?? null;
		}
		getSystemInfo() {
			return this.get("systemInfo");
		}
		getMenuRect() {
			return this.get("menuRect");
		}
	};
	var host_env_default = new HostEnv();
	//#endregion
	//#region ../../node_modules/.pnpm/mitt@3.0.1/node_modules/mitt/dist/mitt.mjs
	function mitt_default(n) {
		return {
			all: n = n || /* @__PURE__ */ new Map(),
			on: function(t, e) {
				var i = n.get(t);
				i ? i.push(e) : n.set(t, [e]);
			},
			off: function(t, e) {
				var i = n.get(t);
				i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
			},
			emit: function(t, e) {
				var i = n.get(t);
				i && i.slice().map(function(n) {
					n(e);
				}), (i = n.get("*")) && i.slice().map(function(n) {
					n(t, e);
				});
			}
		};
	}
	//#endregion
	//#region src/core/data-function.js
	var referenceByFunction = /* @__PURE__ */ new WeakMap();
	var functionByReference = /* @__PURE__ */ new Map();
	function registerDataFunction(fn) {
		const existingReference = referenceByFunction.get(fn);
		if (existingReference) {
			functionByReference.set(existingReference, fn);
			return existingReference;
		}
		let reference;
		do
			reference = `data-function-${uuid()}`;
		while (functionByReference.has(reference));
		referenceByFunction.set(fn, reference);
		functionByReference.set(reference, fn);
		return reference;
	}
	function resolveDataFunction(reference) {
		return functionByReference.get(reference);
	}
	function encodeDataFunctions(value) {
		return transformDataFunctions(value, { mapFunction(fn) {
			return createDataFunctionReference(registerDataFunction(fn));
		} });
	}
	function decodeDataFunctions(value) {
		return transformDataFunctions(value, { mapReference(reference) {
			return resolveDataFunction(getDataFunctionReferenceId(reference)) || reference;
		} });
	}
	var message_default = new class Message {
		constructor() {
			this.event = mitt_default();
			this.init();
		}
		init() {
			if (isWebWorker) globalThis.onmessage = (e) => {
				this.handleMsg(e.data);
			};
			else DiminaServiceBridge.onMessage = this.handleMsg.bind(this);
		}
		handleMsg(msg) {
			const decodedMsg = decodeDataFunctions(msg);
			console.log("[service] receive msg: ", isWebWorker ? decodedMsg : JSON.stringify(decodedMsg));
			const { type, body } = decodedMsg;
			this.event.emit(type, body);
		}
		on(type, callback) {
			this.event.on(type, callback);
		}
		off(type) {
			this.event.off(type);
		}
		send(msg) {
			if (isWebWorker) Message.prototype.send = function(msg) {
				const encodedMsg = encodeDataFunctions(msg);
				encodedMsg.method = "publish";
				globalThis.postMessage(encodedMsg);
			};
			else Message.prototype.send = function(msg) {
				const encodedMsg = encodeDataFunctions(msg);
				return DiminaServiceBridge.publish(encodedMsg.body.bridgeId || "", encodedMsg);
			};
			return this.send(msg);
		}
		invoke(msg) {
			if (isWebWorker) Message.prototype.invoke = function(msg) {
				msg.method = "invoke";
				globalThis.postMessage(msg);
			};
			else Message.prototype.invoke = function(msg) {
				return DiminaServiceBridge.invoke(msg);
			};
			return this.invoke(msg);
		}
	}();
	//#endregion
	//#region src/core/router.js
	var Router = class {
		#stacks = [];
		#initId = "";
		setInitId(id) {
			this.#initId = id;
		}
		push(pageInfo, stackId) {
			this.stack(stackId).push(pageInfo);
		}
		pop() {
			if (this.stack().length > 0) this.stack().pop();
		}
		remove(pageId) {
			for (let i = this.#stacks.length - 1; i >= 0; i--) {
				const pages = this.#stacks[i].pages;
				const pageIndex = pages.findIndex((page) => page.id === pageId);
				if (pageIndex !== -1) {
					pages.splice(pageIndex, 1);
					return;
				}
			}
		}
		getPageInfo() {
			const pages = this.stack();
			return pages[pages.length - 1] || { id: this.#initId };
		}
		/**
		* 推入一个新页面栈
		*/
		pushStack(stackId) {
			const newStack = {
				id: stackId,
				pages: []
			};
			this.#stacks.push(newStack);
			return newStack;
		}
		/**
		* 当前新页面栈退出
		*/
		popStack(stackId) {
			if (stackId) {
				const index = this.#stacks.findIndex((stack) => stack.id === stackId);
				if (index !== -1) this.#stacks.splice(index, 1);
			} else if (this.#stacks.length > 0) this.#stacks.pop();
		}
		/**
		* 获取当前页面栈
		*/
		stack(stackId) {
			if (stackId) {
				let currentStack = this.#stacks.find((stack) => stack.id === stackId);
				if (!currentStack) currentStack = this.pushStack(stackId);
				return currentStack.pages;
			} else {
				const currentStack = this.#stacks[this.#stacks.length - 1];
				if (currentStack) return currentStack.pages;
				else return this.pushStack(Date.now()).pages;
			}
		}
	};
	var router_default = new Router();
	//#endregion
	//#region src/api/common/index.js
	function pick(obj, keys) {
		if (!obj) return obj;
		const result = {};
		for (const key of keys) if (key in obj) result[key] = obj[key];
		return result;
	}
	var hostEnvResolvers = {
		getWindowInfo: () => pick(host_env_default.getSystemInfo(), [
			"pixelRatio",
			"screenWidth",
			"screenHeight",
			"windowWidth",
			"windowHeight",
			"statusBarHeight",
			"safeArea",
			"screenTop"
		]),
		getSystemInfoSync: () => host_env_default.getSystemInfo(),
		getAppBaseInfo: () => pick(host_env_default.getSystemInfo(), [
			"SDKVersion",
			"enableDebug",
			"host",
			"language",
			"version",
			"theme",
			"fontSizeScaleFactor",
			"fontSizeSetting"
		]),
		getDeviceInfo: () => pick(host_env_default.getSystemInfo(), [
			"abi",
			"benchmarkLevel",
			"brand",
			"model",
			"platform",
			"system"
		]),
		getMenuButtonBoundingClientRect: () => host_env_default.getMenuRect()
	};
	var promiseUnsupportedApis = /* @__PURE__ */ new Set([
		"connectSocket",
		"downloadFile",
		"loadSubpackage",
		"preDownloadSubpackage",
		"request",
		"uploadFile"
	]);
	var optionalParamPromiseApis = /* @__PURE__ */ new Set([
		"FileSystemManager.getSavedFileList",
		"clearStorage",
		"chooseImage",
		"chooseMedia",
		"chooseVideo",
		"closeBluetoothAdapter",
		"getClipboardData",
		"getBluetoothAdapterState",
		"getBluetoothDevices",
		"getLocation",
		"getNetworkType",
		"getPrivacySetting",
		"getStorageInfo",
		"getSystemInfo",
		"getSystemInfoAsync",
		"getUserInfo",
		"hideKeyboard",
		"hideLoading",
		"hideShareMenu",
		"hideTabBar",
		"hideToast",
		"login",
		"navigateBack",
		"openAppAuthorizeSetting",
		"openBluetoothAdapter",
		"openSetting",
		"openSystemBluetoothSetting",
		"showNavigationBarLoading",
		"showShareMenu",
		"showTabBar",
		"startPullDownRefresh",
		"startRecord",
		"stopPullDownRefresh",
		"stopBluetoothDevicesDiscovery",
		"stopLocationUpdate",
		"stopRecord",
		"vibrateLong",
		"vibrateShort"
	]);
	function hasCallbackField(data) {
		return Object.prototype.hasOwnProperty.call(data, "success") || Object.prototype.hasOwnProperty.call(data, "fail") || Object.prototype.hasOwnProperty.call(data, "complete");
	}
	function canReturnPromise(name, data) {
		if (promiseUnsupportedApis.has(name) || typeof name === "string" && name.endsWith("Sync")) return false;
		if (data === void 0) return optionalParamPromiseApis.has(name);
		return true;
	}
	function invokeMessage(name, params, target) {
		const msg = {
			type: "invokeAPI",
			target,
			body: {
				name,
				bridgeId: router_default.getPageInfo().id,
				params
			}
		};
		if (target === "container") return message_default.invoke(msg);
		else return message_default.send(msg);
	}
	function invokePromiseAPI(name, params, target) {
		return new Promise((resolve, reject) => {
			let successId;
			let failId;
			const cleanup = () => {
				callback_default.remove(successId);
				callback_default.remove(failId);
			};
			successId = callback_default.store((res) => {
				cleanup();
				resolve(res);
			});
			failId = callback_default.store((res) => {
				cleanup();
				reject(res);
			});
			params.success = successId;
			params.fail = failId;
			try {
				invokeMessage(name, params, target);
			} catch (error) {
				cleanup();
				reject(error);
			}
		});
	}
	function invokeAPI(name, data, target = "container") {
		const resolveFromHostEnv = hostEnvResolvers[name];
		if (target === "container" && resolveFromHostEnv) {
			const cachedValue = resolveFromHostEnv();
			if (cachedValue) return cachedValue;
		}
		let params;
		if (data === void 0) {
			if (canReturnPromise(name, data)) return invokePromiseAPI(name, {}, target);
			params = data;
		} else if (typeof data === "string" || Array.isArray(data)) params = data;
		else if (isFunction(data)) params = { success: callback_default.store(data, true) };
		else if (hasCallbackField(data)) {
			const { success, fail, complete, keep, evtId, ...rest } = data;
			params = rest;
			if (evtId !== void 0) params.evtId = evtId;
			if (isFunction(success)) params.success = callback_default.store(success, keep, evtId);
			else params.success = success;
			if (isFunction(fail)) params.fail = callback_default.store(fail, keep, evtId);
			if (isFunction(complete)) params.complete = callback_default.store(complete, keep, evtId);
		} else {
			const { keep, ...rest } = data;
			delete rest.evtId;
			if (!keep && canReturnPromise(name, data)) {
				params = { ...rest };
				return invokePromiseAPI(name, params, target);
			}
			params = rest;
		}
		return invokeMessage(name, params, target);
	}
	//#endregion
	//#region src/api/core/route/index.js
	var route_exports = /* @__PURE__ */ __exportAll({
		navigateBack: () => navigateBack,
		navigateTo: () => navigateTo,
		reLaunch: () => reLaunch,
		redirectTo: () => redirectTo,
		switchTab: () => switchTab
	});
	/**
	* 跳转到 tabBar 页面，并关闭其他所有非 tabBar 页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.switchTab.html
	* @param {*} opts
	*/
	function switchTab(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		return invokeAPI("switchTab", opts);
	}
	/**
	* 关闭所有页面，打开到应用内的某个页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.reLaunch.html
	* @param {*} opts
	*/
	function reLaunch(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		return invokeAPI("reLaunch", opts);
	}
	/**
	* 关闭当前页面，跳转到应用内的某个页面。但是不允许跳转到 tabbar 页面。
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.redirectTo.html
	* @param {*} opts
	*/
	function redirectTo(opts) {
		const url = parsePath(router_default.getPageInfo().route, opts.url);
		if (router_default.getPageInfo().route === url) return;
		opts.url = url;
		return invokeAPI("redirectTo", opts);
	}
	/**
	* 保留当前页面，跳转到应用内的某个页面。但是不能跳到 tabbar 页面
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.navigateTo.html
	* @param {*} opts
	*/
	function navigateTo(opts) {
		opts.url = parsePath(router_default.getPageInfo().route, opts.url);
		return invokeAPI("navigateTo", opts);
	}
	/**
	* 关闭当前页面，返回上一页面或多级页面。可通过 getCurrentPages 获取当前的页面栈，决定需要返回几层。
	* https://developers.weixin.qq.com/miniprogram/dev/api/route/wx.navigateBack.html
	* @param {*} opts
	*/
	function navigateBack(opts) {
		return invokeAPI("navigateBack", opts);
	}
	//#endregion
	//#region src/api/core/base/app-event/index.js
	var app_event_exports = /* @__PURE__ */ __exportAll({
		offAppHide: () => offAppHide,
		offAppShow: () => offAppShow,
		offError: () => offError,
		onAppHide: () => onAppHide,
		onAppRoute: () => onAppRoute,
		onAppShow: () => onAppShow,
		onError: () => onError,
		onPageNotFound: () => onPageNotFound,
		onUnhandledRejection: () => onUnhandledRejection
	});
	/**
	* 监听小程序错误事件。如脚本错误或 API 调用报错等。该事件与 App.onError 的回调时机与参数一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onError.html
	*/
	function onError(opts) {
		return invokeAPI("onError", opts);
	}
	/**
	* 移除小程序错误事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offError.html
	*/
	function offError(opts) {
		return invokeAPI("offError", opts);
	}
	/**
	* 监听小程序切前台事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onAppShow.html
	*/
	function onAppShow(opts) {
		return invokeAPI("onAppShow", opts);
	}
	/**
	* 监听小程序切后台事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onAppHide.html
	*/
	function onAppHide(opts) {
		return invokeAPI("onAppHide", opts);
	}
	/**
	* 移除小程序切前台事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offAppShow.html
	*/
	function offAppShow(opts) {
		return invokeAPI("offAppShow", opts);
	}
	/**
	* 移除小程序切后台事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.offAppHide.html
	*/
	function offAppHide(opts) {
		return invokeAPI("offAppHide", opts);
	}
	/**
	* 监听未处理的 Promise 拒绝事件。该事件与 App.onUnhandledRejection 的回调时机与参数一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onUnhandledRejection.html
	*/
	function onUnhandledRejection() {}
	/**
	* 监听小程序要打开的页面不存在事件。该事件与 App.onPageNotFound 的回调时机一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/app-event/wx.onPageNotFound.html
	*/
	function onPageNotFound() {}
	/**
	* 小程序隐藏API - onAppRoute(eventListener) | 微信开放社区
	* https://developers.weixin.qq.com/community/develop/article/doc/00006c80998d182690edbb60c56413
	*/
	function onAppRoute() {}
	//#endregion
	//#region src/api/core/file/index.js
	var file_exports = /* @__PURE__ */ __exportAll({
		fileSystemManagerAPINames: () => fileSystemManagerAPINames,
		getFileSystemManager: () => getFileSystemManager
	});
	var ARRAY_BUFFER_BASE64_KEY$2 = "__diminaArrayBufferBase64";
	var FILE_DATA_BASE64_KEY = "__diminaFileDataBase64";
	var FILE_DATA_TYPE_KEY = "__diminaFileDataType";
	var BASE64_CHARS$2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	var BASE64_LOOKUP$2 = (() => {
		const lookup = {};
		for (let i = 0; i < 64; i++) lookup[BASE64_CHARS$2[i]] = i;
		return lookup;
	})();
	function isArrayBuffer$2(value) {
		return Object.prototype.toString.call(value) === "[object ArrayBuffer]";
	}
	function isArrayBufferView(value) {
		return value && value.buffer && isArrayBuffer$2(value.buffer);
	}
	function toArrayBuffer$2(value) {
		if (isArrayBuffer$2(value)) return value;
		if (isArrayBufferView(value)) return value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength);
		return null;
	}
	function arrayBufferToBase64$2(buffer) {
		const bytes = new Uint8Array(buffer);
		let result = "";
		let i = 0;
		for (; i + 2 < bytes.length; i += 3) {
			result += BASE64_CHARS$2[bytes[i] >> 2];
			result += BASE64_CHARS$2[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
			result += BASE64_CHARS$2[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
			result += BASE64_CHARS$2[bytes[i + 2] & 63];
		}
		if (i < bytes.length) {
			result += BASE64_CHARS$2[bytes[i] >> 2];
			if (i + 1 < bytes.length) {
				result += BASE64_CHARS$2[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
				result += BASE64_CHARS$2[(bytes[i + 1] & 15) << 2];
				result += "=";
			} else {
				result += BASE64_CHARS$2[(bytes[i] & 3) << 4];
				result += "==";
			}
		}
		return result;
	}
	function base64ToArrayBuffer$2(base64) {
		const clean = String(base64 || "").replace(/[\r\n\s]/g, "");
		if (!clean) return /* @__PURE__ */ new ArrayBuffer(0);
		const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
		const length = clean.length * 3 / 4 - padding;
		const bytes = new Uint8Array(length);
		let byteIndex = 0;
		for (let i = 0; i < clean.length; i += 4) {
			const c1 = BASE64_LOOKUP$2[clean[i]];
			const c2 = BASE64_LOOKUP$2[clean[i + 1]];
			const c3 = clean[i + 2] === "=" ? 0 : BASE64_LOOKUP$2[clean[i + 2]];
			const c4 = clean[i + 3] === "=" ? 0 : BASE64_LOOKUP$2[clean[i + 3]];
			if (byteIndex < length) bytes[byteIndex++] = c1 << 2 | c2 >> 4;
			if (byteIndex < length) bytes[byteIndex++] = (c2 & 15) << 4 | c3 >> 2;
			if (byteIndex < length) bytes[byteIndex++] = (c3 & 3) << 6 | c4;
		}
		return bytes.buffer;
	}
	function encodeFileData(data) {
		const buffer = toArrayBuffer$2(data);
		if (!buffer) return data;
		return {
			[FILE_DATA_TYPE_KEY]: "base64",
			[FILE_DATA_BASE64_KEY]: arrayBufferToBase64$2(buffer)
		};
	}
	function normalizeWriteOptions(opts, keys = ["data", "arrayBuffer"]) {
		if (!opts || typeof opts !== "object") return opts;
		const next = { ...opts };
		for (const key of keys) if (key in next) next[key] = encodeFileData(next[key]);
		return next;
	}
	function decodeArrayBufferPayload(value) {
		if (value && typeof value === "object" && value[ARRAY_BUFFER_BASE64_KEY$2] !== void 0) return base64ToArrayBuffer$2(value[ARRAY_BUFFER_BASE64_KEY$2]);
		return value;
	}
	function normalizeReadFileResult(res) {
		if (res && typeof res === "object" && res.data !== void 0) return {
			...res,
			data: decodeArrayBufferPayload(res.data)
		};
		return res;
	}
	function normalizeReadZipEntryResult(res) {
		if (!res || typeof res !== "object" || !res.entries || typeof res.entries !== "object") return res;
		const entries = {};
		for (const [path, item] of Object.entries(res.entries)) if (item && typeof item === "object" && item.data !== void 0) entries[path] = {
			...item,
			data: decodeArrayBufferPayload(item.data)
		};
		else entries[path] = item;
		return {
			...res,
			entries
		};
	}
	function fillReadArrayBuffer(res, arrayBuffer, offset = 0) {
		if (!res || typeof res !== "object" || !arrayBuffer || res[ARRAY_BUFFER_BASE64_KEY$2] === void 0) return res;
		const data = new Uint8Array(base64ToArrayBuffer$2(res[ARRAY_BUFFER_BASE64_KEY$2]));
		new Uint8Array(arrayBuffer).set(data, offset);
		const { [ARRAY_BUFFER_BASE64_KEY$2]: _, ...rest } = res;
		return {
			...rest,
			arrayBuffer
		};
	}
	function normalizeReadOptions(opts) {
		const next = { ...opts };
		const buffer = toArrayBuffer$2(opts?.arrayBuffer);
		if (buffer) {
			next.arrayBufferLength = buffer.byteLength;
			delete next.arrayBuffer;
		}
		return next;
	}
	var Stats = class {
		constructor(raw = {}) {
			this.mode = raw.mode;
			this.size = raw.size;
			this.lastAccessedTime = raw.lastAccessedTime;
			this.lastModifiedTime = raw.lastModifiedTime;
			this._isDirectory = !!raw.isDirectory;
			this._isFile = !!raw.isFile;
		}
		isDirectory() {
			return this._isDirectory;
		}
		isFile() {
			return this._isFile;
		}
	};
	function isStatsLike(value) {
		return value && typeof value === "object" && typeof value.size === "number" && Object.prototype.hasOwnProperty.call(value, "isDirectory") && Object.prototype.hasOwnProperty.call(value, "isFile");
	}
	function hydrateStats(value) {
		if (!value || typeof value !== "object") return value;
		if (typeof value.isDirectory === "function" && typeof value.isFile === "function") return value;
		if (isStatsLike(value)) return new Stats(value);
		if (Array.isArray(value)) return value.map((item) => hydrateStats(item));
		const next = {};
		for (const [key, item] of Object.entries(value)) next[key] = hydrateStats(item);
		return next;
	}
	function normalizeStatsResult(res) {
		if (res && typeof res === "object") {
			if (res.stats !== void 0) return {
				...res,
				stats: hydrateStats(res.stats)
			};
			if (res.statsMap !== void 0) return {
				...res,
				statsMap: hydrateStats(res.statsMap)
			};
		}
		return hydrateStats(res);
	}
	function withSuccessTransform(opts, transform) {
		if (!opts || typeof opts !== "object") return opts;
		const next = { ...opts };
		if (typeof opts.success === "function") next.success = (res) => opts.success(transform(res));
		if (typeof opts.complete === "function") next.complete = (res) => opts.complete(transform(res));
		return next;
	}
	function invokeFileAPI(name, opts, { transform = (res) => res, prepare = (data) => data } = {}) {
		const result = invokeAPI(name, prepare(withSuccessTransform(opts, transform)));
		if (result && typeof result.then === "function") return result.then(transform);
		return result;
	}
	function invokeReadAPI(name, opts) {
		const arrayBuffer = opts?.arrayBuffer;
		const offset = opts?.offset || 0;
		return invokeFileAPI(name, opts, {
			prepare: normalizeReadOptions,
			transform: (res) => fillReadArrayBuffer(res, arrayBuffer, offset)
		});
	}
	/**
	* 文件系统管理器
	* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.html
	*/
	var FileSystemManager = class {
		/**
		* 判断文件/目录是否存在
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.access.html
		*/
		access(opts) {
			return invokeFileAPI("FileSystemManager.access", opts);
		}
		/**
		* 同步判断文件/目录是否存在
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.accessSync.html
		*/
		accessSync(path) {
			return invokeAPI("FileSystemManager.accessSync", path);
		}
		/**
		* 在文件结尾追加内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.appendFile.html
		*/
		appendFile(opts) {
			return invokeFileAPI("FileSystemManager.appendFile", opts, { prepare: normalizeWriteOptions });
		}
		/**
		* 同步在文件结尾追加内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.appendFileSync.html
		*/
		appendFileSync(filePath, data, encoding) {
			return invokeAPI("FileSystemManager.appendFileSync", normalizeWriteOptions({
				filePath,
				data,
				encoding
			}));
		}
		/**
		* 关闭文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.close.html
		*/
		close(opts) {
			return invokeFileAPI("FileSystemManager.close", opts);
		}
		/**
		* 同步关闭文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.closeSync.html
		*/
		closeSync(opts) {
			return invokeAPI("FileSystemManager.closeSync", opts);
		}
		/**
		* 复制文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.copyFile.html
		*/
		copyFile(opts) {
			return invokeFileAPI("FileSystemManager.copyFile", opts);
		}
		/**
		* 同步复制文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.copyFileSync.html
		*/
		copyFileSync(srcPath, destPath) {
			return invokeAPI("FileSystemManager.copyFileSync", {
				srcPath,
				destPath
			});
		}
		/**
		* 获取文件的状态信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.fstat.html
		*/
		fstat(opts) {
			return invokeFileAPI("FileSystemManager.fstat", opts, { transform: normalizeStatsResult });
		}
		/**
		* 同步获取文件的状态信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.fstatSync.html
		*/
		fstatSync(opts) {
			return normalizeStatsResult(invokeAPI("FileSystemManager.fstatSync", opts));
		}
		/**
		* 对文件内容进行截断操作
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.ftruncate.html
		*/
		ftruncate(opts) {
			return invokeFileAPI("FileSystemManager.ftruncate", opts);
		}
		/**
		* 对文件内容进行截断操作(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.ftruncateSync.html
		*/
		ftruncateSync(opts) {
			return invokeAPI("FileSystemManager.ftruncateSync", opts);
		}
		/**
		* 获取该小程序下的本地临时文件或本地缓存文件信息
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.getFileInfo.html
		*/
		getFileInfo(opts) {
			return invokeFileAPI("FileSystemManager.getFileInfo", opts);
		}
		/**
		* 获取该小程序下已保存的本地缓存文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.getSavedFileList.html
		*/
		getSavedFileList(opts) {
			return invokeFileAPI("FileSystemManager.getSavedFileList", opts || {});
		}
		/**
		* 创建目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.mkdir.html
		*/
		mkdir(opts) {
			return invokeFileAPI("FileSystemManager.mkdir", opts);
		}
		/**
		* 同步创建目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.mkdirSync.html
		*/
		mkdirSync(dirPath, recursive) {
			return invokeAPI("FileSystemManager.mkdirSync", {
				dirPath,
				recursive
			});
		}
		/**
		* 打开文件,返回文件描述符
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.open.html
		*/
		open(opts) {
			return invokeFileAPI("FileSystemManager.open", opts);
		}
		/**
		* 同步打开文件,返回文件描述符
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.openSync.html
		*/
		openSync(opts) {
			return invokeAPI("FileSystemManager.openSync", opts);
		}
		/**
		* 读文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.read.html
		*/
		read(opts) {
			return invokeReadAPI("FileSystemManager.read", opts);
		}
		/**
		* 读文件(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readSync.html
		*/
		readSync(opts) {
			return fillReadArrayBuffer(invokeAPI("FileSystemManager.readSync", normalizeReadOptions(opts)), opts?.arrayBuffer, opts?.offset || 0);
		}
		/**
		* 读取指定压缩类型的本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readCompressedFile.html
		*/
		readCompressedFile(opts) {
			return invokeFileAPI("FileSystemManager.readCompressedFile", opts, { transform: normalizeReadFileResult });
		}
		/**
		* 同步读取指定压缩类型的本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readCompressedFileSync.html
		*/
		readCompressedFileSync(opts) {
			return decodeArrayBufferPayload(invokeAPI("FileSystemManager.readCompressedFileSync", opts));
		}
		/**
		* 读取目录内文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readdir.html
		*/
		readdir(opts) {
			return invokeFileAPI("FileSystemManager.readdir", opts);
		}
		/**
		* 同步读取目录内文件列表
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readdirSync.html
		*/
		readdirSync(dirPath) {
			return invokeAPI("FileSystemManager.readdirSync", dirPath);
		}
		/**
		* 读取本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readFile.html
		*/
		readFile(opts) {
			return invokeFileAPI("FileSystemManager.readFile", opts, { transform: normalizeReadFileResult });
		}
		/**
		* 同步读取本地文件内容
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readFileSync.html
		*/
		readFileSync(filePath, encoding, position, length) {
			return decodeArrayBufferPayload(invokeAPI("FileSystemManager.readFileSync", {
				filePath,
				encoding,
				position,
				length
			}));
		}
		/**
		* 读取压缩包内的文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.readZipEntry.html
		*/
		readZipEntry(opts) {
			return invokeFileAPI("FileSystemManager.readZipEntry", opts, { transform: normalizeReadZipEntryResult });
		}
		/**
		* 删除该小程序下已保存的本地缓存文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.removeSavedFile.html
		*/
		removeSavedFile(opts) {
			return invokeFileAPI("FileSystemManager.removeSavedFile", opts);
		}
		/**
		* 重命名文件。可以把文件从 oldPath 移动到 newPath
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rename.html
		*/
		rename(opts) {
			return invokeFileAPI("FileSystemManager.rename", opts);
		}
		/**
		* 同步重命名文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.renameSync.html
		*/
		renameSync(oldPath, newPath) {
			return invokeAPI("FileSystemManager.renameSync", {
				oldPath,
				newPath
			});
		}
		/**
		* 删除目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rmdir.html
		*/
		rmdir(opts) {
			return invokeFileAPI("FileSystemManager.rmdir", opts);
		}
		/**
		* 同步删除目录
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.rmdirSync.html
		*/
		rmdirSync(dirPath, recursive) {
			return invokeAPI("FileSystemManager.rmdirSync", {
				dirPath,
				recursive
			});
		}
		/**
		* 保存临时文件到本地
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.saveFile.html
		*/
		saveFile(opts) {
			return invokeFileAPI("FileSystemManager.saveFile", opts);
		}
		/**
		* 同步保存临时文件到本地
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.saveFileSync.html
		*/
		saveFileSync(tempFilePath, filePath) {
			return invokeAPI("FileSystemManager.saveFileSync", {
				tempFilePath,
				filePath
			});
		}
		/**
		* 获取文件 Stats 对象
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.stat.html
		*/
		stat(opts) {
			return invokeFileAPI("FileSystemManager.stat", opts, { transform: normalizeStatsResult });
		}
		/**
		* 同步获取文件 Stats 对象
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.statSync.html
		*/
		statSync(path, recursive) {
			return normalizeStatsResult(invokeAPI("FileSystemManager.statSync", {
				path,
				recursive
			}));
		}
		/**
		* 对文件内容进行截断操作
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.truncate.html
		*/
		truncate(opts) {
			return invokeFileAPI("FileSystemManager.truncate", opts);
		}
		/**
		* 对文件内容进行截断操作(同步)
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.truncateSync.html
		*/
		truncateSync(filePath, length) {
			return invokeAPI("FileSystemManager.truncateSync", {
				filePath,
				length
			});
		}
		/**
		* 删除文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unlink.html
		*/
		unlink(opts) {
			return invokeFileAPI("FileSystemManager.unlink", opts);
		}
		/**
		* 同步删除文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unlinkSync.html
		*/
		unlinkSync(filePath) {
			return invokeAPI("FileSystemManager.unlinkSync", filePath);
		}
		/**
		* 解压文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.unzip.html
		*/
		unzip(opts) {
			return invokeFileAPI("FileSystemManager.unzip", opts);
		}
		/**
		* 写入文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.write.html
		*/
		write(opts) {
			return invokeFileAPI("FileSystemManager.write", opts, { prepare: (data) => normalizeWriteOptions(data, ["arrayBuffer", "data"]) });
		}
		/**
		* 同步写入文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeSync.html
		*/
		writeSync(opts) {
			return invokeAPI("FileSystemManager.writeSync", normalizeWriteOptions(opts, ["arrayBuffer", "data"]));
		}
		/**
		* 写文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeFile.html
		*/
		writeFile(opts) {
			return invokeFileAPI("FileSystemManager.writeFile", opts, { prepare: normalizeWriteOptions });
		}
		/**
		* 同步写文件
		* https://developers.weixin.qq.com/miniprogram/dev/api/file/FileSystemManager.writeFileSync.html
		*/
		writeFileSync(filePath, data, encoding) {
			return invokeAPI("FileSystemManager.writeFileSync", normalizeWriteOptions({
				filePath,
				data,
				encoding
			}));
		}
	};
	var fileSystemManagerAPINames = Object.getOwnPropertyNames(FileSystemManager.prototype).filter((name) => name !== "constructor");
	var fileSystemManagerInstance = null;
	/**
	* 获取全局唯一的文件管理器
	* https://developers.weixin.qq.com/miniprogram/dev/api/file/wx.getFileSystemManager.html
	*/
	function getFileSystemManager() {
		if (!fileSystemManagerInstance) fileSystemManagerInstance = new FileSystemManager();
		return fileSystemManagerInstance;
	}
	//#endregion
	//#region src/api/core/base/update/api-names.js
	var updateManagerAPINames = [
		"applyUpdate",
		"onCheckForUpdate",
		"onUpdateFailed",
		"onUpdateReady"
	];
	//#endregion
	//#region src/api/core/base/index.js
	var base_exports = /* @__PURE__ */ __exportAll({
		canIUse: () => canIUse,
		env: () => env
	});
	/**
	* 环境变量
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/wx.env.html
	*/
	var env = { USER_DATA_PATH: "difile://usr" };
	var builtInAPIs = /* @__PURE__ */ new Set([
		"nextTick",
		"getUpdateManager",
		"UpdateManager",
		...updateManagerAPINames.map((name) => `UpdateManager.${name}`),
		"getPerformance",
		"getFileSystemManager",
		"FileSystemManager",
		...fileSystemManagerAPINames.map((name) => `FileSystemManager.${name}`)
	]);
	var nativeBackedFactorySchemas = {
		createUDPSocket: "UDPSocket.bind",
		UDPSocket: "UDPSocket.bind",
		createTCPSocket: "TCPSocket.connect",
		TCPSocket: "TCPSocket.connect"
	};
	/**
	* 判断小程序的API，回调，参数，组件等是否在当前版本可用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/wx.canIUse.html
	*/
	function canIUse(schema) {
		if (builtInAPIs.has(schema)) return true;
		try {
			return invokeAPI("canIUse", Object.hasOwn(nativeBackedFactorySchemas, schema) ? nativeBackedFactorySchemas[schema] : schema) === true;
		} catch (error) {
			console.warn(`[canIUse] check ${schema} error:`, error);
			return false;
		}
	}
	//#endregion
	//#region src/api/core/base/performance/index.js
	var performance_exports = /* @__PURE__ */ __exportAll({ getPerformance: () => getPerformance });
	/**
	* 获取当前小程序性能相关的信息。关于小程序启动性能优化的更多内容，请参考启动性能指南。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/performance/wx.getPerformance.html
	*/
	function getPerformance() {
		return Performance.getInstance();
	}
	var Performance = class Performance {
		static #instance = null;
		constructor() {
			if (Performance.#instance) throw new Error("Cannot instantiate more than one Performance instance.");
			this.entryList = new EntryList();
			Performance.#instance = this;
		}
		static getInstance() {
			if (!Performance.#instance) Performance.#instance = new Performance();
			return Performance.#instance;
		}
		createObserver(listener) {
			return new Observer(this, listener);
		}
		getEntries() {
			return this.entryList.getEntries();
		}
		getEntriesByName(name, entryType) {
			return this.entryList.getEntriesByName(name, entryType);
		}
		getEntriesByType(entryType) {
			return this.entryList.getEntriesByType(entryType);
		}
		setBufferSize(size) {
			this.entryList.maxEntrySize = size;
		}
	};
	var EntryList = class {
		constructor() {
			this._list = [];
			this.maxEntrySize = 30;
		}
		push(entries) {
			for (const entry of entries) {
				if (this._list.length >= this.maxEntrySize) this._list.shift();
				this._list.push(entry);
			}
		}
		getEntriesByName(name, entryType) {
			return this._entryFilter(name, entryType);
		}
		getEntriesByType(entryType) {
			return this._entryFilter(null, entryType);
		}
		_entryFilter(name, entryType) {
			return this._list.filter((entry) => {
				if (name && name !== entry.name) return false;
				if (entryType && entryType !== entry.entryType) return false;
				return true;
			});
		}
		getEntries() {
			return this._list;
		}
	};
	var Observer = class {
		constructor(performance, listener) {
			this.performance = performance;
			this.entryTypes = [];
			this.callback = listener;
			this.observerId = null;
			this.callbackId = null;
			this.connected = false;
		}
		observe(options = {}) {
			this.disconnect();
			this.connected = true;
			this.entryTypes = Array.isArray(options.entryTypes) ? options.entryTypes : [];
			this.callbackId = callback_default.store((res = {}) => {
				if (res.observerId) {
					this.observerId = res.observerId;
					if (!this.connected) {
						invokeAPI("removePerformanceObserver", { observerId: res.observerId }, "render");
						callback_default.remove(this.callbackId);
						this.callbackId = null;
						return;
					}
				}
				const list = res?.data?.entryList ? JSON.parse(res.data.entryList) : [];
				if (this.connected && list.length > 0) {
					this.performance.entryList.push(list);
					this.notify(list);
				}
			}, true);
			invokeAPI("addPerformanceObserver", {
				entryTypes: this.entryTypes,
				success: this.callbackId
			}, "render");
		}
		notify(data) {
			if (this.connected) {
				const entryList = new EntryList();
				entryList.push(data.filter((entry) => {
					let flag = false;
					if (this.entryTypes && this.entryTypes.length > 0) this.entryTypes.forEach((value) => {
						if (entry.entryType === value) flag = true;
					});
					return flag;
				}));
				if (typeof this.callback === "function") this.callback(entryList);
			}
		}
		disconnect() {
			this.connected = false;
			if (this.observerId) invokeAPI("removePerformanceObserver", { observerId: this.observerId }, "render");
			if (this.callbackId && this.observerId) callback_default.remove(this.callbackId);
			this.observerId = null;
			this.callbackId = null;
		}
	};
	//#endregion
	//#region src/api/core/base/subpackage/index.js
	var subpackage_exports = /* @__PURE__ */ __exportAll({
		loadSubpackage: () => loadSubpackage,
		preDownloadSubpackage: () => preDownloadSubpackage
	});
	/**
	* 触发分包预下载，只下载代码包，不自动执行代码
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/subpackage/wx.preDownloadSubpackage.html
	*/
	function preDownloadSubpackage(opts) {
		return invokeAPI("preDownloadSubpackage", opts);
	}
	/**
	* 触发分包加载
	* https://developers.weixin.qq.com/minigame/dev/api/base/subpackage/wx.loadSubpackage.html
	*/
	function loadSubpackage(opts) {
		return invokeAPI("loadSubpackage", opts);
	}
	//#endregion
	//#region src/api/core/base/system/index.js
	var system_exports = /* @__PURE__ */ __exportAll({
		getAppBaseInfo: () => getAppBaseInfo,
		getDeviceInfo: () => getDeviceInfo,
		getSystemInfo: () => getSystemInfo,
		getSystemInfoAsync: () => getSystemInfoAsync,
		getSystemInfoSync: () => getSystemInfoSync,
		getWindowInfo: () => getWindowInfo,
		offThemeChange: () => offThemeChange,
		onThemeChange: () => onThemeChange,
		openAppAuthorizeSetting: () => openAppAuthorizeSetting,
		openSystemBluetoothSetting: () => openSystemBluetoothSetting
	});
	var themeChangeCallbacks = /* @__PURE__ */ new Set();
	host_env_default.onUpdate((patch) => {
		const theme = patch.systemInfo?.theme;
		if (!theme) return;
		themeChangeCallbacks.forEach((callback) => callback({ theme }));
	});
	/**
	* 跳转系统蓝牙设置页。仅支持安卓
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.openSystemBluetoothSetting.html
	*/
	function openSystemBluetoothSetting(opts) {
		return invokeAPI("openSystemBluetoothSetting", opts);
	}
	/**
	* 获取窗口信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getWindowInfo.html
	*/
	function getWindowInfo(opts) {
		return invokeAPI("getWindowInfo", opts);
	}
	/**
	* 跳转系统授权管理页
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.openAppAuthorizeSetting.html
	*/
	function openAppAuthorizeSetting(opts) {
		return invokeAPI("openAppAuthorizeSetting", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfo.html
	*/
	function getSystemInfo(opts) {
		return new Promise((resolve) => {
			resolve(invokeAPI("getSystemInfo", opts));
		});
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfoSync.html
	*/
	function getSystemInfoSync() {
		return invokeAPI("getSystemInfoSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/system/wx.getSystemInfoAsync.html
	*/
	function getSystemInfoAsync(opts) {
		return invokeAPI("getSystemInfoAsync", opts);
	}
	function getAppBaseInfo() {
		return invokeAPI("getAppBaseInfo");
	}
	function getDeviceInfo() {
		return invokeAPI("getDeviceInfo");
	}
	function onThemeChange(callback) {
		if (isFunction(callback)) themeChangeCallbacks.add(callback);
	}
	function offThemeChange(callback) {
		if (isFunction(callback)) themeChangeCallbacks.delete(callback);
		else themeChangeCallbacks.clear();
	}
	//#endregion
	//#region src/api/core/base/update/index.js
	var update_exports = /* @__PURE__ */ __exportAll({ getUpdateManager: () => getUpdateManager });
	var UPDATE_STATUS_EVENT = "onUpdateStatusChange";
	var EVENT_UPDATE_FAILED = "updatefail";
	var EVENT_UPDATE_READY = "updateready";
	var EVENT_NO_UPDATE = "noupdate";
	var EVENT_UPDATING = "updating";
	/**
	* 获取全局唯一的版本更新管理器，用于管理小程序更新。关于小程序的更新机制，可以查看运行机制文档。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/wx.getUpdateManager.html
	*/
	function getUpdateManager() {
		return UpdateManager.getInstance();
	}
	var UpdateManager = class UpdateManager {
		static #instance = null;
		constructor() {
			if (UpdateManager.#instance) throw new Error("Cannot instantiate more than one UpdateManager instance.");
			this.hasAppliedUpdate = false;
			this.updateFailed = false;
			this.updateReady = false;
			this.checkForUpdateResult = null;
			this.updateFailedListeners = [];
			this.updateReadyListeners = [];
			this.checkForUpdateListeners = [];
			message_default.on(UPDATE_STATUS_EVENT, (msg) => this.handleUpdateStatusChange(msg));
			UpdateManager.#instance = this;
		}
		handleUpdateStatusChange(msg = {}) {
			const { event } = msg;
			if (event === EVENT_UPDATE_FAILED) {
				this.updateFailed = true;
				this.emit(this.updateFailedListeners);
				return;
			}
			if (event === EVENT_UPDATE_READY) {
				const shouldEmitCheck = this.checkForUpdateResult?.hasUpdate !== true;
				const shouldEmitReady = !this.updateReady;
				this.updateReady = true;
				this.checkForUpdateResult = { hasUpdate: true };
				if (shouldEmitCheck) this.emit(this.checkForUpdateListeners, this.checkForUpdateResult);
				if (shouldEmitReady) this.emit(this.updateReadyListeners);
				return;
			}
			if (event === EVENT_UPDATING) {
				this.checkForUpdateResult = { hasUpdate: true };
				this.emit(this.checkForUpdateListeners, this.checkForUpdateResult);
				return;
			}
			if (event === EVENT_NO_UPDATE) {
				this.checkForUpdateResult = { hasUpdate: false };
				this.emit(this.checkForUpdateListeners, this.checkForUpdateResult);
				return;
			}
			if (typeof msg.hasUpdate === "boolean") {
				this.checkForUpdateResult = { hasUpdate: msg.hasUpdate };
				this.emit(this.checkForUpdateListeners, this.checkForUpdateResult);
			}
		}
		emit(listeners, ...args) {
			listeners.slice().forEach((cb) => {
				cb(...args);
			});
		}
		static getInstance() {
			if (!UpdateManager.#instance) UpdateManager.#instance = new UpdateManager();
			return UpdateManager.#instance;
		}
		/**
		* 强制小程序重启并使用新版本。在小程序新版本下载完成后（即收到 onUpdateReady 回调）调用。
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.applyUpdate.html
		*/
		applyUpdate() {
			if (!this.updateReady) console.error("[applyUpdate]: update is not ready");
			else if (this.hasAppliedUpdate) console.error("[applyUpdate]: applyUpdate has been called");
			else {
				this.hasAppliedUpdate = true;
				return invokeAPI("applyUpdate");
			}
		}
		/**
		* 监听向微信后台请求检查更新结果事件。微信在小程序每次启动（包括热启动）时自动检查更新，不需由开发者主动触发。
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onCheckForUpdate.html
		*/
		onCheckForUpdate(cb) {
			if (typeof cb !== "function") return;
			this.checkForUpdateListeners.push(cb);
			if (this.checkForUpdateResult) cb(this.checkForUpdateResult);
		}
		/**
		* 监听小程序更新失败事件。小程序有新版本，客户端主动触发下载（无需开发者触发），下载失败（可能是网络原因等）后回调
		* https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateFailed.html
		*/
		onUpdateFailed(cb) {
			if (typeof cb !== "function") return;
			this.updateFailedListeners.push(cb);
			if (this.updateFailed) cb();
		}
		/**
		* 监听小程序有版本更新事件。客户端主动触发下载（无需开发者触发），下载成功后回调
		*	https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateReady.html
		*/
		onUpdateReady(cb) {
			if (typeof cb !== "function") return;
			this.updateReadyListeners.push(cb);
			if (this.updateReady) cb();
		}
	};
	UpdateManager.getInstance();
	//#endregion
	//#region src/api/core/camera/index.js
	var camera_exports = /* @__PURE__ */ __exportAll({ createCameraContext: () => createCameraContext });
	function createCameraContext() {
		return new CameraContext();
	}
	var CameraContext = class {
		takePhoto(data = {}) {
			return invokeAPI("takePhoto", data);
		}
		startRecord(data = {}) {
			return invokeAPI("startRecordCamera", data);
		}
		stopRecord(data = {}) {
			return invokeAPI("stopRecordCamera", data);
		}
	};
	//#endregion
	//#region src/api/core/data-analysis/index.js
	var data_analysis_exports = /* @__PURE__ */ __exportAll({
		reportAnalytics: () => reportAnalytics,
		reportEvent: () => reportEvent
	});
	/**
	* 自定义分析数据上报接口。使用前，需要在小程序管理后台自定义分析中新建事件，配置好事件名与字段。
	* https://developers.weixin.qq.com/miniprogram/dev/api/data-analysis/wx.reportAnalytics.html
	*/
	function reportAnalytics(...opts) {
		return invokeAPI("reportAnalytics", opts);
	}
	function reportEvent(eventId, data) {
		return invokeAPI("reportAnalytics", {
			eventId,
			data
		});
	}
	//#endregion
	//#region src/api/core/device/bluetooth/shared.js
	var ARRAY_BUFFER_BASE64_KEY$1 = "__diminaArrayBufferBase64";
	var BASE64_CHARS$1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	var BASE64_LOOKUP$1 = (() => {
		const lookup = {};
		for (let i = 0; i < 64; i++) lookup[BASE64_CHARS$1[i]] = i;
		return lookup;
	})();
	function isArrayBuffer$1(value) {
		return Object.prototype.toString.call(value) === "[object ArrayBuffer]";
	}
	function toArrayBuffer$1(value) {
		if (isArrayBuffer$1(value)) return value;
		if (value && value.buffer && isArrayBuffer$1(value.buffer)) return value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength);
		return null;
	}
	function arrayBufferToBase64$1(buffer) {
		const bytes = new Uint8Array(buffer);
		let result = "";
		let i = 0;
		for (; i + 2 < bytes.length; i += 3) {
			result += BASE64_CHARS$1[bytes[i] >> 2];
			result += BASE64_CHARS$1[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
			result += BASE64_CHARS$1[(bytes[i + 1] & 15) << 2 | bytes[i + 2] >> 6];
			result += BASE64_CHARS$1[bytes[i + 2] & 63];
		}
		if (i < bytes.length) {
			result += BASE64_CHARS$1[bytes[i] >> 2];
			if (i + 1 < bytes.length) {
				result += BASE64_CHARS$1[(bytes[i] & 3) << 4 | bytes[i + 1] >> 4];
				result += `${BASE64_CHARS$1[(bytes[i + 1] & 15) << 2]}=`;
			} else result += `${BASE64_CHARS$1[(bytes[i] & 3) << 4]}==`;
		}
		return result;
	}
	function base64ToArrayBuffer$1(base64) {
		const clean = String(base64 || "").replace(/[\r\n\s]/g, "");
		if (!clean) return /* @__PURE__ */ new ArrayBuffer(0);
		const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
		const length = clean.length * 3 / 4 - padding;
		const bytes = new Uint8Array(length);
		let byteIndex = 0;
		for (let i = 0; i < clean.length; i += 4) {
			const c1 = BASE64_LOOKUP$1[clean[i]];
			const c2 = BASE64_LOOKUP$1[clean[i + 1]];
			const c3 = clean[i + 2] === "=" ? 0 : BASE64_LOOKUP$1[clean[i + 2]];
			const c4 = clean[i + 3] === "=" ? 0 : BASE64_LOOKUP$1[clean[i + 3]];
			if (byteIndex < length) bytes[byteIndex++] = c1 << 2 | c2 >> 4;
			if (byteIndex < length) bytes[byteIndex++] = (c2 & 15) << 4 | c3 >> 2;
			if (byteIndex < length) bytes[byteIndex++] = (c3 & 3) << 6 | c4;
		}
		return bytes.buffer;
	}
	function encodeArrayBuffer(value) {
		const buffer = toArrayBuffer$1(value);
		if (!buffer) return value;
		return { [ARRAY_BUFFER_BASE64_KEY$1]: arrayBufferToBase64$1(buffer) };
	}
	function decodeArrayBuffer(value) {
		if (value && typeof value === "object" && value["__diminaArrayBufferBase64"] !== void 0) return base64ToArrayBuffer$1(value[ARRAY_BUFFER_BASE64_KEY$1]);
		return value;
	}
	function normalizeBluetoothDevice(device) {
		if (!device || typeof device !== "object") return device;
		const serviceData = {};
		for (const [uuid, value] of Object.entries(device.serviceData || {})) serviceData[uuid] = decodeArrayBuffer(value);
		return {
			...device,
			advertisData: decodeArrayBuffer(device.advertisData),
			serviceData
		};
	}
	function normalizeDeviceResult(result) {
		if (!result || !Array.isArray(result.devices)) return result;
		return {
			...result,
			devices: result.devices.map(normalizeBluetoothDevice)
		};
	}
	function normalizeCharacteristicResult(result) {
		if (!result || typeof result !== "object") return result;
		return {
			...result,
			value: decodeArrayBuffer(result.value)
		};
	}
	function withResultTransform(opts, transform) {
		if (!opts || typeof opts !== "object") return opts;
		const next = { ...opts };
		if (typeof opts.success === "function") next.success = (result) => opts.success(transform(result));
		if (typeof opts.complete === "function") next.complete = (result) => opts.complete(transform(result));
		return next;
	}
	function invokeBluetoothAPI(name, opts, { prepare = (value) => value, transform = (value) => value } = {}) {
		const result = invokeAPI(name, prepare(withResultTransform(opts, transform)));
		if (result && typeof result.then === "function") return result.then(transform);
		return result;
	}
	function createBluetoothEvent(onName, offName, transform = (value) => value) {
		const listeners = /* @__PURE__ */ new Map();
		return {
			on(listener) {
				if (typeof listener !== "function" || listeners.has(listener)) return;
				const wrapped = (value) => listener(transform(value));
				const callbackId = callback_default.store(wrapped, true);
				listeners.set(listener, callbackId);
				return invokeAPI(onName, {
					callbackId,
					success: callbackId,
					keep: true
				});
			},
			off(listener) {
				if (typeof listener === "function") {
					const callbackId = listeners.get(listener);
					if (!callbackId) return;
					listeners.delete(listener);
					callback_default.remove(callbackId);
					return invokeAPI(offName, {
						callbackId,
						keep: true
					});
				}
				for (const callbackId of listeners.values()) callback_default.remove(callbackId);
				listeners.clear();
				return invokeAPI(offName);
			}
		};
	}
	//#endregion
	//#region src/api/core/device/bluetooth/index.js
	var bluetooth_exports = /* @__PURE__ */ __exportAll({
		closeBluetoothAdapter: () => closeBluetoothAdapter,
		getBluetoothAdapterState: () => getBluetoothAdapterState,
		getBluetoothDevices: () => getBluetoothDevices,
		getConnectedBluetoothDevices: () => getConnectedBluetoothDevices,
		isBluetoothDevicePaired: () => isBluetoothDevicePaired,
		makeBluetoothPair: () => makeBluetoothPair,
		offBluetoothAdapterStateChange: () => offBluetoothAdapterStateChange,
		offBluetoothDeviceFound: () => offBluetoothDeviceFound,
		onBluetoothAdapterStateChange: () => onBluetoothAdapterStateChange,
		onBluetoothDeviceFound: () => onBluetoothDeviceFound,
		openBluetoothAdapter: () => openBluetoothAdapter,
		startBluetoothDevicesDiscovery: () => startBluetoothDevicesDiscovery,
		stopBluetoothDevicesDiscovery: () => stopBluetoothDevicesDiscovery
	});
	var deviceFoundEvent = createBluetoothEvent("onBluetoothDeviceFound", "offBluetoothDeviceFound", normalizeDeviceResult);
	var adapterStateEvent = createBluetoothEvent("onBluetoothAdapterStateChange", "offBluetoothAdapterStateChange");
	/**
	* 停止搜寻附近的蓝牙外围设备。若已经找到需要的蓝牙设备并不需要继续搜索时，建议调用该接口停止蓝牙搜索。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.stopBluetoothDevicesDiscovery.html
	*/
	function stopBluetoothDevicesDiscovery(opts) {
		return invokeAPI("stopBluetoothDevicesDiscovery", opts);
	}
	/**
	* 开始搜寻附近的蓝牙外围设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.startBluetoothDevicesDiscovery.html
	*/
	function startBluetoothDevicesDiscovery(opts) {
		return invokeAPI("startBluetoothDevicesDiscovery", opts);
	}
	/**
	* 初始化蓝牙模块。iOS 上开启主机/从机（外围设备）模式时需分别调用一次，并指定对应的 mode。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.openBluetoothAdapter.html
	*/
	function openBluetoothAdapter(opts) {
		return invokeAPI("openBluetoothAdapter", opts);
	}
	/**
	* 监听搜索到新设备的事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.onBluetoothDeviceFound.html
	*/
	function onBluetoothDeviceFound(listener) {
		return deviceFoundEvent.on(listener);
	}
	/**
	* 监听蓝牙适配器状态变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.onBluetoothAdapterStateChange.html
	*/
	function onBluetoothAdapterStateChange(listener) {
		return adapterStateEvent.on(listener);
	}
	/**
	* 移除搜索到新设备的事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.offBluetoothDeviceFound.html
	*/
	function offBluetoothDeviceFound(listener) {
		return deviceFoundEvent.off(listener);
	}
	/**
	* 移除蓝牙适配器状态变化事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.offBluetoothAdapterStateChange.html
	*/
	function offBluetoothAdapterStateChange(listener) {
		return adapterStateEvent.off(listener);
	}
	/**
	* 根据主服务 UUID 获取已连接的蓝牙设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getConnectedBluetoothDevices.html
	*/
	function getConnectedBluetoothDevices(opts) {
		return invokeBluetoothAPI("getConnectedBluetoothDevices", opts, { transform: normalizeDeviceResult });
	}
	/**
	* 获取在蓝牙模块生效期间所有搜索到的蓝牙设备。包括已经和本机处于连接状态的设备
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getBluetoothDevices.html
	*/
	function getBluetoothDevices(opts) {
		return invokeBluetoothAPI("getBluetoothDevices", opts, { transform: normalizeDeviceResult });
	}
	/**
	* 获取本机蓝牙适配器状态
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.getBluetoothAdapterState.html
	*/
	function getBluetoothAdapterState(opts) {
		return invokeAPI("getBluetoothAdapterState", opts);
	}
	/**
	* 关闭蓝牙模块。调用该方法将断开所有已建立的连接并释放系统资源。建议在使用蓝牙流程后，与 wx.openBluetoothAdapter 成对调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.closeBluetoothAdapter.html
	*/
	function closeBluetoothAdapter(opts) {
		return invokeAPI("closeBluetoothAdapter", opts);
	}
	/**
	* 判断蓝牙设备是否已经配对。仅 Android 支持。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.isBluetoothDevicePaired.html
	*/
	function isBluetoothDevicePaired(opts) {
		return invokeAPI("isBluetoothDevicePaired", opts);
	}
	/**
	* 蓝牙配对接口。仅 Android 支持。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth/wx.makeBluetoothPair.html
	*/
	function makeBluetoothPair(opts) {
		return invokeAPI("makeBluetoothPair", opts);
	}
	//#endregion
	//#region src/api/core/device/bluetooth-ble/index.js
	var bluetooth_ble_exports = /* @__PURE__ */ __exportAll({
		closeBLEConnection: () => closeBLEConnection,
		createBLEConnection: () => createBLEConnection,
		getBLEDeviceCharacteristics: () => getBLEDeviceCharacteristics,
		getBLEDeviceRSSI: () => getBLEDeviceRSSI,
		getBLEDeviceServices: () => getBLEDeviceServices,
		getBLEMTU: () => getBLEMTU,
		notifyBLECharacteristicValueChange: () => notifyBLECharacteristicValueChange,
		offBLECharacteristicValueChange: () => offBLECharacteristicValueChange,
		offBLEConnectionStateChange: () => offBLEConnectionStateChange,
		offBLEMTUChange: () => offBLEMTUChange,
		onBLECharacteristicValueChange: () => onBLECharacteristicValueChange,
		onBLEConnectionStateChange: () => onBLEConnectionStateChange,
		onBLEMTUChange: () => onBLEMTUChange,
		readBLECharacteristicValue: () => readBLECharacteristicValue,
		setBLEMTU: () => setBLEMTU,
		writeBLECharacteristicValue: () => writeBLECharacteristicValue
	});
	var connectionStateEvent = createBluetoothEvent("onBLEConnectionStateChange", "offBLEConnectionStateChange");
	var characteristicValueEvent = createBluetoothEvent("onBLECharacteristicValueChange", "offBLECharacteristicValueChange", normalizeCharacteristicResult);
	var mtuEvent = createBluetoothEvent("onBLEMTUChange", "offBLEMTUChange");
	/**
	* 向蓝牙低功耗设备特征值中写入二进制数据。注意：必须设备的特征支持 write 才可以成功调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.writeBLECharacteristicValue.html
	*/
	function writeBLECharacteristicValue(opts) {
		return invokeBluetoothAPI("writeBLECharacteristicValue", opts, { prepare(data) {
			return data && typeof data === "object" ? {
				...data,
				value: encodeArrayBuffer(data.value)
			} : data;
		} });
	}
	/**
	* 协商设置蓝牙低功耗的最大传输单元 (Maximum Transmission Unit, MTU)。需在 wx.createBLEConnection 调用成功后调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.setBLEMTU.html
	*/
	function setBLEMTU(opts) {
		return invokeAPI("setBLEMTU", opts);
	}
	/**
	* 读取蓝牙低功耗设备特征值的二进制数据。注意：必须设备的特征支持 read 才可以成功调用。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.readBLECharacteristicValue.html
	*/
	function readBLECharacteristicValue(opts) {
		return invokeAPI("readBLECharacteristicValue", opts);
	}
	/**
	* 监听蓝牙低功耗连接状态改变事件。包括开发者主动连接或断开连接，设备丢失，连接异常断开等等
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.onBLEConnectionStateChange.html
	*/
	function onBLEConnectionStateChange(listener) {
		return connectionStateEvent.on(listener);
	}
	/**
	* 监听蓝牙低功耗设备的特征值变化事件。必须先调用 wx.notifyBLECharacteristicValueChange 接口才能接收到设备推送的 notification。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.onBLECharacteristicValueChange.html
	*/
	function onBLECharacteristicValueChange(listener) {
		return characteristicValueEvent.on(listener);
	}
	/**
	* 移除蓝牙低功耗连接状态改变事件的监听函数。不传此参数则移除所有监听函数。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.offBLEConnectionStateChange.html
	*/
	function offBLEConnectionStateChange(listener) {
		return connectionStateEvent.off(listener);
	}
	/**
	* 移除蓝牙低功耗设备的特征值变化事件的全部监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.offBLECharacteristicValueChange.html
	*/
	function offBLECharacteristicValueChange(listener) {
		return characteristicValueEvent.off(listener);
	}
	/**
	* 启用蓝牙低功耗设备特征值变化时的 notify 功能，订阅特征。注意：必须设备的特征支持 notify 或者 indicate 才可以成功调用。
	* 另外，必须先启用 wx.notifyBLECharacteristicValueChange 才能监听到设备 characteristicValueChange 事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.notifyBLECharacteristicValueChange.html
	*/
	function notifyBLECharacteristicValueChange(opts) {
		return invokeAPI("notifyBLECharacteristicValueChange", opts);
	}
	/**
	* 获取蓝牙低功耗设备所有服务 (service)。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceServices.html
	*/
	function getBLEDeviceServices(opts) {
		return invokeAPI("getBLEDeviceServices", opts);
	}
	/**
	* 获取蓝牙低功耗设备的信号强度 (Received Signal Strength Indication, RSSI)
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceRSSI.html
	*/
	function getBLEDeviceRSSI(opts) {
		return invokeAPI("getBLEDeviceRSSI", opts);
	}
	/**
	* 获取蓝牙低功耗设备某个服务中所有特征 (characteristic)。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEDeviceCharacteristics.html
	*/
	function getBLEDeviceCharacteristics(opts) {
		return invokeAPI("getBLEDeviceCharacteristics", opts);
	}
	/**
	* 连接蓝牙低功耗设备。
	* 若小程序在之前已有搜索过某个蓝牙设备，并成功建立连接，可直接传入之前搜索获取的 deviceId 直接尝试连接该设备，无需再次进行搜索操作。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.createBLEConnection.html
	*/
	function createBLEConnection(opts) {
		return invokeAPI("createBLEConnection", opts);
	}
	/**
	* 断开与蓝牙低功耗设备的连接。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.closeBLEConnection.html
	*/
	function closeBLEConnection(opts) {
		return invokeAPI("closeBLEConnection", opts);
	}
	/**
	* 获取蓝牙低功耗的最大传输单元。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.getBLEMTU.html
	*/
	function getBLEMTU(opts) {
		return invokeAPI("getBLEMTU", opts);
	}
	/**
	* 监听蓝牙低功耗的最大传输单元变化事件。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.onBLEMTUChange.html
	*/
	function onBLEMTUChange(listener) {
		return mtuEvent.on(listener);
	}
	/**
	* 移除蓝牙低功耗的最大传输单元变化事件监听函数。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/bluetooth-ble/wx.offBLEMTUChange.html
	*/
	function offBLEMTUChange(listener) {
		return mtuEvent.off(listener);
	}
	//#endregion
	//#region src/api/core/device/clipboard/index.js
	var clipboard_exports = /* @__PURE__ */ __exportAll({
		getClipboardData: () => getClipboardData,
		setClipboardData: () => setClipboardData
	});
	/**
	* 设置系统剪贴板的内容。调用成功后，会弹出 toast 提示"内容已复制"，持续 1.5s
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/clipboard/wx.setClipboardData.html
	*/
	function setClipboardData(opts) {
		return invokeAPI("setClipboardData", opts);
	}
	/**
	* 获取系统剪贴板的内容
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/clipboard/wx.getClipboardData.html
	*/
	function getClipboardData(opts) {
		return invokeAPI("getClipboardData", opts);
	}
	//#endregion
	//#region src/api/core/device/contact/index.js
	var contact_exports = /* @__PURE__ */ __exportAll({
		addPhoneContact: () => addPhoneContact,
		chooseContact: () => chooseContact
	});
	/**
	* 拉起手机通讯录，选择联系人
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/contact/wx.chooseContact.html
	*/
	function chooseContact(opts) {
		return invokeAPI("chooseContact", opts);
	}
	/**
	* 添加手机通讯录联系人。用户可以选择将该表单以「新增联系人」或「添加到已有联系人」的方式，写入手机系统通讯录。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/contact/wx.addPhoneContact.html
	*/
	function addPhoneContact(opts) {
		return invokeAPI("addPhoneContact", opts);
	}
	//#endregion
	//#region src/api/core/device/keyboard/index.js
	var keyboard_exports = /* @__PURE__ */ __exportAll({ hideKeyboard: () => hideKeyboard });
	/**
	* 在input、textarea等focus拉起键盘之后，手动调用此接口收起键盘
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/keyboard/wx.hideKeyboard.html
	*/
	function hideKeyboard(opts) {
		return invokeAPI("hideKeyboard", opts);
	}
	//#endregion
	//#region src/api/core/device/memory/index.js
	var memory_exports = /* @__PURE__ */ __exportAll({
		offMemoryWarning: () => offMemoryWarning,
		onMemoryWarning: () => onMemoryWarning
	});
	/**
	* 监听内存不足告警事件。
	* 当 iOS/Android 向小程序进程发出内存警告时，触发该事件。触发该事件不意味小程序被杀，大部分情况下仅仅是告警，开发者可在收到通知后回收一些不必要资源避免进一步加剧内存紧张。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/memory/wx.onMemoryWarning.html
	*/
	function onMemoryWarning(opts) {
		return invokeAPI("onMemoryWarning", opts);
	}
	/**
	* 移除内存不足告警事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/memory/wx.offMemoryWarning.html
	*/
	function offMemoryWarning(opts) {
		return invokeAPI("offMemoryWarning", opts);
	}
	//#endregion
	//#region src/api/core/device/network/index.js
	var network_exports = /* @__PURE__ */ __exportAll({ getNetworkType: () => getNetworkType });
	/**
	* 获取网络类型
	*	https://developers.weixin.qq.com/miniprogram/dev/api/device/network/wx.getNetworkType.html
	* @param {*} opts
	*/
	function getNetworkType(opts) {
		return invokeAPI("getNetworkType", opts);
	}
	//#endregion
	//#region src/api/core/device/phone/index.js
	var phone_exports = /* @__PURE__ */ __exportAll({ makePhoneCall: () => makePhoneCall });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/phone/wx.makePhoneCall.html
	*/
	function makePhoneCall(opts) {
		return invokeAPI("makePhoneCall", opts);
	}
	//#endregion
	//#region src/api/core/device/scan/index.js
	var scan_exports = /* @__PURE__ */ __exportAll({ scanCode: () => scanCode });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/scan/wx.scanCode.html
	*/
	function scanCode(opts) {
		return invokeAPI("scanCode", opts);
	}
	//#endregion
	//#region src/api/core/device/screen/index.js
	var screen_exports = /* @__PURE__ */ __exportAll({
		offUserCaptureScreen: () => offUserCaptureScreen,
		onUserCaptureScreen: () => onUserCaptureScreen
	});
	var userCaptureScreenEvent = createBluetoothEvent("onUserCaptureScreen", "offUserCaptureScreen");
	var userCaptureScreenListener;
	/**
	* 监听用户主动截屏事件。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/screen/wx.onUserCaptureScreen.html
	*/
	function onUserCaptureScreen(listener) {
		if (typeof listener !== "function") return;
		if (userCaptureScreenListener && userCaptureScreenListener !== listener) userCaptureScreenEvent.off(userCaptureScreenListener);
		userCaptureScreenListener = listener;
		return userCaptureScreenEvent.on(listener);
	}
	/**
	* 移除用户主动截屏事件的监听函数。
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/screen/wx.offUserCaptureScreen.html
	*/
	function offUserCaptureScreen(listener) {
		if (typeof listener === "function" && listener !== userCaptureScreenListener) return;
		userCaptureScreenListener = void 0;
		return userCaptureScreenEvent.off(listener);
	}
	//#endregion
	//#region src/api/core/device/vibrate/index.js
	var vibrate_exports = /* @__PURE__ */ __exportAll({
		vibrateLong: () => vibrateLong,
		vibrateShort: () => vibrateShort
	});
	/**
	* 使手机发生较短时间的振动（15 ms）
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/vibrate/wx.vibrateShort.html
	*/
	function vibrateShort(opts) {
		return invokeAPI("vibrateShort", opts);
	}
	/**
	* 使手机发生较长时间的振动（400 ms)
	* https://developers.weixin.qq.com/miniprogram/dev/api/device/vibrate/wx.vibrateLong.html
	*/
	function vibrateLong(opts) {
		return invokeAPI("vibrateLong", opts);
	}
	//#endregion
	//#region src/api/core/ext/index.js
	var ext_exports = /* @__PURE__ */ __exportAll({
		extBridge: () => extBridge,
		extOffBridge: () => extOffBridge,
		extOnBridge: () => extOnBridge,
		offLoginStatusChanged: () => offLoginStatusChanged,
		onLoginStatusChanged: () => onLoginStatusChanged
	});
	/**
	* 第三方拓展的 bridge 接口
	*/
	function extBridge({ event, module, data = {}, success, fail, complete }, extraCallback) {
		let overrideSuccess;
		let overrideFail;
		let overrideComplete;
		if (isFunction(extraCallback)) {
			overrideSuccess = extraCallback;
			overrideFail = extraCallback;
		} else {
			overrideSuccess = success;
			overrideFail = fail;
			overrideComplete = complete;
		}
		return invokeAPI(event, {
			module,
			data,
			keep: data.isSustain ?? true,
			success: overrideSuccess,
			fail: overrideFail,
			complete: overrideComplete
		});
	}
	/**
	* 第三方扩展的 on 接口
	*/
	function extOnBridge({ event, module, callBack, isSustain = true }) {
		if (!module || module === "DMServiceBridgeModule") {
			console.error(`[ERROR]: extOnBridge \u53C2\u6570 module ${module ? `\u503C${module}\u4E0D\u5408\u6CD5` : "为空"}`);
			return;
		}
		if (!event) {
			console.error("[ERROR]: extOnBridge 参数 event 为空");
			return;
		}
		if (!callBack) {
			console.error("[ERROR]: extOnBridge 参数 callBack 为空");
			return;
		}
		const eventName = `${module}_${event}`;
		invokeAPI(eventName, {
			evtId: eventName,
			keep: isSustain,
			success: callBack
		});
	}
	/**
	* 第三方扩展的 off 接口
	*/
	function extOffBridge({ event, module, callBack }) {
		if (!module || module === "DMServiceBridgeModule") {
			console.error(`[ERROR]: extOffBridge \u53C2\u6570 module ${module ? `\u503C${module}\u4E0D\u5408\u6CD5` : "为空"}`);
			return;
		}
		if (!event) {
			console.error("[ERROR]: extOffBridge 参数 event 为空");
			return;
		}
		const eventName = `${module}_${event}`;
		invokeAPI(eventName, {
			evtId: eventName,
			success: callBack
		});
	}
	/**
	* 登录状态变化时的回调
	*/
	function onLoginStatusChanged(callback) {
		message_default.on("notifyLoginStatusChanged", (msg) => {
			callback?.(msg);
		});
	}
	/**
	* 取消登录状态变化时的回调
	*/
	function offLoginStatusChanged() {
		message_default.off("notifyLoginStatusChanged");
	}
	//#endregion
	//#region src/core/safe-callback.js
	var reportingErrors = /* @__PURE__ */ new WeakSet();
	function reportCallbackError(ctx, error, label) {
		if (ctx && (typeof ctx === "object" || typeof ctx === "function") && !reportingErrors.has(ctx)) {
			reportingErrors.add(ctx);
			try {
				if (isFunction(ctx.componentError)) ctx.componentError(error);
			} catch (errorHandlerError) {
				console.error("[service] error lifetime error:", errorHandlerError);
			} finally {
				reportingErrors.delete(ctx);
			}
		}
		console.error(`[service] ${label} error:`, error);
	}
	/**
	* Invoke a user callback synchronously while isolating its exception.
	*
	* This intentionally does not await callback return values. exparser/glass-easel
	* lifecycle and observer dispatch stays in the current call stack, while an
	* exception from one callback must not prevent the remaining callbacks or tree
	* traversal from running.
	*/
	function invokeSafely(ctx, callback, args = [], label = "callback", reportToComponent = true) {
		if (!isFunction(callback)) return;
		try {
			return callback.apply(ctx, args);
		} catch (error) {
			if (reportToComponent) reportCallbackError(ctx, error, label);
			else console.error(`[service] ${label} error:`, error);
			return;
		}
	}
	function invokeSafelyAll(ctx, callbacks, args = [], label = "callback", reportToComponent = true) {
		for (const callback of callbacks || []) invokeSafely(ctx, callback, args, label, reportToComponent);
	}
	//#endregion
	//#region src/instance/app/app.js
	var lifecycleMethods = [
		"onLaunch",
		"onShow",
		"onHide"
	];
	var reservedProperties = ["globalData"];
	var App = class {
		constructor(appModule, options) {
			this.appModule = appModule;
			this.options = options;
			this.init();
		}
		init() {
			this.initGlobalData();
			this.initLifecycle();
			this.initCustomMethods();
			this.invokeSomeLifecycle();
		}
		initGlobalData() {
			this.globalData = this.appModule.moduleInfo.globalData;
		}
		initLifecycle() {
			lifecycleMethods.forEach((method) => {
				const lifecycleMethod = this.appModule.moduleInfo[method];
				if (!isFunction(lifecycleMethod)) return;
				this[method] = lifecycleMethod.bind(this);
			});
		}
		initCustomMethods() {
			const moduleInfo = this.appModule.moduleInfo;
			for (const attr in moduleInfo) {
				if (lifecycleMethods.includes(attr) || reservedProperties.includes(attr)) continue;
				if (isFunction(moduleInfo[attr])) this[attr] = moduleInfo[attr].bind(this);
				else this[attr] = moduleInfo[attr];
			}
		}
		invokeSomeLifecycle() {
			invokeSafely(this, this.onLaunch, [this.options], "onLaunch");
			invokeSafely(this, this.onShow, [this.options], "onShow");
		}
		appShow() {
			invokeSafely(this, this.onShow, [this.options], "onShow");
		}
		appHide() {
			invokeSafely(this, this.onHide, [], "onHide");
		}
	};
	var CONTEXT_2D_TYPES = /* @__PURE__ */ new Set(["2d"]);
	var WEBGL_CONTEXT_TYPES = /* @__PURE__ */ new Set([
		"webgl",
		"experimental-webgl",
		"webgl2"
	]);
	var CANVAS_2D_RESOURCE_METHODS = /* @__PURE__ */ new Set([
		"createLinearGradient",
		"createPattern",
		"createRadialGradient"
	]);
	var WEBGL_RESOURCE_METHOD_TYPES = /* @__PURE__ */ new Map([
		["createBuffer", "buffer"],
		["createFramebuffer", "framebuffer"],
		["createProgram", "program"],
		["createQuery", "query"],
		["createRenderbuffer", "renderbuffer"],
		["createSampler", "sampler"],
		["createShader", "shader"],
		["createTexture", "texture"],
		["createTransformFeedback", "transformFeedback"],
		["createVertexArray", "vertexArray"],
		["fenceSync", "sync"]
	]);
	var WEBGL_LOCATION_METHOD_TYPES = /* @__PURE__ */ new Map([["getAttribLocation", "attribLocation"], ["getUniformLocation", "uniformLocation"]]);
	var WEBGL_DELETE_METHOD_TYPES = /* @__PURE__ */ new Map([
		["deleteBuffer", "buffer"],
		["deleteFramebuffer", "framebuffer"],
		["deleteProgram", "program"],
		["deleteQuery", "query"],
		["deleteRenderbuffer", "renderbuffer"],
		["deleteSampler", "sampler"],
		["deleteShader", "shader"],
		["deleteSync", "sync"],
		["deleteTexture", "texture"],
		["deleteTransformFeedback", "transformFeedback"],
		["deleteVertexArray", "vertexArray"]
	]);
	var WEBGL_IS_METHOD_TYPES = /* @__PURE__ */ new Map([
		["isBuffer", "buffer"],
		["isFramebuffer", "framebuffer"],
		["isProgram", "program"],
		["isQuery", "query"],
		["isRenderbuffer", "renderbuffer"],
		["isSampler", "sampler"],
		["isShader", "shader"],
		["isSync", "sync"],
		["isTexture", "texture"],
		["isTransformFeedback", "transformFeedback"],
		["isVertexArray", "vertexArray"]
	]);
	var WEBGL_DEFAULT_CONTEXT_ATTRIBUTES = {
		alpha: true,
		depth: true,
		stencil: false,
		antialias: true,
		premultipliedAlpha: true,
		preserveDrawingBuffer: false,
		powerPreference: "default",
		failIfMajorPerformanceCaveat: false,
		desynchronized: false
	};
	var webglCapabilitiesByBridge = /* @__PURE__ */ new Map();
	var WEBGL_CONSTANTS = {
		DEPTH_BUFFER_BIT: 256,
		STENCIL_BUFFER_BIT: 1024,
		COLOR_BUFFER_BIT: 16384,
		FALSE: 0,
		TRUE: 1,
		POINTS: 0,
		LINES: 1,
		LINE_LOOP: 2,
		LINE_STRIP: 3,
		TRIANGLES: 4,
		TRIANGLE_STRIP: 5,
		TRIANGLE_FAN: 6,
		ZERO: 0,
		ONE: 1,
		SRC_COLOR: 768,
		ONE_MINUS_SRC_COLOR: 769,
		SRC_ALPHA: 770,
		ONE_MINUS_SRC_ALPHA: 771,
		DST_ALPHA: 772,
		ONE_MINUS_DST_ALPHA: 773,
		DST_COLOR: 774,
		ONE_MINUS_DST_COLOR: 775,
		SRC_ALPHA_SATURATE: 776,
		FUNC_ADD: 32774,
		BLEND_EQUATION: 32777,
		BLEND_EQUATION_RGB: 32777,
		BLEND_EQUATION_ALPHA: 34877,
		FUNC_SUBTRACT: 32778,
		FUNC_REVERSE_SUBTRACT: 32779,
		BLEND_DST_RGB: 32968,
		BLEND_SRC_RGB: 32969,
		BLEND_DST_ALPHA: 32970,
		BLEND_SRC_ALPHA: 32971,
		CONSTANT_COLOR: 32769,
		ONE_MINUS_CONSTANT_COLOR: 32770,
		CONSTANT_ALPHA: 32771,
		ONE_MINUS_CONSTANT_ALPHA: 32772,
		BLEND_COLOR: 32773,
		ARRAY_BUFFER: 34962,
		ELEMENT_ARRAY_BUFFER: 34963,
		ARRAY_BUFFER_BINDING: 34964,
		ELEMENT_ARRAY_BUFFER_BINDING: 34965,
		STREAM_DRAW: 35040,
		STATIC_DRAW: 35044,
		DYNAMIC_DRAW: 35048,
		BUFFER_SIZE: 34660,
		BUFFER_USAGE: 34661,
		CURRENT_VERTEX_ATTRIB: 34342,
		FRONT: 1028,
		BACK: 1029,
		FRONT_AND_BACK: 1032,
		CULL_FACE: 2884,
		BLEND: 3042,
		DITHER: 3024,
		STENCIL_TEST: 2960,
		DEPTH_TEST: 2929,
		SCISSOR_TEST: 3089,
		POLYGON_OFFSET_FILL: 32823,
		SAMPLE_ALPHA_TO_COVERAGE: 32926,
		SAMPLE_COVERAGE: 32928,
		NO_ERROR: 0,
		INVALID_ENUM: 1280,
		INVALID_VALUE: 1281,
		INVALID_OPERATION: 1282,
		OUT_OF_MEMORY: 1285,
		CW: 2304,
		CCW: 2305,
		LINE_WIDTH: 2849,
		ALIASED_POINT_SIZE_RANGE: 33901,
		ALIASED_LINE_WIDTH_RANGE: 33902,
		CULL_FACE_MODE: 2885,
		FRONT_FACE: 2886,
		DEPTH_RANGE: 2928,
		DEPTH_WRITEMASK: 2930,
		DEPTH_CLEAR_VALUE: 2931,
		DEPTH_FUNC: 2932,
		STENCIL_CLEAR_VALUE: 2961,
		STENCIL_FUNC: 2962,
		STENCIL_FAIL: 2964,
		STENCIL_PASS_DEPTH_FAIL: 2965,
		STENCIL_PASS_DEPTH_PASS: 2966,
		STENCIL_REF: 2967,
		STENCIL_VALUE_MASK: 2963,
		STENCIL_WRITEMASK: 2968,
		STENCIL_BACK_FUNC: 34816,
		STENCIL_BACK_FAIL: 34817,
		STENCIL_BACK_PASS_DEPTH_FAIL: 34818,
		STENCIL_BACK_PASS_DEPTH_PASS: 34819,
		STENCIL_BACK_REF: 36003,
		STENCIL_BACK_VALUE_MASK: 36004,
		STENCIL_BACK_WRITEMASK: 36005,
		VIEWPORT: 2978,
		SCISSOR_BOX: 3088,
		COLOR_CLEAR_VALUE: 3106,
		COLOR_WRITEMASK: 3107,
		UNPACK_ALIGNMENT: 3317,
		PACK_ALIGNMENT: 3333,
		MAX_TEXTURE_SIZE: 3379,
		MAX_VIEWPORT_DIMS: 3386,
		SUBPIXEL_BITS: 3408,
		RED_BITS: 3410,
		GREEN_BITS: 3411,
		BLUE_BITS: 3412,
		ALPHA_BITS: 3413,
		DEPTH_BITS: 3414,
		STENCIL_BITS: 3415,
		POLYGON_OFFSET_UNITS: 10752,
		POLYGON_OFFSET_FACTOR: 32824,
		TEXTURE_BINDING_2D: 32873,
		SAMPLE_BUFFERS: 32936,
		SAMPLES: 32937,
		SAMPLE_COVERAGE_VALUE: 32938,
		SAMPLE_COVERAGE_INVERT: 32939,
		COMPRESSED_TEXTURE_FORMATS: 34467,
		DONT_CARE: 4352,
		FASTEST: 4353,
		NICEST: 4354,
		GENERATE_MIPMAP_HINT: 33170,
		BYTE: 5120,
		UNSIGNED_BYTE: 5121,
		SHORT: 5122,
		UNSIGNED_SHORT: 5123,
		INT: 5124,
		UNSIGNED_INT: 5125,
		FLOAT: 5126,
		DEPTH_COMPONENT: 6402,
		ALPHA: 6406,
		RGB: 6407,
		RGBA: 6408,
		LUMINANCE: 6409,
		LUMINANCE_ALPHA: 6410,
		UNSIGNED_SHORT_4_4_4_4: 32819,
		UNSIGNED_SHORT_5_5_5_1: 32820,
		UNSIGNED_SHORT_5_6_5: 33635,
		FRAGMENT_SHADER: 35632,
		VERTEX_SHADER: 35633,
		MAX_VERTEX_ATTRIBS: 34921,
		MAX_VERTEX_UNIFORM_VECTORS: 36347,
		MAX_VARYING_VECTORS: 36348,
		MAX_COMBINED_TEXTURE_IMAGE_UNITS: 35661,
		MAX_VERTEX_TEXTURE_IMAGE_UNITS: 35660,
		MAX_TEXTURE_IMAGE_UNITS: 34930,
		MAX_FRAGMENT_UNIFORM_VECTORS: 36349,
		SHADER_TYPE: 35663,
		DELETE_STATUS: 35712,
		LINK_STATUS: 35714,
		VALIDATE_STATUS: 35715,
		ATTACHED_SHADERS: 35717,
		ACTIVE_UNIFORMS: 35718,
		ACTIVE_ATTRIBUTES: 35721,
		SHADING_LANGUAGE_VERSION: 35724,
		CURRENT_PROGRAM: 35725,
		NEVER: 512,
		LESS: 513,
		EQUAL: 514,
		LEQUAL: 515,
		GREATER: 516,
		NOTEQUAL: 517,
		GEQUAL: 518,
		ALWAYS: 519,
		KEEP: 7680,
		REPLACE: 7681,
		INCR: 7682,
		DECR: 7683,
		INVERT: 5386,
		INCR_WRAP: 34055,
		DECR_WRAP: 34056,
		VENDOR: 7936,
		RENDERER: 7937,
		VERSION: 7938,
		NEAREST: 9728,
		LINEAR: 9729,
		NEAREST_MIPMAP_NEAREST: 9984,
		LINEAR_MIPMAP_NEAREST: 9985,
		NEAREST_MIPMAP_LINEAR: 9986,
		LINEAR_MIPMAP_LINEAR: 9987,
		TEXTURE_MAG_FILTER: 10240,
		TEXTURE_MIN_FILTER: 10241,
		TEXTURE_WRAP_S: 10242,
		TEXTURE_WRAP_T: 10243,
		TEXTURE_2D: 3553,
		TEXTURE: 5890,
		TEXTURE_CUBE_MAP: 34067,
		TEXTURE_BINDING_CUBE_MAP: 34068,
		TEXTURE_CUBE_MAP_POSITIVE_X: 34069,
		TEXTURE_CUBE_MAP_NEGATIVE_X: 34070,
		TEXTURE_CUBE_MAP_POSITIVE_Y: 34071,
		TEXTURE_CUBE_MAP_NEGATIVE_Y: 34072,
		TEXTURE_CUBE_MAP_POSITIVE_Z: 34073,
		TEXTURE_CUBE_MAP_NEGATIVE_Z: 34074,
		MAX_CUBE_MAP_TEXTURE_SIZE: 34076,
		TEXTURE0: 33984,
		TEXTURE1: 33985,
		TEXTURE2: 33986,
		TEXTURE3: 33987,
		TEXTURE4: 33988,
		TEXTURE5: 33989,
		TEXTURE6: 33990,
		TEXTURE7: 33991,
		TEXTURE8: 33992,
		TEXTURE9: 33993,
		TEXTURE10: 33994,
		TEXTURE11: 33995,
		TEXTURE12: 33996,
		TEXTURE13: 33997,
		TEXTURE14: 33998,
		TEXTURE15: 33999,
		TEXTURE16: 34e3,
		TEXTURE17: 34001,
		TEXTURE18: 34002,
		TEXTURE19: 34003,
		TEXTURE20: 34004,
		TEXTURE21: 34005,
		TEXTURE22: 34006,
		TEXTURE23: 34007,
		TEXTURE24: 34008,
		TEXTURE25: 34009,
		TEXTURE26: 34010,
		TEXTURE27: 34011,
		TEXTURE28: 34012,
		TEXTURE29: 34013,
		TEXTURE30: 34014,
		TEXTURE31: 34015,
		ACTIVE_TEXTURE: 34016,
		REPEAT: 10497,
		CLAMP_TO_EDGE: 33071,
		MIRRORED_REPEAT: 33648,
		FLOAT_VEC2: 35664,
		FLOAT_VEC3: 35665,
		FLOAT_VEC4: 35666,
		INT_VEC2: 35667,
		INT_VEC3: 35668,
		INT_VEC4: 35669,
		BOOL: 35670,
		BOOL_VEC2: 35671,
		BOOL_VEC3: 35672,
		BOOL_VEC4: 35673,
		FLOAT_MAT2: 35674,
		FLOAT_MAT3: 35675,
		FLOAT_MAT4: 35676,
		SAMPLER_2D: 35678,
		SAMPLER_CUBE: 35680,
		LOW_FLOAT: 36336,
		MEDIUM_FLOAT: 36337,
		HIGH_FLOAT: 36338,
		LOW_INT: 36339,
		MEDIUM_INT: 36340,
		HIGH_INT: 36341,
		FRAMEBUFFER: 36160,
		RENDERBUFFER: 36161,
		RGBA4: 32854,
		RGB5_A1: 32855,
		RGB565: 36194,
		DEPTH_COMPONENT16: 33189,
		STENCIL_INDEX8: 36168,
		DEPTH_STENCIL: 34041,
		RENDERBUFFER_WIDTH: 36162,
		RENDERBUFFER_HEIGHT: 36163,
		RENDERBUFFER_INTERNAL_FORMAT: 36164,
		RENDERBUFFER_RED_SIZE: 36176,
		RENDERBUFFER_GREEN_SIZE: 36177,
		RENDERBUFFER_BLUE_SIZE: 36178,
		RENDERBUFFER_ALPHA_SIZE: 36179,
		RENDERBUFFER_DEPTH_SIZE: 36180,
		RENDERBUFFER_STENCIL_SIZE: 36181,
		FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE: 36048,
		FRAMEBUFFER_ATTACHMENT_OBJECT_NAME: 36049,
		FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL: 36050,
		FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE: 36051,
		COLOR_ATTACHMENT0: 36064,
		DEPTH_ATTACHMENT: 36096,
		STENCIL_ATTACHMENT: 36128,
		DEPTH_STENCIL_ATTACHMENT: 33306,
		NONE: 0,
		FRAMEBUFFER_COMPLETE: 36053,
		FRAMEBUFFER_INCOMPLETE_ATTACHMENT: 36054,
		FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT: 36055,
		FRAMEBUFFER_INCOMPLETE_DIMENSIONS: 36057,
		FRAMEBUFFER_UNSUPPORTED: 36061,
		FRAMEBUFFER_BINDING: 36006,
		RENDERBUFFER_BINDING: 36007,
		MAX_RENDERBUFFER_SIZE: 34024,
		INVALID_FRAMEBUFFER_OPERATION: 1286,
		UNPACK_FLIP_Y_WEBGL: 37440,
		UNPACK_PREMULTIPLY_ALPHA_WEBGL: 37441,
		CONTEXT_LOST_WEBGL: 37442,
		UNPACK_COLORSPACE_CONVERSION_WEBGL: 37443,
		BROWSER_DEFAULT_WEBGL: 37444,
		COMPILE_STATUS: 35713
	};
	function normalizeContextType(type) {
		const contextType = String(type).toLowerCase();
		return contextType === "experimental-webgl" ? "webgl" : contextType;
	}
	function setWebGLCapabilities(bridgeId, capabilities) {
		if (!bridgeId || !capabilities) return;
		webglCapabilitiesByBridge.set(bridgeId, capabilities);
	}
	function getWebGLCapabilities(bridgeId) {
		return webglCapabilitiesByBridge.get(bridgeId) || null;
	}
	function getContextCapabilities(capabilities, contextType) {
		if (!capabilities) return null;
		return capabilities[normalizeContextType(contextType)] || null;
	}
	function deserializeCanvasValue(value) {
		if (value === null || value === void 0) return value;
		if (Array.isArray(value)) return value.map((item) => deserializeCanvasValue(item));
		if (typeof value !== "object") return value;
		if (value.__canvasTypedArray) {
			if (value.__canvasTypedArray === "DataView") return new DataView(new Uint8Array(value.data || []).buffer);
			const Ctor = globalThis[value.__canvasTypedArray];
			if (typeof Ctor === "function") return new Ctor(value.data || []);
			return value.data || [];
		}
		const result = {};
		for (const [key, item] of Object.entries(value)) result[key] = deserializeCanvasValue(item);
		return result;
	}
	message_default.on("canvasCapabilities", ({ bridgeId, capabilities }) => {
		setWebGLCapabilities(bridgeId, capabilities);
	});
	message_default.on("resourceLoaded", ({ bridgeId, canvasCapabilities }) => {
		setWebGLCapabilities(bridgeId, canvasCapabilities);
	});
	var canvasResourceSerial = 1;
	var canvasRafSerial = 1;
	function getCurrentBridgeId$1() {
		const pageInfo = router_default.getPageInfo();
		return pageInfo?.bridgeId || pageInfo?.id || "";
	}
	function normalizeCanvasDimension(value, fallback) {
		if (value === void 0) return fallback;
		const number = Number(value);
		return Number.isFinite(number) && number >= 0 ? Math.floor(number) : fallback;
	}
	function sendCanvasMessage(bridgeId, name, params) {
		message_default.send({
			type: "invokeAPI",
			target: "render",
			body: {
				bridgeId,
				name,
				params
			}
		});
	}
	function scheduleMicrotask(fn) {
		Promise.resolve().then(fn);
	}
	function isPlainObject(value) {
		return Object.prototype.toString.call(value) === "[object Object]";
	}
	function serializeTypedArray(value) {
		if (typeof ArrayBuffer === "undefined" || !ArrayBuffer.isView(value)) return null;
		if (value instanceof DataView) return {
			__canvasTypedArray: "DataView",
			data: Array.from(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
		};
		return {
			__canvasTypedArray: value.constructor.name,
			data: Array.from(value)
		};
	}
	function serializeCanvasArg(value) {
		if (value === null || value === void 0) return value;
		if (value.__canvasResourceId) return { __canvasResourceId: value.__canvasResourceId };
		if (value.__diminaCanvasNode) return { __canvasNodeId: value.nodeId };
		const typedArray = serializeTypedArray(value);
		if (typedArray) return typedArray;
		if (typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer) return {
			__canvasArrayBuffer: true,
			data: Array.from(new Uint8Array(value))
		};
		if (Array.isArray(value)) return value.map((item) => serializeCanvasArg(item));
		if (isPlainObject(value)) {
			const result = {};
			for (const [key, item] of Object.entries(value)) result[key] = serializeCanvasArg(item);
			return result;
		}
		return value;
	}
	function serializeCanvasArgs(args) {
		return Array.from(args).map((arg) => serializeCanvasArg(arg));
	}
	function makeResourceId(prefix = "canvas_resource") {
		return `${prefix}_${uuid()}`;
	}
	var CanvasResource = class {
		constructor(canvas, resourceId, resourceType = "resource", metadata = {}) {
			this.__canvasResourceId = resourceId;
			this.__canvasProxyValue = canvasResourceSerial++;
			this.canvas = canvas;
			this.resourceType = resourceType;
			this.metadata = metadata;
			this.deleted = false;
			return new Proxy(this, { get(target, prop) {
				if (prop in target) {
					const value = target[prop];
					return typeof value === "function" ? value.bind(target) : value;
				}
				if (typeof prop === "symbol") return;
				return (...args) => {
					target.canvas.enqueueOperation({
						op: "resourceCall",
						resourceId,
						method: prop,
						args: serializeCanvasArgs(args)
					});
				};
			} });
		}
		valueOf() {
			return this.__canvasProxyValue;
		}
		toString() {
			return String(this.__canvasProxyValue);
		}
		markDeleted() {
			this.deleted = true;
		}
		updateMetadata(patch = {}) {
			Object.assign(this.metadata, patch);
		}
	};
	var CanvasImage = class {
		constructor(canvas, imageId) {
			this.__canvasResourceId = imageId;
			this.canvas = canvas;
			this.imageId = imageId;
			this.onload = null;
			this.onerror = null;
			this.width = 0;
			this.height = 0;
			this._src = "";
			this.canvas.enqueueOperation({
				op: "createImage",
				imageId
			});
		}
		get src() {
			return this._src;
		}
		set src(value) {
			this._src = value;
			const onload = callback_default.store((event = {}) => {
				this.width = event.width || this.width;
				this.height = event.height || this.height;
				if (isFunction(this.onload)) this.onload(event);
			});
			const onerror = callback_default.store((event = {}) => {
				if (isFunction(this.onerror)) this.onerror(event);
			});
			this.canvas.enqueueOperation({
				op: "imageSetSrc",
				imageId: this.imageId,
				src: value,
				onload,
				onerror
			});
		}
	};
	var CanvasRenderingContext2DProxy = class {
		constructor(canvas, contextId) {
			this.canvas = canvas;
			this.contextId = contextId;
			this.state = {
				fillStyle: "#000000",
				strokeStyle: "#000000",
				font: "10px sans-serif",
				globalAlpha: 1,
				lineWidth: 1
			};
			return new Proxy(this, {
				get(target, prop) {
					if (prop in target) return target[prop];
					if (prop in target.state) return target.state[prop];
					if (typeof prop === "symbol") return;
					return (...args) => target.call(prop, args);
				},
				set(target, prop, value) {
					target.state[prop] = value;
					target.canvas.enqueueOperation({
						op: "contextSetProperty",
						contextId,
						prop,
						value: serializeCanvasArg(value)
					});
					return true;
				}
			});
		}
		async getImageData(x, y, w, h) {
			return await this.canvas.getImageData({
				contextId: this.contextId,
				x,
				y,
				width: w,
				height: h
			});
		}
		toDataURL(type, quality) {
			return this.canvas.toDataURL(type, quality);
		}
		call(method, args) {
			if (method === "measureText") return { width: String(args[0] ?? "").length * 10 };
			if (method === "createImageData") {
				const w = args[0];
				const h = args[1];
				return {
					width: w,
					height: h,
					data: new Uint8ClampedArray(w * h * 4)
				};
			}
			const resultId = CANVAS_2D_RESOURCE_METHODS.has(method) ? makeResourceId() : void 0;
			this.canvas.enqueueOperation({
				op: "contextCall",
				contextId: this.contextId,
				method,
				args: serializeCanvasArgs(args),
				resultId
			});
			if (resultId) return new CanvasResource(this.canvas, resultId);
		}
	};
	var WebGLExtensionProxy = class {
		constructor(context, name, extensionId, descriptor = {}) {
			this.context = context;
			this.name = name;
			this.__canvasResourceId = extensionId;
			this.constants = descriptor.constants || {};
			return new Proxy(this, { get(target, prop) {
				if (prop in target) {
					const value = target[prop];
					return typeof value === "function" ? value.bind(target) : value;
				}
				if (Object.prototype.hasOwnProperty.call(target.constants, prop)) return target.constants[prop];
				if (typeof prop === "symbol") return;
				return (...args) => target.call(prop, args);
			} });
		}
		call(method, args) {
			let result;
			let resultId;
			if (method.startsWith("create")) {
				resultId = makeResourceId("webgl_extension_resource");
				result = new CanvasResource(this.context.canvas, resultId, `${this.name}:${method}`);
				this.context.resources.set(resultId, result);
			} else if (method.startsWith("delete") && args[0]?.markDeleted) args[0].markDeleted();
			else if (method.startsWith("is") && args[0] instanceof CanvasResource) return !args[0].deleted;
			this.context.canvas.enqueueOperation({
				op: "extensionCall",
				contextId: this.context.contextId,
				extensionId: this.__canvasResourceId,
				method,
				args: serializeCanvasArgs(args),
				resultId
			});
			return result;
		}
	};
	var WebGLRenderingContextProxy = class {
		constructor(canvas, contextId, contextType, attributes, capabilities) {
			this.canvas = canvas;
			this.contextId = contextId;
			this.contextType = contextType;
			this.requestedAttributes = {
				...WEBGL_DEFAULT_CONTEXT_ATTRIBUTES,
				...isPlainObject(attributes) ? attributes : {}
			};
			this.capabilities = null;
			this.resources = /* @__PURE__ */ new Map();
			this.extensions = /* @__PURE__ */ new Map();
			this.properties = /* @__PURE__ */ new Map();
			this.state = /* @__PURE__ */ new Map();
			this.enabledCapabilities = /* @__PURE__ */ new Set();
			this.errors = [];
			this.queryResults = /* @__PURE__ */ new Map();
			this.contextLost = false;
			this.creationFailed = false;
			this.hasActualCapabilities = false;
			this.initializeState();
			this.updateCapabilities(capabilities);
			return new Proxy(this, {
				get(target, prop) {
					if (prop in target) {
						const value = target[prop];
						return typeof value === "function" ? value.bind(target) : value;
					}
					if (target.properties.has(prop)) return target.properties.get(prop);
					if (Object.prototype.hasOwnProperty.call(target.capabilities?.constants || {}, prop)) return target.capabilities.constants[prop];
					if (Object.prototype.hasOwnProperty.call(WEBGL_CONSTANTS, prop)) return WEBGL_CONSTANTS[prop];
					if (prop === "drawingBufferWidth") return target.canvas.width;
					if (prop === "drawingBufferHeight") return target.canvas.height;
					if (typeof prop === "symbol") return;
					return (...args) => target.call(prop, args);
				},
				set(target, prop, value) {
					target.properties.set(prop, value);
					target.canvas.enqueueOperation({
						op: "contextSetProperty",
						contextId,
						prop,
						value: serializeCanvasArg(value)
					});
					return true;
				}
			});
		}
		initializeState() {
			const { width, height } = this.canvas;
			this.state.set(WEBGL_CONSTANTS.VIEWPORT, [
				0,
				0,
				width,
				height
			]);
			this.state.set(WEBGL_CONSTANTS.SCISSOR_BOX, [
				0,
				0,
				width,
				height
			]);
			this.state.set(WEBGL_CONSTANTS.COLOR_CLEAR_VALUE, new Float32Array([
				0,
				0,
				0,
				0
			]));
			this.state.set(WEBGL_CONSTANTS.COLOR_WRITEMASK, [
				true,
				true,
				true,
				true
			]);
			this.state.set(WEBGL_CONSTANTS.DEPTH_CLEAR_VALUE, 1);
			this.state.set(WEBGL_CONSTANTS.DEPTH_WRITEMASK, true);
			this.state.set(WEBGL_CONSTANTS.DEPTH_FUNC, WEBGL_CONSTANTS.LESS);
			this.state.set(WEBGL_CONSTANTS.STENCIL_CLEAR_VALUE, 0);
			this.state.set(WEBGL_CONSTANTS.LINE_WIDTH, 1);
			this.state.set(WEBGL_CONSTANTS.CULL_FACE_MODE, WEBGL_CONSTANTS.BACK);
			this.state.set(WEBGL_CONSTANTS.FRONT_FACE, WEBGL_CONSTANTS.CCW);
			this.state.set(WEBGL_CONSTANTS.ACTIVE_TEXTURE, WEBGL_CONSTANTS.TEXTURE0);
			this.state.set(WEBGL_CONSTANTS.PACK_ALIGNMENT, 4);
			this.state.set(WEBGL_CONSTANTS.UNPACK_ALIGNMENT, 4);
			this.state.set(WEBGL_CONSTANTS.CURRENT_PROGRAM, null);
			this.state.set(WEBGL_CONSTANTS.ARRAY_BUFFER_BINDING, null);
			this.state.set(WEBGL_CONSTANTS.ELEMENT_ARRAY_BUFFER_BINDING, null);
			this.state.set(WEBGL_CONSTANTS.TEXTURE_BINDING_2D, null);
			this.state.set(WEBGL_CONSTANTS.FRAMEBUFFER_BINDING, null);
			this.state.set(WEBGL_CONSTANTS.RENDERBUFFER_BINDING, null);
		}
		updateCapabilities(capabilities, actual = false) {
			if (!capabilities) return;
			const next = deserializeCanvasValue(capabilities);
			const extensions = { ...this.capabilities?.extensions || {} };
			for (const [name, descriptor] of Object.entries(next.extensions || {})) extensions[name] = {
				...extensions[name] || {},
				...descriptor,
				constants: {
					...extensions[name]?.constants || {},
					...descriptor.constants || {}
				}
			};
			this.capabilities = {
				...this.capabilities || {},
				...next,
				constants: {
					...this.capabilities?.constants || {},
					...next.constants || {}
				},
				parameters: {
					...this.capabilities?.parameters || {},
					...next.parameters || {}
				},
				extensions,
				shaderPrecisionFormats: {
					...this.capabilities?.shaderPrecisionFormats || {},
					...next.shaderPrecisionFormats || {}
				}
			};
			this.hasActualCapabilities ||= actual;
			if (typeof this.capabilities.contextLost === "boolean") this.contextLost = this.capabilities.contextLost;
		}
		applyFeedback(feedback = {}) {
			if (feedback.success === false) {
				this.creationFailed = true;
				this.contextLost = true;
				this.canvas.handleContextCreationFailure(this.contextId, this.contextType, feedback.statusMessage);
			} else if (feedback.capabilities) this.updateCapabilities(feedback.capabilities, true);
			if (typeof feedback.contextLost === "boolean") this.contextLost = feedback.contextLost;
			for (const error of feedback.errors || []) this.queueError(error);
			for (const update of feedback.resources || []) this.resources.get(update.resourceId)?.updateMetadata(deserializeCanvasValue(update.metadata));
			for (const query of feedback.queries || []) this.queryResults.set(query.key, this.deserializeFeedbackValue(query.value));
		}
		deserializeFeedbackValue(value) {
			if (value?.__canvasResourceId) return this.resources.get(value.__canvasResourceId) || null;
			if (Array.isArray(value)) return value.map((item) => this.deserializeFeedbackValue(item));
			if (value && typeof value === "object" && !value.__canvasTypedArray) {
				const result = {};
				for (const [key, item] of Object.entries(value)) result[key] = this.deserializeFeedbackValue(item);
				return result;
			}
			return deserializeCanvasValue(value);
		}
		queueError(error) {
			if (error && error !== WEBGL_CONSTANTS.NO_ERROR && !this.errors.includes(error)) this.errors.push(error);
		}
		queryKey(method, args) {
			return `${method}:${JSON.stringify(serializeCanvasArgs(args))}`;
		}
		requestQuery(method, args, fallback = null) {
			const key = this.queryKey(method, args);
			this.canvas.enqueueOperation({
				op: "contextQuery",
				contextId: this.contextId,
				method,
				args: serializeCanvasArgs(args),
				key
			});
			return this.queryResults.has(key) ? this.queryResults.get(key) : fallback;
		}
		createResource(method, args, resourceType) {
			const resultId = makeResourceId(`webgl_${resourceType}`);
			const metadata = {};
			if (resourceType === "shader") {
				metadata.shaderType = args[0];
				metadata.source = "";
				metadata.compileStatus = false;
				metadata.infoLog = "";
			} else if (resourceType === "program") {
				metadata.attachedShaders = [];
				metadata.linkStatus = false;
				metadata.validateStatus = false;
				metadata.infoLog = "";
			}
			const resource = new CanvasResource(this.canvas, resultId, resourceType, metadata);
			this.resources.set(resultId, resource);
			this.canvas.enqueueOperation({
				op: "contextCall",
				contextId: this.contextId,
				method,
				args: serializeCanvasArgs(args),
				resultId
			});
			return resource;
		}
		call(method, args) {
			switch (method) {
				case "getParameter": return this.getParameter(args[0]);
				case "getShaderParameter": return this.getShaderParameter(args[0], args[1]);
				case "getProgramParameter": return this.getProgramParameter(args[0], args[1]);
				case "getShaderInfoLog": return args[0]?.metadata?.infoLog || "";
				case "getProgramInfoLog": return args[0]?.metadata?.infoLog || "";
				case "getShaderSource": return args[0]?.metadata?.source || null;
				case "getAttachedShaders": return args[0]?.metadata?.attachedShaders?.slice() || [];
				case "getError": {
					const error = this.errors.shift();
					if (error) return error;
					this.canvas.enqueueOperation({
						op: "contextFeedback",
						contextId: this.contextId
					});
					return WEBGL_CONSTANTS.NO_ERROR;
				}
				case "isContextLost":
					this.canvas.enqueueOperation({
						op: "contextFeedback",
						contextId: this.contextId
					});
					return this.contextLost;
				case "isEnabled": return this.enabledCapabilities.has(args[0]);
				case "checkFramebufferStatus": return this.requestQuery(method, args, WEBGL_CONSTANTS.FRAMEBUFFER_COMPLETE);
				case "getContextAttributes": return { ...this.hasActualCapabilities && this.capabilities?.contextAttributes ? this.capabilities.contextAttributes : this.requestedAttributes };
				case "getSupportedExtensions": return (this.capabilities?.supportedExtensions || []).slice();
				case "getExtension": return this.getExtension(args[0]);
				case "getShaderPrecisionFormat": return this.getShaderPrecisionFormat(args[0], args[1]);
				case "getActiveAttrib":
				case "getActiveUniform":
				case "getBufferParameter":
				case "getFramebufferAttachmentParameter":
				case "getRenderbufferParameter":
				case "getTexParameter":
				case "getUniform":
				case "getVertexAttrib":
				case "getVertexAttribOffset": return this.requestQuery(method, args);
				default: break;
			}
			const resourceType = WEBGL_RESOURCE_METHOD_TYPES.get(method) || WEBGL_LOCATION_METHOD_TYPES.get(method);
			if (resourceType) return this.createResource(method, args, resourceType);
			if (WEBGL_IS_METHOD_TYPES.has(method)) {
				const resource = args[0];
				return resource instanceof CanvasResource && resource.resourceType === WEBGL_IS_METHOD_TYPES.get(method) && !resource.deleted;
			}
			if (WEBGL_DELETE_METHOD_TYPES.has(method) && args[0]?.markDeleted) args[0].markDeleted();
			this.updateState(method, args);
			const operation = {
				op: "contextCall",
				contextId: this.contextId,
				method,
				args: serializeCanvasArgs(args)
			};
			if (method === "compileShader") {
				args[0]?.updateMetadata({ compileStatus: true });
				operation.feedback = "shader";
			} else if (method === "linkProgram" || method === "validateProgram") {
				args[0]?.updateMetadata(method === "linkProgram" ? { linkStatus: true } : { validateStatus: true });
				operation.feedback = "program";
			} else if (method === "readPixels" && ArrayBuffer.isView(args[6])) {
				operation.typedArrayUpdateId = this.canvas.registerTypedArrayUpdate(args[6]);
				operation.typedArrayArgIndex = 6;
			} else if (method === "getBufferSubData" && ArrayBuffer.isView(args[2])) {
				operation.typedArrayUpdateId = this.canvas.registerTypedArrayUpdate(args[2]);
				operation.typedArrayArgIndex = 2;
			}
			this.canvas.enqueueOperation(operation);
		}
		updateState(method, args) {
			switch (method) {
				case "viewport":
					this.state.set(WEBGL_CONSTANTS.VIEWPORT, args.slice(0, 4));
					break;
				case "scissor":
					this.state.set(WEBGL_CONSTANTS.SCISSOR_BOX, args.slice(0, 4));
					break;
				case "clearColor":
					this.state.set(WEBGL_CONSTANTS.COLOR_CLEAR_VALUE, new Float32Array(args.slice(0, 4)));
					break;
				case "colorMask":
					this.state.set(WEBGL_CONSTANTS.COLOR_WRITEMASK, args.slice(0, 4).map(Boolean));
					break;
				case "clearDepth":
					this.state.set(WEBGL_CONSTANTS.DEPTH_CLEAR_VALUE, args[0]);
					break;
				case "depthMask":
					this.state.set(WEBGL_CONSTANTS.DEPTH_WRITEMASK, Boolean(args[0]));
					break;
				case "depthFunc":
					this.state.set(WEBGL_CONSTANTS.DEPTH_FUNC, args[0]);
					break;
				case "clearStencil":
					this.state.set(WEBGL_CONSTANTS.STENCIL_CLEAR_VALUE, args[0]);
					break;
				case "lineWidth":
					this.state.set(WEBGL_CONSTANTS.LINE_WIDTH, args[0]);
					break;
				case "cullFace":
					this.state.set(WEBGL_CONSTANTS.CULL_FACE_MODE, args[0]);
					break;
				case "frontFace":
					this.state.set(WEBGL_CONSTANTS.FRONT_FACE, args[0]);
					break;
				case "activeTexture":
					this.state.set(WEBGL_CONSTANTS.ACTIVE_TEXTURE, args[0]);
					break;
				case "pixelStorei":
					this.state.set(args[0], args[1]);
					break;
				case "enable":
					this.enabledCapabilities.add(args[0]);
					break;
				case "disable":
					this.enabledCapabilities.delete(args[0]);
					break;
				case "useProgram":
					this.state.set(WEBGL_CONSTANTS.CURRENT_PROGRAM, args[0] || null);
					break;
				case "bindBuffer":
					if (args[0] === WEBGL_CONSTANTS.ARRAY_BUFFER) this.state.set(WEBGL_CONSTANTS.ARRAY_BUFFER_BINDING, args[1] || null);
					else if (args[0] === WEBGL_CONSTANTS.ELEMENT_ARRAY_BUFFER) this.state.set(WEBGL_CONSTANTS.ELEMENT_ARRAY_BUFFER_BINDING, args[1] || null);
					break;
				case "bindTexture":
					if (args[0] === WEBGL_CONSTANTS.TEXTURE_2D) this.state.set(WEBGL_CONSTANTS.TEXTURE_BINDING_2D, args[1] || null);
					break;
				case "bindFramebuffer":
					this.state.set(WEBGL_CONSTANTS.FRAMEBUFFER_BINDING, args[1] || null);
					break;
				case "bindRenderbuffer":
					this.state.set(WEBGL_CONSTANTS.RENDERBUFFER_BINDING, args[1] || null);
					break;
				case "shaderSource":
					args[0]?.updateMetadata({ source: String(args[1] ?? "") });
					break;
				case "attachShader": {
					const attached = args[0]?.metadata?.attachedShaders;
					if (attached && args[1] && !attached.includes(args[1])) attached.push(args[1]);
					break;
				}
				case "detachShader": {
					const attached = args[0]?.metadata?.attachedShaders;
					const index = attached?.indexOf(args[1]) ?? -1;
					if (index >= 0) attached.splice(index, 1);
					break;
				}
				default: break;
			}
		}
		getParameter(pname) {
			if (this.state.has(pname)) {
				const value = this.state.get(pname);
				if (ArrayBuffer.isView(value)) return value.slice();
				return Array.isArray(value) ? value.slice() : value;
			}
			const parameters = this.capabilities?.parameters || {};
			if (Object.prototype.hasOwnProperty.call(parameters, pname)) return deserializeCanvasValue(parameters[pname]);
			return this.requestQuery("getParameter", [pname]);
		}
		getShaderParameter(shader, pname) {
			if (!(shader instanceof CanvasResource) || shader.resourceType !== "shader") return null;
			switch (pname) {
				case WEBGL_CONSTANTS.DELETE_STATUS: return shader.deleted;
				case WEBGL_CONSTANTS.SHADER_TYPE: return shader.metadata.shaderType;
				case WEBGL_CONSTANTS.COMPILE_STATUS: return Boolean(shader.metadata.compileStatus);
				default: return this.requestQuery("getShaderParameter", [shader, pname]);
			}
		}
		getProgramParameter(program, pname) {
			if (!(program instanceof CanvasResource) || program.resourceType !== "program") return null;
			switch (pname) {
				case WEBGL_CONSTANTS.DELETE_STATUS: return program.deleted;
				case WEBGL_CONSTANTS.LINK_STATUS: return Boolean(program.metadata.linkStatus);
				case WEBGL_CONSTANTS.VALIDATE_STATUS: return Boolean(program.metadata.validateStatus);
				case WEBGL_CONSTANTS.ATTACHED_SHADERS: return program.metadata.attachedShaders.length;
				default: return this.requestQuery("getProgramParameter", [program, pname]);
			}
		}
		getShaderPrecisionFormat(shaderType, precisionType) {
			const key = `${shaderType}:${precisionType}`;
			const value = this.capabilities?.shaderPrecisionFormats?.[key];
			return value ? { ...value } : this.requestQuery("getShaderPrecisionFormat", [shaderType, precisionType]);
		}
		getExtension(requestedName) {
			const requested = String(requestedName || "");
			const name = (this.capabilities?.supportedExtensions || []).find((item) => item.toLowerCase() === requested.toLowerCase());
			if (!name) return null;
			if (this.extensions.has(name)) return this.extensions.get(name);
			const extensionId = makeResourceId("webgl_extension");
			const descriptor = this.capabilities?.extensions?.[name] || {};
			const extension = new WebGLExtensionProxy(this, name, extensionId, descriptor);
			this.extensions.set(name, extension);
			this.canvas.enqueueOperation({
				op: "getExtension",
				contextId: this.contextId,
				extensionId,
				name
			});
			return extension;
		}
	};
	var CanvasNode = class {
		constructor({ nodeId, bridgeId = getCurrentBridgeId$1(), width = 300, height = 150, type = "2d", offscreen = false, webglCapabilities }) {
			this.__diminaCanvasNode = true;
			this.nodeId = nodeId;
			this.bridgeId = bridgeId;
			this.type = type;
			this.offscreen = offscreen;
			this.webglCapabilities = webglCapabilities || getWebGLCapabilities(bridgeId);
			this.contexts = /* @__PURE__ */ new Map();
			this.contextsById = /* @__PURE__ */ new Map();
			this.activeContextType = null;
			this.eventListeners = /* @__PURE__ */ new Map();
			this.pendingTypedArrayUpdates = /* @__PURE__ */ new Map();
			this.pendingOperations = [];
			this.flushScheduled = false;
			this._width = normalizeCanvasDimension(width, 300);
			this._height = normalizeCanvasDimension(height, 150);
		}
		get width() {
			return this._width;
		}
		set width(value) {
			this._width = normalizeCanvasDimension(value, 300);
			this.enqueueOperation({
				op: "setCanvasProperty",
				prop: "width",
				value: this._width
			});
		}
		get height() {
			return this._height;
		}
		set height(value) {
			this._height = normalizeCanvasDimension(value, 150);
			this.enqueueOperation({
				op: "setCanvasProperty",
				prop: "height",
				value: this._height
			});
		}
		getContext(type = "2d", attributes) {
			const requestedType = String(type).toLowerCase();
			const contextType = normalizeContextType(requestedType);
			const isWebGL = WEBGL_CONTEXT_TYPES.has(requestedType);
			if (!CONTEXT_2D_TYPES.has(contextType) && !isWebGL) return null;
			if (this.activeContextType && this.activeContextType !== contextType) return null;
			if (this.contexts.has(contextType)) return this.contexts.get(contextType);
			const capabilities = isWebGL ? getContextCapabilities(this.webglCapabilities, contextType) : null;
			if (isWebGL && capabilities?.supported === false) return null;
			const contextId = makeResourceId("canvas_context");
			this.enqueueOperation({
				op: "getContext",
				contextId,
				contextType: requestedType,
				attributes: serializeCanvasArg(attributes)
			});
			const context = isWebGL ? new WebGLRenderingContextProxy(this, contextId, contextType, attributes, capabilities) : new CanvasRenderingContext2DProxy(this, contextId);
			this.activeContextType = contextType;
			this.contexts.set(contextType, context);
			this.contextsById.set(contextId, context);
			return context;
		}
		addEventListener(type, listener) {
			if (!isFunction(listener)) return;
			if (!this.eventListeners.has(type)) this.eventListeners.set(type, /* @__PURE__ */ new Set());
			this.eventListeners.get(type).add(listener);
		}
		removeEventListener(type, listener) {
			this.eventListeners.get(type)?.delete(listener);
		}
		dispatchEvent(event) {
			if (!event?.type) return true;
			let defaultPrevented = false;
			const normalizedEvent = {
				...event,
				target: this,
				currentTarget: this,
				preventDefault() {
					defaultPrevented = true;
					this.defaultPrevented = true;
				}
			};
			for (const listener of this.eventListeners.get(event.type) || []) listener.call(this, normalizedEvent);
			const propertyHandler = this[`on${event.type}`];
			if (isFunction(propertyHandler)) propertyHandler.call(this, normalizedEvent);
			return !defaultPrevented;
		}
		notifyContextCreationError(statusMessage = "WebGL context creation failed") {
			this.dispatchEvent({
				type: "webglcontextcreationerror",
				statusMessage
			});
		}
		handleContextCreationFailure(contextId, contextType, statusMessage) {
			const context = this.contextsById.get(contextId);
			if (this.contexts.get(contextType) === context) {
				this.contexts.delete(contextType);
				this.activeContextType = null;
			}
			this.contextsById.delete(contextId);
			this.notifyContextCreationError(statusMessage);
		}
		registerTypedArrayUpdate(value) {
			const updateId = makeResourceId("canvas_typed_array_update");
			this.pendingTypedArrayUpdates.set(updateId, value);
			return updateId;
		}
		applyFlushFeedback(feedback = {}) {
			for (const [contextId, contextFeedback] of Object.entries(feedback.contexts || {})) this.contextsById.get(contextId)?.applyFeedback?.(contextFeedback);
			for (const update of feedback.typedArrays || []) {
				const target = this.pendingTypedArrayUpdates.get(update.id);
				if (target && ArrayBuffer.isView(target)) {
					const data = deserializeCanvasValue(update.value);
					if (ArrayBuffer.isView(data)) target.set(data.subarray(0, target.length));
					else if (Array.isArray(data)) target.set(data.slice(0, target.length));
				}
				this.pendingTypedArrayUpdates.delete(update.id);
			}
		}
		createImage() {
			return new CanvasImage(this, makeResourceId("canvas_image"));
		}
		requestAnimationFrame(fn) {
			const requestId = canvasRafSerial++;
			const callbackId = callback_default.store((timestamp) => {
				if (isFunction(fn)) fn(timestamp);
			});
			sendCanvasMessage(this.bridgeId, "canvasNodeRequestAnimationFrame", {
				nodeId: this.nodeId,
				requestId,
				callback: callbackId
			});
			return requestId;
		}
		cancelAnimationFrame(requestId) {
			sendCanvasMessage(this.bridgeId, "canvasNodeCancelAnimationFrame", {
				nodeId: this.nodeId,
				requestId
			});
		}
		getImageData({ contextId, x, y, width, height }) {
			return new Promise((resolve, reject) => {
				const callbackId = callback_default.store((res) => {
					resolve(res);
				});
				this.enqueueOperation({
					op: "getImageData",
					contextId,
					x,
					y,
					width,
					height,
					callback: callbackId
				});
			});
		}
		toDataURL(type = "image/png", quality) {
			return new Promise((resolve) => {
				const callbackId = callback_default.store((dataURL) => {
					resolve(dataURL);
				});
				this.enqueueOperation({
					op: "toDataURL",
					mimeType: type,
					quality,
					callback: callbackId
				});
			});
		}
		enqueueOperation(operation) {
			this.pendingOperations.push(operation);
			if (this.flushScheduled) return;
			this.flushScheduled = true;
			scheduleMicrotask(() => this.flushOperations());
		}
		flushOperations() {
			this.flushScheduled = false;
			if (this.pendingOperations.length === 0) return;
			const operations = this.pendingOperations;
			this.pendingOperations = [];
			const feedback = operations.some((operation) => operation.op === "getContext" || operation.op === "contextQuery" || operation.op === "contextFeedback" || operation.feedback || operation.typedArrayUpdateId) ? callback_default.store((result) => this.applyFlushFeedback(result)) : void 0;
			sendCanvasMessage(this.bridgeId, "canvasNodeFlush", {
				nodeId: this.nodeId,
				operations,
				feedback
			});
		}
	};
	function hydrateCanvasNode(node, bridgeId = getCurrentBridgeId$1()) {
		if (!node || node.__diminaNodeType !== "dimina-canvas-node") return node;
		setWebGLCapabilities(bridgeId, node.webglCapabilities);
		return new CanvasNode({
			nodeId: node.nodeId,
			bridgeId,
			width: node.width,
			height: node.height,
			type: node.type,
			webglCapabilities: node.webglCapabilities
		});
	}
	function hydrateSelectorQueryResult(value, bridgeId = getCurrentBridgeId$1()) {
		if (Array.isArray(value)) return value.map((item) => hydrateSelectorQueryResult(item, bridgeId));
		if (!value || typeof value !== "object") return value;
		if (value.node) return {
			...value,
			node: hydrateCanvasNode(value.node, bridgeId)
		};
		return value;
	}
	function createOffscreenCanvas(options = {}) {
		const width = normalizeCanvasDimension(options.width, 300);
		const height = normalizeCanvasDimension(options.height, 150);
		const type = options.type || "2d";
		const nodeId = makeResourceId("offscreen_canvas");
		const bridgeId = getCurrentBridgeId$1();
		sendCanvasMessage(bridgeId, "createOffscreenCanvas", {
			nodeId,
			width,
			height,
			type
		});
		return new CanvasNode({
			nodeId,
			bridgeId,
			width,
			height,
			type,
			offscreen: true,
			webglCapabilities: getWebGLCapabilities(bridgeId)
		});
	}
	//#endregion
	//#region src/api/core/wxml/selector-query/index.js
	var selector_query_exports = /* @__PURE__ */ __exportAll({ createSelectorQuery: () => createSelectorQuery });
	/**
	* 返回一个 SelectorQuery 对象实例。在自定义组件或包含自定义组件的页面中，应使用 this.createSelectorQuery() 来代替。
	* https://developers.weixin.qq.com/miniprogram/dev/framework/view/selector.html
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/wx.createSelectorQuery.html
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.html
	*/
	function createSelectorQuery() {
		return new SelectorQuery();
	}
	function getCurrentPageInfo() {
		return router_default.getPageInfo();
	}
	function getCurrentModuleId() {
		const pageInfo = getCurrentPageInfo();
		return pageInfo?.__id__ || pageInfo?.id;
	}
	function getCurrentBridgeId() {
		const pageInfo = getCurrentPageInfo();
		return pageInfo?.bridgeId || pageInfo?.id;
	}
	var SelectorQuery = class {
		constructor() {
			this.__componentId = getCurrentModuleId();
			this.__taskQueue = [];
			this.__cbQueue = [];
		}
		/**
		* 将选择器的选取范围更改为自定义组件 component 内。（初始时，选择器仅选取页面范围的节点，不会选取任何自定义组件中的节点）。
		* @param {Component} com
		* @returns {SelectorQuery} SelectorQuery
		*/
		in(com) {
			this.__componentId = com.__id__;
			return this;
		}
		/**
		* 在当前页面下选择第一个匹配选择器 selector 的节点。返回一个 NodesRef 对象实例，可以用于获取节点信息。
		* @param {string} selector
		* @returns {NodesRef} NodesRef
		*/
		select(selector) {
			return new NodesRef(this, this.__componentId, selector, true);
		}
		/**
		* 在当前页面下选择匹配选择器 selector 的所有节点。
		* @param {string} selector
		* @returns {NodesRef} NodesRef
		*/
		selectAll(selector) {
			return new NodesRef(this, this.__componentId, selector, false);
		}
		/**
		* 选择显示区域。可用于获取显示区域的尺寸、滚动位置等信息。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.selectViewport.html
		* @returns {NodesRef} NodesRef
		*/
		selectViewport() {
			return new NodesRef(this, getCurrentModuleId(), "", true);
		}
		/**
		*
		* @param {*} selector
		* @param {*} moduleId
		* @param {*} single
		* @param {*} fields
		* @param {*} callback
		*/
		__push(selector, moduleId, single, fields, callback) {
			this.__taskQueue.push({
				moduleId,
				selector,
				single,
				fields
			});
			this.__cbQueue.push(callback);
		}
		/**
		* 执行所有的请求。请求结果按请求次序构成数组，在callback的第一个参数中返回。
		* @param {Function} callback
		*/
		exec(callback) {
			const that = this;
			const bridgeId = getCurrentBridgeId();
			invokeAPI("selectorQuery", {
				tasks: this.__taskQueue,
				success: (res) => {
					const hydratedRes = hydrateSelectorQueryResult(res, bridgeId) || [];
					hydratedRes.forEach((nodeInfo, index) => {
						const cb = that.__cbQueue[index];
						if (isFunction(cb)) cb.call(that, nodeInfo);
					});
					if (isFunction(callback)) callback.call(that, hydratedRes);
				}
			}, "render");
		}
	};
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.html
	*/
	var NodesRef = class {
		constructor(selectorQuery, componentId, selector, single) {
			this.__selectorQuery = selectorQuery;
			this.__moduleId = componentId;
			this.__selector = selector;
			this.__single = single;
		}
		/**
		* 获取节点的相关信息。需要获取的字段在fields中指定。返回值是 nodesRef 对应的 selectorQuery
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.fields.html
		*/
		fields(fields, callback) {
			this.__selectorQuery.__push(this.__selector, this.__moduleId, this.__single, fields, callback);
			return this.__selectorQuery;
		}
		/**
		* 添加节点的布局位置的查询请求。相对于显示区域，以像素为单位。其功能类似于 DOM 的 getBoundingClientRect。返回 NodesRef 对应的 SelectorQuery
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.boundingClientRect.html
		*/
		boundingClientRect(callback) {
			return this.fields({
				id: true,
				dataset: true,
				rect: true,
				size: true
			}, callback);
		}
		/**
		* 添加节点的 Context 对象查询请求。
		* 目前支持 VideoContext、CanvasContext、LivePlayerContext、EditorContext和 MapContext 的获取。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.context.html
		*/
		context(callback) {
			return this.fields({ context: true }, callback);
		}
		/**
		* 获取 Node 节点实例
		* 目前支持 Canvas 和 ScrollViewContext 的获取。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.node.html
		*/
		node(callback) {
			return this.fields({ node: true }, callback);
		}
		/**
		* 添加节点的滚动位置查询请求。以像素为单位。节点必须是 scroll-view 或者 viewport，返回 NodesRef 对应的 SelectorQuery。
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.scrollOffset.html
		*/
		scrollOffset(callback) {
			return this.fields({
				id: true,
				dataset: true,
				scrollOffset: true
			}, callback);
		}
	};
	//#endregion
	//#region src/api/core/wxml/intersection-observer/index.js
	var intersection_observer_exports = /* @__PURE__ */ __exportAll({ createIntersectionObserver: () => createIntersectionObserver });
	/**
	* 创建并返回一个 IntersectionObserver 对象实例。在自定义组件或包含自定义组件的页面中，应使用 this.createIntersectionObserver([options]) 来代替。
	* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/wx.createIntersectionObserver.html
	*/
	function createIntersectionObserver(component, options = {}) {
		const { thresholds = [0], initialRatio = 0, observeAll = false } = options;
		return new IntersectionObserver(component, {
			thresholds,
			initialRatio,
			observeAll
		});
	}
	var IntersectionObserver = class {
		constructor(component, options) {
			this._component = component;
			this._options = options;
			this._relativeInfo = [];
			this._observerId = null;
			this._disconnected = false;
		}
		/**
		* 使用选择器指定一个节点，作为参照区域之一
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeTo.html
		*/
		relativeTo(selector, margins = {
			left: 0,
			right: 0,
			top: 0,
			bottom: 0
		}) {
			if (this._observerId !== null) throw new Error("Relative nodes cannot be added after \"observe\" call in IntersectionObserver");
			this._relativeInfo.push({
				selector,
				margins: [
					"left",
					"right",
					"top",
					"bottom"
				].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
			});
			return this;
		}
		/**
		* 指定页面显示区域作为参照区域之一
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeToViewport.html
		*/
		relativeToViewport(margins = {
			left: 0,
			right: 0,
			top: 0,
			bottom: 0
		}) {
			if (this._observerId !== null) throw new Error("Relative nodes cannot be added after \"observe\" call in IntersectionObserver");
			this._relativeInfo.push({
				selector: null,
				margins: [
					"left",
					"right",
					"top",
					"bottom"
				].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
			});
			return this;
		}
		/**
		* 指定目标节点并开始监听相交状态变化情况
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.observe.html
		*/
		observe(targetSelector, listener) {
			const that = this;
			const id = callback_default.store((res) => {
				if (!that._disconnected) that._observerId = res.observerId;
				if (res.info) listener.call(that, res.info);
			}, true);
			invokeAPI("addIntersectionObserver", {
				moduleId: this._component.__id__,
				targetSelector,
				relativeInfo: this._relativeInfo,
				options: this._options,
				success: id
			}, "render");
		}
		/**
		* 停止监听。回调函数将不再触发
		* https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.disconnect.html
		*/
		disconnect() {
			invokeAPI("removeIntersectionObserver", { observerId: this._observerId }, "render");
			this._disconnected = true;
		}
	};
	//#endregion
	//#region src/api/core/wxml/media-query-observer/index.js
	var media_query_observer_exports = /* @__PURE__ */ __exportAll({ createMediaQueryObserver: () => createMediaQueryObserver });
	function normalizeCondition(condition = {}) {
		const normalized = {};
		for (const key of [
			"minWidth",
			"maxWidth",
			"width",
			"minHeight",
			"maxHeight",
			"height"
		]) {
			const value = Number(condition[key]);
			if (Number.isFinite(value) && value >= 0) normalized[key] = value;
		}
		if (typeof condition.orientation === "string" && /^[-_a-z0-9]+$/i.test(condition.orientation)) normalized.orientation = condition.orientation;
		return normalized;
	}
	function createMediaQueryObserver(component, options = {}) {
		return new MediaQueryObserver(component, options);
	}
	var MediaQueryObserver = class {
		constructor(component, options) {
			this._component = component;
			this._options = options;
			this._observerId = null;
			this._callbackId = null;
			this._disconnected = false;
		}
		observe(condition, listener) {
			if (!isFunction(listener)) throw new TypeError("MediaQueryObserver.observe listener must be a function");
			if (this._observerId !== null) throw new Error("MediaQueryObserver.observe can only be called once");
			this._disconnected = false;
			this._callbackId = callback_default.store((res = {}) => {
				if (res.observerId) {
					this._observerId = res.observerId;
					if (this._disconnected) {
						invokeAPI("removeMediaQueryObserver", { observerId: res.observerId }, "render");
						callback_default.remove(this._callbackId);
						this._callbackId = null;
						return;
					}
				}
				if (!this._disconnected && typeof res.matches === "boolean") listener.call(this, { matches: res.matches });
			}, true);
			invokeAPI("addMediaQueryObserver", {
				moduleId: this._component.__id__,
				condition: normalizeCondition(condition),
				options: this._options,
				success: this._callbackId
			}, "render");
		}
		disconnect() {
			this._disconnected = true;
			invokeAPI("removeMediaQueryObserver", { observerId: this._observerId }, "render");
			if (this._callbackId && this._observerId) {
				callback_default.remove(this._callbackId);
				this._callbackId = null;
			}
		}
	};
	//#endregion
	//#region src/core/data-update.js
	/**
	* Parse a mini-program setData path.
	*
	* Unlike lodash paths, brackets only accept array indexes. Dots and brackets
	* can be used as literal key characters when escaped with a backslash.
	*/
	function parseDataPath(path) {
		if (typeof path !== "string" || path.length === 0) return null;
		const parts = [];
		let token = "";
		let index = 0;
		const pushToken = () => {
			if (token.length > 0) {
				parts.push(token);
				token = "";
			}
		};
		while (index < path.length) {
			const char = path[index];
			if (char === "\\") {
				const escaped = path[index + 1];
				if (escaped === "." || escaped === "[" || escaped === "]" || escaped === "\\") {
					token += escaped;
					index += 2;
					continue;
				}
				token += char;
				index++;
				continue;
			}
			if (char === ".") {
				pushToken();
				index++;
				continue;
			}
			if (char === "[") {
				if (parts.length === 0 && token.length === 0) return null;
				pushToken();
				const closingIndex = path.indexOf("]", index + 1);
				if (closingIndex === -1) return null;
				const arrayIndex = path.slice(index + 1, closingIndex);
				if (!/^\d+$/.test(arrayIndex)) return null;
				parts.push(Number(arrayIndex));
				index = closingIndex + 1;
				continue;
			}
			if (char === "]") return null;
			token += char;
			index++;
		}
		pushToken();
		return parts.length > 0 ? parts : null;
	}
	function setDataPathValue(target, path, value) {
		let current = target;
		for (let index = 0; index < path.length - 1; index++) {
			const key = path[index];
			const nextKey = path[index + 1];
			const hasOwnValue = Object.prototype.hasOwnProperty.call(current, key);
			if (typeof nextKey === "number") {
				if (!hasOwnValue || !Array.isArray(current[key])) current[key] = [];
			} else if (!hasOwnValue || current[key] === null || typeof current[key] !== "object" || Array.isArray(current[key])) current[key] = {};
			current = current[key];
		}
		current[path[path.length - 1]] = value;
	}
	function isPathPrefix(prefix, path) {
		return prefix.length <= path.length && prefix.every((part, index) => part === path[index]);
	}
	function parseObserverExpression(expression) {
		const paths = expression.split(",").map((item) => item.trim()).filter(Boolean);
		const parsedPaths = [];
		for (const path of paths) {
			if (path === "**") {
				parsedPaths.push({
					path: [],
					wildcard: true
				});
				continue;
			}
			const wildcard = path.endsWith(".**");
			const parsed = parseDataPath(wildcard ? path.slice(0, -3) : path);
			if (parsed) parsedPaths.push({
				path: parsed,
				wildcard
			});
		}
		return parsedPaths;
	}
	function observerPathMatches(observerPath, changedPath) {
		if (observerPath.wildcard && observerPath.path.length === 0) return true;
		if (observerPath.wildcard) return isPathPrefix(observerPath.path, changedPath) || isPathPrefix(changedPath, observerPath.path);
		return isPathPrefix(changedPath, observerPath.path);
	}
	function getObserverDescriptors(info) {
		const descriptors = [];
		if (Array.isArray(info.behaviorObserverList) && info.behaviorObserverList.length > 0) for (const { key, observer } of info.behaviorObserverList) descriptors.push({
			expression: key,
			observer
		});
		else for (const [expression, observers] of Object.entries(info.behaviorObservers || {})) for (const observer of observers || []) descriptors.push({
			expression,
			observer
		});
		for (const [expression, observer] of Object.entries(info.observers || {})) descriptors.push({
			expression,
			observer
		});
		return descriptors.map((descriptor) => ({
			...descriptor,
			paths: parseObserverExpression(descriptor.expression)
		}));
	}
	/** Invoke matching data observers once, in their registration order. */
	function invokeDataObservers(ctx, changedPaths, data = ctx.data, info = ctx.__info__ || {}) {
		for (const descriptor of getObserverDescriptors(info)) {
			if (!isFunction(descriptor.observer)) continue;
			if (!descriptor.paths.some((path) => changedPaths.some((changedPath) => observerPathMatches(path, changedPath)))) continue;
			const args = descriptor.paths.map(({ path }) => path.length === 0 ? data : get(data, path));
			invokeSafely(ctx, descriptor.observer, args, "data observer");
		}
	}
	function makeChangedData(ctx, changes) {
		const changedData = {};
		for (const change of changes) changedData[change.key] = get(ctx.data, change.path);
		return changedData;
	}
	function collectPropertyChanges(ctx, changes) {
		const properties = ctx.__info__?.properties || {};
		return changes.flatMap((change) => {
			const propertyName = change.path[0];
			if (typeof propertyName !== "string" || !Object.prototype.hasOwnProperty.call(properties, propertyName)) return [];
			return [{
				propertyName,
				oldValue: change.path.length === 1 ? change.oldValue : void 0,
				path: change.path,
				value: change.value
			}];
		});
	}
	/**
	* Apply one setData transaction. setData calls made by a data observer join the
	* same transaction and are drained in a following observer pass.
	*/
	function applyDataUpdates(ctx, data, callback) {
		if (!data || typeof data !== "object" || Array.isArray(data)) {
			console.warn("[service] setData data must be an object");
			return null;
		}
		const outermost = !ctx.__dataUpdateTransaction__;
		const transaction = ctx.__dataUpdateTransaction__ || {
			changes: [],
			pendingPaths: [],
			callbacks: []
		};
		ctx.__dataUpdateTransaction__ = transaction;
		if (isFunction(callback)) transaction.callbacks.push(callback);
		for (const key of Object.keys(data)) {
			const path = parseDataPath(key);
			if (!path) {
				console.warn(`[service] invalid setData path: ${key}`);
				continue;
			}
			let value = cloneDeep(data[key]);
			if (path.length === 1 && ctx.__propertySchemas__?.[path[0]] && isFunction(ctx.normalizePropertyValues)) value = ctx.normalizePropertyValues({ [path[0]]: value })[path[0]];
			const oldValue = path.length === 1 ? ctx.data[path[0]] : void 0;
			setDataPathValue(ctx.data, path, value);
			transaction.changes.push({
				key,
				path,
				oldValue,
				value
			});
			transaction.pendingPaths.push(path);
		}
		if (!outermost) return null;
		try {
			while (transaction.pendingPaths.length > 0) {
				const changedPaths = transaction.pendingPaths;
				transaction.pendingPaths = [];
				invokeDataObservers(ctx, changedPaths);
			}
		} finally {
			delete ctx.__dataUpdateTransaction__;
		}
		return {
			callbacks: transaction.callbacks,
			changedData: makeChangedData(ctx, transaction.changes),
			changes: transaction.changes.map((change) => ({
				path: change.path,
				value: change.value
			})),
			propertyChanges: collectPropertyChanges(ctx, transaction.changes)
		};
	}
	function invokePropertyChanges(ctx, propertyChanges) {
		const properties = ctx.__info__?.properties || {};
		for (const change of propertyChanges) {
			const definition = properties[change.propertyName];
			const observer = definition?.observer;
			const path = change.path;
			const value = Object.prototype.hasOwnProperty.call(change, "value") ? change.value : path.length === 1 ? ctx.data[change.propertyName] : get(ctx.data, path);
			if (path.length === 1 && value === change.oldValue && !definition?.observeAssignments) continue;
			if (isString(observer)) invokeSafely(ctx, ctx[observer], [
				value,
				change.oldValue,
				path
			], "property observer");
			else if (isFunction(observer)) invokeSafely(ctx, observer, [
				value,
				change.oldValue,
				path
			], "property observer");
		}
	}
	//#endregion
	//#region src/core/update-queue.js
	var queues = /* @__PURE__ */ new Map();
	function getQueue(bridgeId) {
		if (!queues.has(bridgeId)) queues.set(bridgeId, {
			depth: 0,
			scheduled: false,
			updates: [],
			byModuleId: /* @__PURE__ */ new Map(),
			callbackIds: []
		});
		return queues.get(bridgeId);
	}
	function createUpdateCallback(ctx, callbacks) {
		const callbackList = (Array.isArray(callbacks) ? callbacks : [callbacks]).filter(isFunction);
		if (callbackList.length === 0) return;
		return callback_default.store(() => {
			callbackList.forEach((cb) => invokeSafely(ctx, cb, [], "setData callback"));
		});
	}
	function beginUpdateBatch(bridgeId) {
		const queue = getQueue(bridgeId);
		queue.depth++;
	}
	function endUpdateBatch(bridgeId) {
		const queue = getQueue(bridgeId);
		if (queue.depth > 0) queue.depth--;
		if (queue.depth === 0) flushUpdates(bridgeId);
	}
	function snapshotUpdate(data, changes = []) {
		const normalizedChanges = changes.length > 0 ? changes : Object.entries(data).flatMap(([key, value]) => {
			const path = parseDataPath(key);
			return path ? [{
				path,
				value
			}] : [];
		});
		const snapshot = JSON.parse(JSON.stringify(encodeDataFunctions({
			data,
			changes: normalizedChanges
		})));
		return {
			data: snapshot.data || {},
			changes: (snapshot.changes || []).filter((change) => Object.prototype.hasOwnProperty.call(change, "value"))
		};
	}
	function enqueueUpdate(bridgeId, moduleId, data, callbackId, changes = []) {
		const queue = getQueue(bridgeId);
		const update = queue.byModuleId.get(moduleId);
		const snapshot = snapshotUpdate(data, changes);
		if (update) {
			Object.assign(update.data, snapshot.data);
			update.changes.push(...snapshot.changes);
		} else {
			const nextUpdate = {
				moduleId,
				data: snapshot.data,
				changes: snapshot.changes
			};
			queue.byModuleId.set(moduleId, nextUpdate);
			queue.updates.push(nextUpdate);
		}
		if (callbackId) queue.callbackIds.push(callbackId);
		if (queue.depth === 0 && !queue.scheduled) {
			queue.scheduled = true;
			Promise.resolve().then(() => {
				queue.scheduled = false;
				if (queue.depth === 0) flushUpdates(bridgeId);
			});
		}
	}
	function flushUpdates(bridgeId) {
		const queue = queues.get(bridgeId);
		if (!queue || queue.updates.length === 0) return;
		const updates = queue.updates;
		const callbackIds = queue.callbackIds;
		queue.updates = [];
		queue.byModuleId = /* @__PURE__ */ new Map();
		queue.callbackIds = [];
		queue.scheduled = false;
		message_default.send({
			type: "ub",
			target: "render",
			body: {
				bridgeId,
				updates,
				callbackIds
			}
		});
	}
	//#endregion
	//#region src/core/utils.js
	function filterData(obj) {
		if (isNil(obj)) return obj;
		if (isFunction(obj)) return obj;
		if (obj instanceof Date) return obj.getTime();
		if (Array.isArray(obj)) return obj.map((item) => filterData(item));
		if (typeof obj !== "object") return obj;
		return Object.entries(obj).reduce((acc, [key, value]) => {
			if (key.startsWith("$")) return acc;
			else acc[key] = filterData(value);
			return acc;
		}, {});
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html
	*
	* @param {{type, optionalTypes, value, observer}} properties
	*/
	function serializeProps(properties) {
		if (properties) {
			const props = {};
			for (const key in properties) {
				const schema = normalizePropertyDefinition(properties[key]);
				props[key] = {
					type: [schema.type, ...schema.optionalTypes].map(convertToStringType),
					default: schema.value
				};
			}
			return props;
		}
	}
	var TYPE_TO_STRING_MAP = /* @__PURE__ */ new Map([
		[String, "s"],
		[Number, "n"],
		[Boolean, "b"],
		[Object, "o"],
		[Array, "a"]
	]);
	/**
	* 属性的类型可以为 String Number Boolean Object Array 其一，也可以为 null 表示不限制类型。
	* 将实际类型转换成字符串方便传输
	* @param {*} type
	*/
	function convertToStringType(type) {
		if (Array.isArray(type)) return type.map((item) => convertToStringType(item));
		else {
			if (type === null || type === "") return null;
			const stringType = TYPE_TO_STRING_MAP.get(type);
			if (stringType) return stringType;
			console.warn(`[service] ignore unknown props type ${type}`);
			return null;
		}
	}
	function resolveEventBinding(eventAttr = {}, type = "") {
		const normalizedType = type.trim();
		if (!normalizedType) return;
		const compactType = normalizedType.replace(/-/g, "").toLowerCase();
		const candidates = [
			normalizedType,
			toCamelCase(normalizedType),
			camelCaseToUnderscore(normalizedType),
			compactType
		];
		for (const candidate of candidates) if (candidate && eventAttr[candidate] !== void 0) {
			const binding = eventAttr[candidate];
			if (typeof binding === "string") return { bind: binding };
			if (binding && typeof binding === "object") return binding;
		}
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
	* 
	* 同名字段的覆盖和组合规则：
	* 1. properties 和 methods: 组件覆盖 behavior, 靠后的 behavior 覆盖靠前的, 引用者覆盖被引用者
	* 2. data: 对象类型深度合并, 其他类型按优先级覆盖
	* 3. 生命周期和 observers: 不覆盖, 按顺序执行 (被引用的 > 引用者 > 靠前的 > 靠后的)
	* 4. 同一个 behavior 被多次引用时不会重复执行
	* 
	* @param {*} obj
	* @param {*} behaviors
	*/
	function mergeBehaviors(obj, behaviors) {
		if (!Array.isArray(behaviors)) return;
		const processedBehaviors = /* @__PURE__ */ new WeakMap();
		const activeBehaviors = /* @__PURE__ */ new WeakSet();
		const componentProperties = obj.properties;
		const componentData = obj.data;
		const componentMethods = obj.methods;
		const componentRelations = obj.relations;
		const hasComponentExport = Object.prototype.hasOwnProperty.call(obj, "export");
		const componentExport = obj.export;
		let behaviorProperties;
		let behaviorData;
		let behaviorMethods;
		let behaviorRelations;
		let behaviorExport;
		/**
		* 深度合并对象类型的 data 字段
		* @param {object} target 目标对象
		* @param {object} source 源对象
		* @returns {object} 合并后的对象
		*/
		function deepMergeData(target, source) {
			const result = Array.isArray(target) ? [...target] : { ...target };
			for (const key in source) if (Object.prototype.hasOwnProperty.call(source, key)) {
				const targetValue = result[key];
				const sourceValue = source[key];
				if (typeof targetValue === "object" && sourceValue !== null && typeof sourceValue === "object" && !Array.isArray(sourceValue)) result[key] = deepMergeData(targetValue, sourceValue);
				else result[key] = sourceValue;
			}
			return result;
		}
		/**
		* 递归合并单个 behavior
		* @param {object} target 目标对象
		* @param {object} behavior behavior 对象
		*/
		function merge(target, behavior) {
			if (typeof behavior === "string") {
				handleBuiltinBehavior(target, behavior);
				return;
			}
			if (!behavior || typeof behavior !== "object") return;
			if (activeBehaviors.has(behavior)) return;
			activeBehaviors.add(behavior);
			const callbacksAlreadyProcessed = processedBehaviors.has(behavior);
			if (Array.isArray(behavior.behaviors)) behavior.behaviors.forEach((b) => merge(target, b));
			if (behavior.properties) behaviorProperties = {
				...behaviorProperties,
				...behavior.properties
			};
			if (behavior.data) behaviorData = deepMergeData(behaviorData || {}, behavior.data);
			if (!callbacksAlreadyProcessed) {
				processedBehaviors.set(behavior, true);
				const lifetimes = [
					"created",
					"attached",
					"ready",
					"moved",
					"detached",
					"error"
				];
				target.behaviorLifetimes = target.behaviorLifetimes || {};
				for (const lifetime of lifetimes) {
					const lifecycleMethod = behavior.lifetimes?.[lifetime] || behavior[lifetime];
					if (isFunction(lifecycleMethod)) {
						target.behaviorLifetimes[lifetime] = target.behaviorLifetimes[lifetime] || [];
						target.behaviorLifetimes[lifetime].push(lifecycleMethod);
					}
				}
				if (behavior.observers) {
					target.behaviorObservers = target.behaviorObservers || {};
					target.behaviorObserverList = target.behaviorObserverList || [];
					for (const observerKey in behavior.observers) {
						if (!target.behaviorObservers[observerKey]) target.behaviorObservers[observerKey] = [];
						target.behaviorObservers[observerKey].push(behavior.observers[observerKey]);
						target.behaviorObserverList.push({
							key: observerKey,
							observer: behavior.observers[observerKey]
						});
					}
				}
			}
			if (behavior.methods) behaviorMethods = {
				...behaviorMethods,
				...behavior.methods
			};
			if (behavior.relations) behaviorRelations = {
				...behaviorRelations,
				...behavior.relations
			};
			if (behavior.export) behaviorExport = behavior.export;
			if (!callbacksAlreadyProcessed && behavior.pageLifetimes) {
				target.behaviorPageLifetimes = target.behaviorPageLifetimes || {};
				for (const lifetime of [
					"show",
					"hide",
					"resize",
					"routeDone"
				]) if (isFunction(behavior.pageLifetimes[lifetime])) {
					target.behaviorPageLifetimes[lifetime] = target.behaviorPageLifetimes[lifetime] || [];
					target.behaviorPageLifetimes[lifetime].push(behavior.pageLifetimes[lifetime]);
				}
			}
			activeBehaviors.delete(behavior);
		}
		/**
		* 处理内置 behavior
		* @param {object} target 目标对象
		* @param {string} behaviorName behavior 名称
		*/
		function handleBuiltinBehavior(target, behaviorName) {
			switch (behaviorName) {
				case "wx://component-export": break;
				case "wx://form-field":
					behaviorProperties = {
						...behaviorProperties,
						name: { type: String },
						value: { type: null }
					};
					break;
				case "wx://form-field-group":
				case "wx://form-field-button":
				case "wx://label-target":
				case "wx://style-filter":
				case "wx://request-filter": break;
				default: console.warn(`[service] 未知的内置 behavior: ${behaviorName}`);
			}
		}
		behaviors.forEach((behavior) => merge(obj, behavior));
		if (behaviorProperties || componentProperties) obj.properties = {
			...behaviorProperties,
			...componentProperties
		};
		if (behaviorData || componentData) obj.data = deepMergeData(behaviorData || {}, componentData || {});
		if (behaviorMethods || componentMethods) obj.methods = {
			...behaviorMethods,
			...componentMethods
		};
		if (behaviorRelations || componentRelations) obj.relations = {
			...behaviorRelations,
			...componentRelations
		};
		if (hasComponentExport) obj.export = componentExport;
		else if (behaviorExport) obj.export = behaviorExport;
	}
	/**
	* 检查一个组件是否是指定组件的子组件(包括深层嵌套)
	* ComponentA (__id__: 'a')
	└─ ComponentB (__id__: 'b', __parentId__: 'a')
	└─ ComponentC (__id__: 'c', __parentId__: 'b', class: 'target')
	* @param {object} component 待检查的组件
	* @param {string} parentId 父组件ID
	* @param {Array} allComponents 所有组件列表
	* @returns {boolean} 是否为子组件
	*/
	function isChildComponent(component, parentId, allComponents) {
		let parent = component;
		while (parent && parent.__parentId__) {
			if (parent.__parentId__ === parentId) return true;
			parent = allComponents.find((item) => item.__id__ === parent.__parentId__);
		}
		return false;
	}
	/**
	* 根据选择器匹配组件
	* @param {string} selector 选择器
	* @param {object} item 待匹配的组件
	* @returns {boolean} 是否匹配
	*/
	function matchComponent(selector, item) {
		if (!selector || !item) return false;
		if (selector.startsWith("#")) {
			const id = selector.slice(1);
			return item.id === id;
		}
		if (selector.startsWith(".")) {
			const className = selector.slice(1);
			return item.__targetInfo__?.class && item.__targetInfo__.class.split(" ").includes(className);
		}
		if (selector.startsWith("[") && selector.endsWith("]")) {
			const attrMatch = selector.slice(1, -1).match(/^(\w+)(?:=["']?([^"']*)["']?)?$/);
			if (attrMatch) {
				const [, attrName, attrValue] = attrMatch;
				const dataset = item.__targetInfo__?.dataset || {};
				if (attrValue === void 0) return Object.prototype.hasOwnProperty.call(dataset, attrName);
				return dataset[attrName] === attrValue;
			}
			return false;
		}
		if (item.is) return item.is.split("/").pop() === selector || item.is === selector;
		return false;
	}
	/**
	* 检查表达式的依赖是否发生变化
	* @param {object} bindingInfo 绑定信息对象（包含 expression, dependencies, isSimple）
	* @param {object} changedData 变化的数据
	* @returns {boolean} 是否有依赖变化
	*/
	function hasDependencyChanged(bindingInfo, changedData) {
		if (!bindingInfo || !Array.isArray(bindingInfo.dependencies)) return false;
		for (const dep of bindingInfo.dependencies) {
			if (dep in changedData) return true;
			for (const changedKey of Object.keys(changedData)) {
				if (changedKey.startsWith(dep + ".") || changedKey.startsWith(dep + "[")) return true;
				if (dep.startsWith(changedKey + ".") || dep.startsWith(changedKey + "[")) return true;
			}
		}
		return false;
	}
	/**
	* 计算表达式的新值
	* @param {object} bindingInfo 绑定信息对象（包含 expression, dependencies, isSimple）
	* @param {object} parentData 父组件的完整数据
	* @returns {*} 计算后的值
	*/
	function evaluateExpression(bindingInfo, parentData) {
		if (!bindingInfo || !bindingInfo.expression) return;
		if (bindingInfo.isSimple) return get(parentData, bindingInfo.expression);
		try {
			return new Function("data", `with(data) { return ${bindingInfo.expression} }`)(parentData);
		} catch (error) {
			console.warn("[service] 计算表达式失败:", bindingInfo.expression, error);
			return;
		}
	}
	/**
	* 同步更新子组件的 properties
	* 在父组件/页面 setData 时，同步更新所有受影响的子组件，确保 selectComponent 能立即获取到最新值
	* 完全依赖编译器提供的绑定关系，支持复杂表达式
	* @param {object} parent 父组件或页面实例
	* @param {object} allInstances 所有组件实例对象（来自 runtime.instances[bridgeId]）
	* @param {object} changedData 父组件变化的数据（新值）
	*/
	function syncUpdateChildrenProps(parent, allInstances, changedData) {
		const children = Object.values(allInstances || {});
		const syncedChildren = [];
		for (const child of children) {
			if (!isChildComponent(child, parent.__id__, children) || child.__parentId__ !== parent.__id__) continue;
			const childProperties = child.__info__?.properties || {};
			const updateData = {};
			for (const propName in childProperties) {
				const bindingInfo = parent.__childPropsBindings__?.[child.__id__]?.[propName];
				if (!bindingInfo) continue;
				if (hasDependencyChanged(bindingInfo, changedData)) updateData[propName] = cloneDeep(evaluateExpression(bindingInfo, parent.data));
			}
			if (Object.keys(updateData).length > 0) {
				const incomingData = child.normalizePropertyValues?.(updateData, { applyFilter: false }) || updateData;
				const normalizedData = child.tO?.(incomingData) || child.normalizePropertyValues?.(incomingData) || incomingData;
				child.__pendingSyncedProps__ = child.__pendingSyncedProps__ || {};
				Object.assign(child.__pendingSyncedProps__, incomingData);
				syncedChildren.push({
					child,
					data: normalizedData
				});
			}
		}
		return syncedChildren;
	}
	//#endregion
	//#region src/instance/component/component.js
	var componentLifetimes = [
		"created",
		"attached",
		"ready",
		"moved",
		"detached",
		"error"
	];
	var pageLifetimes = [
		"show",
		"hide",
		"resize",
		"routeDone"
	];
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html
	*/
	var Component = class Component {
		constructor(module, opts) {
			this.initd = false;
			this.opts = opts;
			if (opts.targetInfo) {
				this.id = opts.targetInfo.id;
				this.dataset = opts.targetInfo.dataset;
				this.__targetInfo__ = opts.targetInfo;
			}
			this.is = opts.path;
			this.route = opts.path;
			this.query = opts.query;
			this.renderer = "webview";
			this.bridgeId = opts.bridgeId;
			if (!this.id) this.id = opts.bridgeId;
			this.behaviors = module.behaviors;
			this.data = cloneDeep(module.noReferenceData);
			Object.defineProperty(this, "properties", {
				get() {
					return this.data;
				},
				enumerable: true,
				configurable: false
			});
			this.__isComponent__ = module.isComponent;
			this.__type__ = module.type;
			this.__id__ = this.opts.moduleId;
			this.__info__ = module.moduleInfo;
			this.__eventAttr__ = opts.eventAttr;
			this.__eventPath__ = null;
			this.__pageId__ = opts.pageId;
			this.__parentId__ = opts.parentId;
			this.__isCustomTabBar__ = opts.isCustomTabBar === true;
			this.__relations__ = /* @__PURE__ */ new Map();
			this.__relationPaths__ = /* @__PURE__ */ new Map();
			this.__groupSetDataMode__ = false;
			this.__groupSetDataBuffer__ = {};
			this.__groupSetDataChanges__ = [];
			this.__groupSetDataCallbacks__ = [];
			this.__pendingInitSetDataCallbacks__ = [];
			this.__childPropsBindings__ = {};
			this.__pendingSyncedProps__ = {};
			this.__initialPropertyObserversInvoked__ = false;
			this.__initialPropertyNames__ = new Set(opts.propertyNames || Object.keys(opts.properties || {}));
			this.__initialPropertyChanges__ = [];
			this.__initialPropertyValues__ = {};
			this.__propertySchemas__ = Object.fromEntries(Object.entries(this.__info__.properties || {}).map(([name, definition]) => [name, normalizePropertyDefinition(definition)]));
		}
		init({ deferInitialData = false } = {}) {
			this.#initCustomMethods();
			if (this.__isComponent__) {
				const initialProperties = this.opts.properties || {};
				for (const [key, schema] of Object.entries(this.__propertySchemas__)) {
					const absentValue = resolvePropertyValue(schema, void 0, { absent: true });
					this.data[key] = absentValue;
					if (this.__initialPropertyNames__.has(key)) {
						const value = this.normalizePropertyValue(key, initialProperties[key], { applyFilter: false });
						this.__initialPropertyValues__[key] = value;
						this.__initialPropertyChanges__.push({
							propertyName: key,
							oldValue: void 0,
							path: [key],
							value
						});
					}
				}
			}
			this.#initLifecycle();
			this.#initRelations();
			this.#initComponentExport();
			this.#invokeInitLifecycle();
			if (!deferInitialData) this.sendInitialData();
		}
		sendInitialData() {
			if (this.__initialDataSent__) return;
			this.__initialDataSent__ = true;
			message_default.send({
				type: this.__id__,
				target: "render",
				body: {
					bridgeId: this.bridgeId,
					path: this.is,
					data: this.data
				}
			});
		}
		flushInitSetDataCallbacks() {
			if (this.__pendingInitSetDataCallbacks__.length === 0) return;
			const callbacks = this.__pendingInitSetDataCallbacks__;
			this.__pendingInitSetDataCallbacks__ = [];
			enqueueUpdate(this.bridgeId, this.__id__, {}, createUpdateCallback(this, callbacks));
		}
		/**
		* 初始化组件导出功能
		* 处理 wx://component-export behavior
		*/
		#initComponentExport() {
			if (this.hasBehavior("wx://component-export")) {
				if (this.__info__.export && isFunction(this.__info__.export)) this.export = this.__info__.export.bind(this);
			}
		}
		/**
		* 初始化组件间关系
		*/
		#initRelations() {
			const relations = this.__info__.relations;
			if (!relations || typeof relations !== "object") return;
			for (const [relationPath] of Object.entries(relations)) {
				const resolvedPath = this.#resolveRelationPath(relationPath);
				this.__relationPaths__.set(relationPath, resolvedPath);
				if (!this.__relations__.has(relationPath)) this.__relations__.set(relationPath, []);
			}
		}
		/**
		* 解析关系路径，将相对路径转换为绝对路径
		*/
		#resolveRelationPath(relationPath) {
			if (relationPath.startsWith("./")) {
				const lastSlashIndex = this.is.lastIndexOf("/");
				if (lastSlashIndex === -1) return relationPath.substring(2);
				return `${this.is.substring(0, lastSlashIndex)}/${relationPath.substring(2)}`;
			} else if (relationPath.startsWith("../")) {
				const pathParts = this.is.split("/");
				const relationParts = relationPath.split("/");
				let currentParts = pathParts.slice(0, -1);
				for (const part of relationParts) if (part === "..") currentParts.pop();
				else if (part !== ".") currentParts.push(part);
				return currentParts.join("/");
			} else return relationPath;
		}
		/**
		* 检查组件关系并建立连接
		*/
		#checkAndLinkRelations() {
			const relations = this.__info__.relations;
			if (!relations) return;
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {}).filter((instance) => instance === this || !instance.__isComponent__ || instance.__componentAttached__ || instance.__componentAttaching__);
			for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const { type, target } = relationConfig;
				const resolvedPath = this.__relationPaths__.get(relationPath);
				const relatedComponents = allInstances.filter((instance) => {
					if (target) return instance.hasBehavior && instance.hasBehavior(target);
					else return instance.is === resolvedPath || instance.is.endsWith(`/${resolvedPath}`);
				}).filter((instance) => this.#checkRelationType(instance, type));
				for (const relatedComponent of relatedComponents) this.#linkRelation(relationPath, relatedComponent, relationConfig);
			}
			this.#notifyOthersToCheckRelations();
		}
		/**
		* 通知其他组件重新检查关系
		*/
		#notifyOthersToCheckRelations() {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			for (const instance of allInstances) if (instance !== this && instance._checkRelationsWithTarget) instance._checkRelationsWithTarget(this);
		}
		/**
		* 检查与特定目标组件的关系
		*/
		_checkRelationsWithTarget(targetInstance) {
			const relations = this.__info__.relations;
			if (!relations) return;
			for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const { type, target } = relationConfig;
				const resolvedPath = this.__relationPaths__.get(relationPath);
				let matches = false;
				if (target) matches = targetInstance.hasBehavior && targetInstance.hasBehavior(target);
				else matches = targetInstance.is === resolvedPath || targetInstance.is.endsWith(`/${resolvedPath}`);
				if (matches && this.#checkRelationType(targetInstance, type)) this.#linkRelation(relationPath, targetInstance, relationConfig);
			}
		}
		/**
		* 检查关系类型是否匹配
		*/
		#checkRelationType(targetInstance, relationType) {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			switch (relationType) {
				case "parent": return targetInstance.__id__ === this.__parentId__;
				case "child": return targetInstance.__parentId__ === this.__id__;
				case "ancestor": return this.#isAncestor(targetInstance.__id__, this.__id__, allInstances);
				case "descendant": return this.#isAncestor(this.__id__, targetInstance.__id__, allInstances);
				default: return false;
			}
		}
		/**
		* 检查 ancestorId 是否是 descendantId 的祖先
		*/
		#isAncestor(ancestorId, descendantId, allInstances) {
			let current = allInstances.find((instance) => instance.__id__ === descendantId);
			while (current && current.__parentId__) {
				if (current.__parentId__ === ancestorId) return true;
				current = allInstances.find((instance) => instance.__id__ === current.__parentId__);
			}
			return false;
		}
		/**
		* 建立关系连接
		*/
		#linkRelation(relationPath, targetInstance, relationConfig) {
			const relationNodes = this.__relations__.get(relationPath) || [];
			if (relationNodes.includes(targetInstance)) return;
			relationNodes.push(targetInstance);
			this.__relations__.set(relationPath, relationNodes);
			invokeSafely(this, relationConfig.linked, [targetInstance], "relation linked callback");
		}
		/**
		* 移除关系连接
		*/
		#unlinkRelation(relationPath, targetInstance, relationConfig) {
			const relationNodes = this.__relations__.get(relationPath) || [];
			const index = relationNodes.indexOf(targetInstance);
			if (index === -1) return;
			relationNodes.splice(index, 1);
			this.__relations__.set(relationPath, relationNodes);
			invokeSafely(this, relationConfig.unlinked, [targetInstance], "relation unlinked callback");
		}
		/**
		* 处理关系变化
		*/
		#handleRelationChange(relationPath, targetInstance, relationConfig) {
			invokeSafely(this, relationConfig.linkChanged, [targetInstance], "relation linkChanged callback");
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/performance/tips/runtime_setData.html
		* @param {*} data
		*/
		setData(data, callback) {
			const update = applyDataUpdates(this, data, callback);
			if (!update) return;
			if (!this.initd) {
				this.__pendingInitSetDataCallbacks__.push(...update.callbacks);
				invokePropertyChanges(this, update.propertyChanges);
				return;
			}
			if (this.__groupSetDataMode__) {
				for (const key of Object.keys(update.changedData)) this.__groupSetDataBuffer__[key] = update.changedData[key];
				this.__groupSetDataChanges__.push(...update.changes);
				this.__groupSetDataCallbacks__.push(...update.callbacks);
				invokePropertyChanges(this, update.propertyChanges);
				return;
			}
			const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], update.changedData);
			enqueueUpdate(this.bridgeId, this.__id__, update.changedData, createUpdateCallback(this, update.callbacks), update.changes);
			syncedChildren.forEach(({ child, data }) => {
				enqueueUpdate(this.bridgeId, child.__id__, data);
			});
			invokePropertyChanges(this, update.propertyChanges);
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
		*/
		#initLifecycle() {
			componentLifetimes.forEach((method) => {
				const lifecycleMethod = this.__info__.lifetimes?.[method] || this.__info__[method];
				if (!isFunction(lifecycleMethod)) return;
				this[method] = lifecycleMethod.bind(this);
			});
			if (this.__isComponent__) pageLifetimes.forEach((method) => {
				const lifecycleMethod = this.__info__.pageLifetimes?.[method];
				if (!isFunction(lifecycleMethod)) return;
				if (method === "show") method = "onShow";
				else if (method === "hide") method = "onHide";
				this[method] = lifecycleMethod.bind(this);
			});
		}
		/**
		* 开发者自定义函数
		* Component 构造器的主要区别是：方法需要放在 methods: { } 里面
		*/
		#initCustomMethods() {
			const methods = this.__info__.methods;
			for (const attr in methods) if (isFunction(methods[attr])) this[attr] = methods[attr].bind(this);
		}
		#invokeInitialPropertyObservers() {
			if (!this.__isComponent__ || !this.__info__.properties || this.__initialPropertyObserversInvoked__) return;
			const changedPaths = this.__initialPropertyChanges__.map((change) => change.path);
			if (changedPaths.length > 0) {
				invokeDataObservers(this, changedPaths);
				invokePropertyChanges(this, this.__initialPropertyChanges__);
			}
			this.__initialPropertyObserversInvoked__ = true;
		}
		#applyInitialProperties() {
			for (const [key, incomingValue] of Object.entries(this.__initialPropertyValues__)) {
				const oldValue = this.data[key];
				const value = this.normalizePropertyValue(key, incomingValue, { oldValue });
				this.data[key] = value;
				const change = this.__initialPropertyChanges__.find((item) => item.propertyName === key);
				if (change) {
					change.oldValue = oldValue;
					change.value = value;
				}
			}
		}
		#invokeInitLifecycle() {
			if (this.__isComponent__) {
				this.componentCreated();
				this.#applyInitialProperties();
				this.#invokeInitialPropertyObservers();
			} else {
				this.componentCreated();
				this.componentAttached();
				invokeSafely(this, this.onLoad, [this.opts.query || {}], "onLoad");
			}
			this.initd = true;
		}
		/**
		* 触发观察者函数
		* triggerObserver
		*/
		tO(data) {
			const incomingData = typeof this.normalizePropertyValues === "function" ? this.normalizePropertyValues(data, { applyFilter: false }) : data;
			const nextData = {};
			const appliedData = {};
			for (const [prop, incomingValue] of Object.entries(incomingData)) {
				if (this.__pendingSyncedProps__ && Object.prototype.hasOwnProperty.call(this.__pendingSyncedProps__, prop) && deepEqual(this.__pendingSyncedProps__[prop], incomingValue)) {
					if (!this.hasPropertyFilter?.(prop)) this.data[prop] = incomingValue;
					appliedData[prop] = this.data[prop];
					delete this.__pendingSyncedProps__[prop];
					continue;
				}
				const value = typeof this.normalizePropertyValue === "function" ? this.normalizePropertyValue(prop, incomingValue) : incomingValue;
				nextData[prop] = value;
				appliedData[prop] = value;
			}
			if (Object.keys(nextData).length === 0) return appliedData;
			const propertyChanges = [];
			const changedPaths = [];
			for (const [prop, val] of Object.entries(nextData)) {
				const oldVal = this.data[prop];
				this.data[prop] = val;
				changedPaths.push([prop]);
				propertyChanges.push({
					propertyName: prop,
					oldValue: oldVal,
					path: [prop],
					value: val
				});
			}
			invokeDataObservers(this, changedPaths);
			invokePropertyChanges(this, propertyChanges);
			return appliedData;
		}
		hasPropertyFilter(prop) {
			const definition = this.__info__.properties?.[prop];
			return !!definition && typeof definition === "object" && definition.filter != null;
		}
		normalizePropertyValue(prop, value, { absent = false, applyFilter = true, oldValue = this.data[prop], path = [prop] } = {}) {
			const schema = this.__propertySchemas__[prop];
			if (!schema) return value;
			const normalizedValue = resolvePropertyValue(schema, value, { absent });
			if (absent || !applyFilter || !this.hasPropertyFilter(prop)) return normalizedValue;
			const definition = this.__info__.properties[prop];
			const filter = isFunction(definition.filter) ? definition.filter : this.__info__.methods?.[definition.filter];
			if (!isFunction(filter)) return normalizedValue;
			const filteredValue = invokeSafely(this, filter, [
				normalizedValue,
				oldValue,
				path
			], "property filter");
			return filteredValue === void 0 ? normalizedValue : filteredValue;
		}
		normalizePropertyValues(data, { applyFilter = true } = {}) {
			const normalized = {};
			for (const [prop, value] of Object.entries(data || {})) normalized[prop] = this.normalizePropertyValue(prop, value, { applyFilter });
			return normalized;
		}
		getPageId() {
			return this.__id__;
		}
		/**
		* 检查组件是否具有 behavior （检查时会递归检查被直接或间接引入的所有behavior）
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
		*/
		hasBehavior(behavior) {
			const _hasBehavior = function(behaviors) {
				if (!Array.isArray(behaviors)) return false;
				if (behaviors.includes(behavior)) return true;
				for (const b of behaviors) if (b && b.behaviors && _hasBehavior(b.behaviors)) return true;
				return false;
			};
			return _hasBehavior(this.behaviors);
		}
		/**
		* 创建一个 SelectorQuery 对象，选择器选取范围为这个组件实例内
		*/
		createSelectorQuery() {
			return createSelectorQuery().in(this);
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
		* 使用选择器选取子组件实例对象，返回匹配到的第一个组件实例对象
		*/
		selectComponent(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			const matchedComponent = children.find((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
			if (!matchedComponent) return null;
			if (matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) return matchedComponent.export();
			return matchedComponent;
		}
		/**
		* 使用选择器选取子组件实例对象，返回匹配到的全部组件实例对象组成的数组
		*/
		selectAllComponents(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			return children.filter((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
		}
		/**
		* 选取当前组件节点所在的组件实例（即组件的引用者），返回它的组件实例对象
		*/
		selectOwnerComponent() {
			const children = Object.values(runtime_default.instances[this.bridgeId]);
			for (const item of children) if (item.id === this.__parentId__) return item;
			return null;
		}
		/**
		* 创建一个 IntersectionObserver 对象，选择器选取范围为这个组件实例内
		* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#createIntersectionObserver-Object-options
		*/
		createIntersectionObserver(options) {
			return createIntersectionObserver(this, options);
		}
		/**
		* 立刻执行 callback，其中的多个 setData 之间不会触发界面绘制
		* （只有某些特殊场景中需要，如用于在不同组件同时 setData 时进行界面绘制同步）
		* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Component.html#groupSetData-Function-callback
		* @param {Function} callback 回调函数，在此函数中进行的多个 setData 调用会被合并
		*/
		groupSetData(callback) {
			if (!isFunction(callback)) {
				console.warn("[service] groupSetData callback must be a function");
				return;
			}
			this.__groupSetDataMode__ = true;
			beginUpdateBatch(this.bridgeId);
			this.__groupSetDataBuffer__ = {};
			this.__groupSetDataChanges__ = [];
			this.__groupSetDataCallbacks__ = [];
			try {
				invokeSafely(this, callback, [], "groupSetData callback");
			} finally {
				this.__groupSetDataMode__ = false;
				if (this.__groupSetDataBuffer__ && Object.keys(this.__groupSetDataBuffer__).length > 0) {
					const bufferedData = this.__groupSetDataBuffer__;
					const bufferedCallbacks = this.__groupSetDataCallbacks__;
					const bufferedChanges = this.__groupSetDataChanges__;
					this.__groupSetDataBuffer__ = {};
					this.__groupSetDataChanges__ = [];
					this.__groupSetDataCallbacks__ = [];
					const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], bufferedData);
					enqueueUpdate(this.bridgeId, this.__id__, bufferedData, createUpdateCallback(this, bufferedCallbacks), bufferedChanges);
					syncedChildren.forEach(({ child, data }) => {
						enqueueUpdate(this.bridgeId, child.__id__, data);
					});
				} else {
					this.__groupSetDataBuffer__ = {};
					this.__groupSetDataChanges__ = [];
					this.__groupSetDataCallbacks__ = [];
				}
				endUpdateBatch(this.bridgeId);
			}
		}
		/**
		* 创建一个 MediaQueryObserver 对象，选择器范围限定在当前组件。
		*/
		createMediaQueryObserver(options) {
			return createMediaQueryObserver(this, options);
		}
		/**
		* 获取这个关系所对应的所有关联节点
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/relations.html
		*/
		getRelationNodes(relationPath) {
			const relationNodes = this.__relations__.get(relationPath);
			if (!relationNodes) return null;
			return [...relationNodes];
		}
		/**
		* 执行关键帧动画。
		*/
		animate(selector, keyframes, duration, timeline, callback) {
			if (isFunction(timeline)) {
				callback = timeline;
				timeline = void 0;
			}
			invokeAPI("componentAnimate", {
				moduleId: this.__id__,
				selector,
				keyframes,
				duration,
				timeline,
				success: callback
			}, "render");
		}
		/**
		* 清除关键帧动画。
		*/
		clearAnimation(selector, options, callback) {
			if (isFunction(options)) {
				callback = options;
				options = {};
			}
			invokeAPI("componentClearAnimation", {
				moduleId: this.__id__,
				selector,
				options: options || {},
				success: callback
			}, "render");
		}
		/**
		* 触发组件所在页面的事件逻辑
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html
		* @param {*} methodName
		* @param {*} detail // detail对象，提供给事件监听函数
		* @param {*} options // 触发事件的选项
		*/
		async triggerEvent(methodName, detail, options = {}) {
			if (!methodName) return;
			const type = methodName.trim();
			if (!type) return;
			const normalizedOptions = {
				bubbles: options.bubbles === true,
				composed: options.composed === true,
				capturePhase: options.capturePhase === true
			};
			const target = {
				id: this.id,
				dataset: this.dataset || {}
			};
			let stopped = false;
			let defaultPrevented = false;
			const event = {
				type,
				timeStamp: Date.now(),
				detail,
				bubbles: normalizedOptions.bubbles,
				composed: normalizedOptions.composed,
				currentTarget: null,
				target,
				preventDefault() {
					defaultPrevented = true;
				},
				stopPropagation() {
					stopped = true;
				}
			};
			Object.defineProperty(event, "defaultPrevented", {
				enumerable: true,
				get: () => defaultPrevented
			});
			const eventPath = Component.prototype.getCustomEventPath.call(this, normalizedOptions.composed);
			const dispatch = async (node, capture) => {
				const binding = resolveEventBinding(node.eventAttr, type);
				if (!binding) return;
				const methodName = capture ? binding.captureCatch ?? binding.captureBind : binding.catch ?? binding.bind;
				if (!methodName) return;
				event.currentTarget = node.currentTarget;
				const result = await runtime_default.triggerEvent({
					bridgeId: this.bridgeId,
					moduleId: node.moduleId,
					methodName,
					event
				});
				if (capture ? Boolean(binding.captureCatch) : Boolean(binding.catch)) event.stopPropagation();
				if (result === false) {
					event.preventDefault();
					event.stopPropagation();
				}
			};
			if (normalizedOptions.capturePhase) for (let i = eventPath.length - 1; i >= 0 && !stopped; i--) await dispatch(eventPath[i], true);
			if (stopped) return;
			const bubblePath = normalizedOptions.bubbles ? eventPath : eventPath.slice(0, 1);
			for (const node of bubblePath) {
				await dispatch(node, false);
				if (stopped) break;
			}
		}
		getCustomEventPath(composed) {
			const eventPath = [{
				moduleId: this.__pageId__,
				eventAttr: this.__eventAttr__ || {},
				currentTarget: {
					id: this.id,
					dataset: this.dataset || {}
				}
			}];
			if (Array.isArray(this.__eventPath__)) {
				const renderPath = this.__eventPath__.filter((node) => node?.moduleId).map((node) => {
					const hostInstance = node.isComponentHost && node.nodeModuleId ? runtime_default.instances[this.bridgeId]?.[node.nodeModuleId] : null;
					return {
						moduleId: node.moduleId,
						nodeModuleId: node.nodeModuleId,
						isComponentHost: node.isComponentHost === true,
						eventAttr: node.eventAttr || {},
						currentTarget: {
							id: hostInstance?.id ?? node.targetInfo?.id,
							dataset: hostInstance?.dataset || node.targetInfo?.dataset || {}
						}
					};
				});
				const instances = runtime_default.instances[this.bridgeId] || {};
				const visited = /* @__PURE__ */ new Set([this.__id__]);
				let insertionCursor = 0;
				let parent = instances[this.__parentId__];
				while (parent?.__isComponent__ && !visited.has(parent.__id__)) {
					visited.add(parent.__id__);
					const hostIndex = renderPath.findIndex((node) => node.isComponentHost && node.nodeModuleId === parent.__id__);
					if (hostIndex >= 0) insertionCursor = Math.max(insertionCursor, hostIndex + 1);
					else if (Object.keys(parent.__eventAttr__ || {}).length > 0) {
						let lastInternalIndex = -1;
						for (let i = 0; i < renderPath.length; i++) if (renderPath[i].moduleId === parent.__id__) lastInternalIndex = i;
						const insertAt = Math.max(insertionCursor, lastInternalIndex + 1);
						renderPath.splice(insertAt, 0, {
							moduleId: parent.__pageId__,
							nodeModuleId: parent.__id__,
							isComponentHost: true,
							eventAttr: parent.__eventAttr__,
							currentTarget: {
								id: parent.id,
								dataset: parent.dataset || {}
							}
						});
						insertionCursor = insertAt + 1;
					}
					parent = instances[parent.__parentId__];
				}
				for (const node of renderPath) if (composed || node.moduleId === this.__pageId__) eventPath.push(node);
				return eventPath;
			}
			const instances = runtime_default.instances[this.bridgeId] || {};
			const visited = /* @__PURE__ */ new Set([this.__id__]);
			let parent = instances[this.__parentId__];
			while (parent?.__isComponent__ && !visited.has(parent.__id__)) {
				visited.add(parent.__id__);
				if (composed || parent.__pageId__ === this.__pageId__) eventPath.push({
					moduleId: parent.__pageId__,
					eventAttr: parent.__eventAttr__ || {},
					currentTarget: {
						id: parent.id,
						dataset: parent.dataset || {}
					}
				});
				parent = instances[parent.__parentId__];
			}
			return eventPath;
		}
		pageReady() {
			if (!this.__isComponent__) invokeSafely(this, this.ready, [], "ready lifetime");
		}
		/**
		* 页面退出时执行
		*/
		pageUnload() {
			if (!this.__isComponent__) invokeSafely(this, this.onUnload, [], "onUnload");
		}
		pageScrollTop(opts) {
			if (!this.__isComponent__) {
				const { scrollTop } = opts;
				invokeSafely(this, this.onPageScroll, [{ scrollTop }], "onPageScroll");
			}
		}
		pagePullDownRefresh() {
			if (!this.__isComponent__) invokeSafely(this, this.onPullDownRefresh, [], "onPullDownRefresh");
		}
		pageReachBottom() {
			if (!this.__isComponent__) invokeSafely(this, this.onReachBottom, [], "onReachBottom");
		}
		pageShareAppMessage(options = {}) {
			if (!this.__isComponent__) return invokeSafely(this, this.onShareAppMessage, [options], "onShareAppMessage");
		}
		pageTabItemTap(item = {}) {
			if (!this.__isComponent__) invokeSafely(this, this.onTabItemTap, [item], "onTabItemTap");
		}
		/**
		* 组件所在的页面被展示时执行
		*/
		pageShow() {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.show, [], "page show lifetime");
			invokeSafely(this, this.onShow, [], "page show lifetime");
		}
		/**
		* 组件所在的页面被隐藏时执行
		*/
		pageHide() {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.hide, [], "page hide lifetime");
			invokeSafely(this, this.onHide, [], "page hide lifetime");
		}
		/**
		* 组件所在的页面尺寸变化时执行
		* @param {object} size
		*/
		pageResize(size) {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.resize, [size], "page resize lifetime");
			invokeSafely(this, this.resize, [size], "page resize lifetime");
		}
		componentRouteDone() {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.routeDone, [], "page routeDone lifetime");
			invokeSafely(this, this.routeDone, [], "page routeDone lifetime");
		}
		/**
		* 在组件实例刚刚被创建时执行
		*/
		componentCreated() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.created, [], "created lifetime");
			invokeSafely(this, this.created, [], "created lifetime");
		}
		/**
		* 在组件实例进入页面节点树时执行
		*/
		componentAttached() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.attached, [], "attached lifetime");
			invokeSafely(this, this.attached, [], "attached lifetime");
			this.#checkAndLinkRelations();
		}
		/**
		* 在组件在视图层布局完成后执行
		*/
		componentReadied() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.ready, [], "ready lifetime");
			invokeSafely(this, this.ready, [], "ready lifetime");
		}
		/**
		* 在组件实例被移动到节点树另一个位置时执行
		*/
		componentMoved() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.moved, [], "moved lifetime");
			invokeSafely(this, this.moved, [], "moved lifetime");
			const relations = this.__info__.relations;
			if (relations) for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const relationNodes = this.__relations__.get(relationPath) || [];
				for (const node of relationNodes) this.#handleRelationChange(relationPath, node, relationConfig);
			}
		}
		/**
		* 在组件实例被从页面节点树移除时执行
		*/
		componentDetached() {
			this.__componentAttached__ = false;
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.detached, [], "detached lifetime");
			invokeSafely(this, this.detached, [], "detached lifetime");
			const relations = this.__info__.relations;
			if (relations) for (const [relationPath, relationConfig] of Object.entries(relations)) {
				const nodesToUnlink = [...this.__relations__.get(relationPath) || []];
				for (const node of nodesToUnlink) this.#unlinkRelation(relationPath, node, relationConfig);
			}
			this.#notifyOthersToUnlinkThis();
			this.initd = false;
		}
		/**
		* 通知其他组件移除对当前组件的引用
		*/
		#notifyOthersToUnlinkThis() {
			const allInstances = Object.values(runtime_default.instances[this.bridgeId] || {});
			for (const instance of allInstances) {
				if (instance === this || !instance.__relations__) continue;
				for (const [relationPath, relationNodes] of instance.__relations__.entries()) {
					const index = relationNodes.indexOf(this);
					if (index !== -1) {
						relationNodes.splice(index, 1);
						instance.__relations__.set(relationPath, relationNodes);
						const relationConfig = instance.__info__.relations?.[relationPath];
						invokeSafely(instance, relationConfig?.unlinked, [this], "relation unlinked callback");
					}
				}
			}
		}
		/**
		* 每当组件方法抛出错误时执行
		* @param {*} error
		*/
		componentError(error) {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.error, [error], "error lifetime", false);
			invokeSafely(this, this.error, [error], "error lifetime", false);
		}
	};
	//#endregion
	//#region src/instance/component/component-module.js
	var ComponentModule = class ComponentModule {
		static type = "component";
		/**
		*
		* @param {{data: object, lifetimes: object, pageLifetimes: object, methods: object, options: object, properties: object}} moduleInfo
		*/
		constructor(moduleInfo, extraInfo) {
			this.moduleInfo = moduleInfo;
			this.extraInfo = extraInfo;
			this.type = ComponentModule.type;
			this.isComponent = this.extraInfo.component;
			this.behaviors = this.moduleInfo.behaviors;
			this.usingComponents = this.extraInfo.usingComponents;
			mergeBehaviors(this.moduleInfo, this.behaviors);
			this.noReferenceData = filterData(this.moduleInfo.data || {});
		}
		getProps() {
			let props = serializeProps(this.moduleInfo.properties);
			const builtinBehaviors = Array.isArray(this.behaviors) ? this.behaviors.filter((behavior) => typeof behavior === "string" && behavior.startsWith("wx://")) : [];
			if (Array.isArray(this.moduleInfo.externalClasses) && this.moduleInfo.externalClasses.length > 0) {
				if (!props) props = {};
				for (const externalClass of this.moduleInfo.externalClasses) props[externalClass] = {
					type: ["s"],
					cls: true
				};
			}
			if (builtinBehaviors.length) {
				props ||= {};
				props.__diminaMeta = { builtinBehaviors };
			}
			return props;
		}
	};
	//#endregion
	//#region src/instance/page/page.js
	var Page = class {
		constructor(module, opts) {
			this.initd = false;
			this.opts = opts;
			this.is = opts.path;
			this.route = opts.path;
			this.bridgeId = opts.bridgeId;
			this.id = opts.bridgeId;
			this.query = opts.query;
			this.data = cloneDeep(module.noReferenceData);
			this.__type__ = module.type;
			this.__id__ = opts.moduleId;
			this.__info__ = module.moduleInfo;
			this.__childPropsBindings__ = {};
			this.__pendingInitSetDataCallbacks__ = [];
		}
		init({ deferInitialData = false } = {}) {
			this.#initMembers();
			this.#invokeInitLifecycle();
			if (!deferInitialData) this.sendInitialData();
		}
		sendInitialData() {
			if (this.__initialDataSent__) return;
			this.__initialDataSent__ = true;
			message_default.send({
				type: this.__id__,
				target: "render",
				body: {
					bridgeId: this.bridgeId,
					path: this.is,
					data: this.data
				}
			});
		}
		flushInitSetDataCallbacks() {
			if (this.__pendingInitSetDataCallbacks__.length === 0) return;
			const callbacks = this.__pendingInitSetDataCallbacks__;
			this.__pendingInitSetDataCallbacks__ = [];
			enqueueUpdate(this.bridgeId, this.__id__, {}, createUpdateCallback(this, callbacks));
		}
		setData(data, callback) {
			const update = applyDataUpdates(this, data, callback);
			if (!update) return;
			if (!this.initd) {
				this.__pendingInitSetDataCallbacks__.push(...update.callbacks);
				return;
			}
			const syncedChildren = syncUpdateChildrenProps(this, runtime_default.instances[this.bridgeId], update.changedData);
			enqueueUpdate(this.bridgeId, this.__id__, update.changedData, createUpdateCallback(this, update.callbacks), update.changes);
			syncedChildren.forEach(({ child, data }) => {
				enqueueUpdate(this.bridgeId, child.__id__, data);
			});
		}
		/**
		* 创建一个 SelectorQuery 对象，选择器选取范围为这个页面实例内
		*/
		createSelectorQuery() {
			return createSelectorQuery().in(this);
		}
		/**
		* 返回当前 tab 页直属的自定义 tabBar 组件实例。
		* https://developers.weixin.qq.com/miniprogram/dev/framework/ability/custom-tabbar.html
		*/
		getTabBar() {
			const instances = Object.values(runtime_default.instances[this.bridgeId] || {});
			return instances.find((item) => item?.__isComponent__ && item.__isCustomTabBar__ && isChildComponent(item, this.__id__, instances)) || null;
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html#获取组件实例
		* 使用选择器选取页面中的组件实例对象，返回匹配到的第一个组件实例对象
		*/
		selectComponent(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId] || {});
			const matchedComponent = children.find((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item));
			if (!matchedComponent) return null;
			if (matchedComponent.hasBehavior && matchedComponent.hasBehavior("wx://component-export") && matchedComponent.export) return matchedComponent.export();
			return matchedComponent;
		}
		/**
		* 使用选择器选取页面中的组件实例对象，返回匹配到的全部组件实例对象组成的数组
		*/
		selectAllComponents(selector) {
			const children = Object.values(runtime_default.instances[this.bridgeId] || {});
			return children.filter((item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)).map((component) => {
				if (component.hasBehavior && component.hasBehavior("wx://component-export") && component.export) return component.export();
				return component;
			});
		}
		#initMembers() {
			for (const attr in this.__info__) {
				const member = this.__info__[attr];
				if (isFunction(member)) this[attr] = member.bind(this);
				else this[attr] = member;
			}
		}
		#invokeInitLifecycle() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.created, [], "created lifetime");
			invokeSafely(this, this.created, [], "created lifetime");
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.attached, [], "attached lifetime");
			invokeSafely(this, this.attached, [], "attached lifetime");
			invokeSafely(this, this.onLoad, [this.opts.query || {}], "onLoad");
			this.initd = true;
		}
		/**
		* 页面显示/切入前台时触发。该时机不能保证页面渲染完成，如有页面/组件元素相关操作建议在 onReady 中处理
		*/
		pageShow() {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.show, [], "page show lifetime");
			invokeSafely(this, this.onShow, [], "onShow");
		}
		pageHide() {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.hide, [], "page hide lifetime");
			invokeSafely(this, this.onHide, [], "onHide");
		}
		pageReady() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.ready, [], "ready lifetime");
			invokeSafely(this, this.ready, [], "ready lifetime");
			invokeSafely(this, this.onReady, [], "onReady");
		}
		pageUnload() {
			invokeSafelyAll(this, this.__info__.behaviorLifetimes?.detached, [], "detached lifetime");
			invokeSafely(this, this.detached, [], "detached lifetime");
			invokeSafely(this, this.onUnload, [], "onUnload");
			this.initd = false;
		}
		pageScrollTop(opts) {
			const { scrollTop } = opts;
			invokeSafely(this, this.onPageScroll, [{ scrollTop }], "onPageScroll");
		}
		pagePullDownRefresh() {
			invokeSafely(this, this.onPullDownRefresh, [], "onPullDownRefresh");
		}
		pageReachBottom() {
			invokeSafely(this, this.onReachBottom, [], "onReachBottom");
		}
		pageShareAppMessage(options = {}) {
			return invokeSafely(this, this.onShareAppMessage, [options], "onShareAppMessage");
		}
		pageTabItemTap(item = {}) {
			invokeSafely(this, this.onTabItemTap, [item], "onTabItemTap");
		}
		pageResize(size) {
			invokeSafelyAll(this, this.__info__.behaviorPageLifetimes?.resize, [size], "page resize lifetime");
			invokeSafely(this, this.onResize, [size], "onResize");
		}
	};
	//#endregion
	//#region src/instance/page/page-module.js
	var PageModule = class PageModule {
		static type = "page";
		constructor(moduleInfo, extraInfo) {
			this.moduleInfo = moduleInfo;
			this.extraInfo = extraInfo;
			this.type = PageModule.type;
			this.behaviors = this.moduleInfo.behaviors;
			this.usingComponents = this.extraInfo.usingComponents;
			mergeBehaviors(this.moduleInfo, this.behaviors);
			if (this.moduleInfo.methods) {
				for (const [name, method] of Object.entries(this.moduleInfo.methods)) if (!(name in this.moduleInfo) && isFunction(method)) this.moduleInfo[name] = method;
			}
			this.noReferenceData = filterData(this.moduleInfo.data || {});
		}
	};
	//#endregion
	//#region src/instance/app/app-module.js
	var AppModule = class {
		static type = "app";
		constructor(moduleInfo) {
			this.moduleInfo = moduleInfo;
		}
	};
	//#endregion
	//#region src/core/loader.js
	var Loader = class {
		constructor() {
			this.staticModules = {};
		}
		/**
		* [Container] loadResource -> [Service] loadResource
		* @param {*} opts
		*/
		loadResource(opts) {
			const { appId, bridgeId, pagePath, root, baseUrl, resourceLoadId } = opts;
			if (isWebWorker) {
				this.isScriptLoaded = this.isScriptLoaded || {};
				if (!this.isScriptLoaded[root]) {
					const logicResourcePath = `${baseUrl}${appId}/${root}/logic.js`;
					globalThis.importScripts(logicResourcePath);
					this.isScriptLoaded[root] = true;
				}
			}
			router_default.setInitId(bridgeId);
			modRequire("app");
			modRequire(pagePath);
			message_default.invoke({
				type: "serviceResourceLoaded",
				target: "service",
				body: {
					bridgeId,
					resourceLoadId
				}
			});
		}
		/**
		* 创建逻辑层 App 映射实例
		* @param {*} moduleInfo
		*/
		createAppModule(moduleInfo) {
			const appModule = new AppModule(moduleInfo);
			this.staticModules[AppModule.type] = appModule;
		}
		/**
		*创建逻辑层 Page/Component 映射实例
		* [Container]loadResource -> [Service]loadResource -> globalThis.Page/globalThis.Component -> create
		* @param {*} moduleInfo {{data: object, method: object}} 模块逻辑信息
		* @param {*} extraInfo {{path: string, component: boolean, usingComponents: object}} 模块额外信息
		* @param {*} type {{type: string}} type
		*/
		createModule(moduleInfo, extraInfo, type) {
			const { path, usingComponents } = extraInfo;
			if (this.staticModules[path]) return;
			if (usingComponents) for (const componentPath of Object.values(usingComponents)) modRequire(componentPath);
			if (type === PageModule.type) {
				const pageModule = new PageModule(moduleInfo, extraInfo);
				this.staticModules[path] = pageModule;
			} else if (type === ComponentModule.type) {
				const componentModule = new ComponentModule(moduleInfo, extraInfo);
				this.staticModules[path] = componentModule;
			} else console.error(`[service] createModule ${type} error`);
		}
		getPropsByPath(usingComponents) {
			const res = {};
			this.getComponentProps(res, usingComponents);
			return res;
		}
		getComponentProps(res, usingComponents) {
			if (!usingComponents) return;
			for (const componentPath of Object.values(usingComponents)) {
				const component = this.staticModules[componentPath];
				if (!component || res[componentPath]) continue;
				res[componentPath] = component.getProps();
				this.getComponentProps(res, component.usingComponents);
			}
		}
		getAppModule() {
			return this.staticModules[AppModule.type];
		}
		getModuleByPath(path) {
			return this.staticModules[path];
		}
	};
	var loader_default = new Loader();
	//#endregion
	//#region src/core/runtime.js
	var Runtime = class {
		constructor() {
			this.app = void 0;
			this.defaultApp = {};
			this.appLaunchOptions = {};
			this.instances = {};
			this.pageStates = /* @__PURE__ */ new Map();
		}
		setAppLaunchOptions(options) {
			if (!this.app) this.appLaunchOptions = options;
		}
		getApp(options = {}) {
			return options.allowDefault ? this.app || this.defaultApp : this.app;
		}
		getPageState(bridgeId) {
			if (!this.pageStates.has(bridgeId)) this.pageStates.set(bridgeId, {
				hidden: false,
				pendingReady: false,
				pendingShow: false,
				ready: false,
				shown: false
			});
			return this.pageStates.get(bridgeId);
		}
		queuePendingEvent(instance, payload) {
			instance.__pendingRuntimeEvents__ = instance.__pendingRuntimeEvents__ || [];
			return new Promise((resolve, reject) => {
				instance.__pendingRuntimeEvents__.push({
					...payload,
					resolve,
					reject
				});
			});
		}
		async flushPendingEvents(instance) {
			const pendingEvents = instance?.__pendingRuntimeEvents__ || [];
			instance.__pendingRuntimeEvents__ = [];
			for (const pendingEvent of pendingEvents) try {
				const result = await this.dispatchEvent(pendingEvent);
				pendingEvent.resolve(result);
			} catch (error) {
				pendingEvent.reject(error);
			}
		}
		async dispatchEvent({ instance, bridgeId, moduleId, methodName, event }) {
			if (isFunction(instance[methodName])) return await instance[methodName](event);
			console.warn(`[service] triggerEvent ${bridgeId} ${moduleId}, is: ${instance.is}, method: ${methodName} is not exist`);
		}
		createApp(opts = this.appLaunchOptions) {
			if (this.app) {
				console.log("[service] app instance already existed");
				return;
			}
			const { scene, pagePath: path, query } = opts || {};
			const appModule = loader_default.getAppModule();
			if (!appModule) {
				console.log("[service] app instance is not exist");
				return;
			}
			console.log("[service] create app instance");
			Object.assign(appModule.moduleInfo, this.defaultApp);
			this.defaultApp = {};
			this.app = new App(appModule, {
				scene,
				path,
				query
			});
		}
		appShow() {
			this.app?.appShow();
		}
		appHide() {
			this.app?.appHide();
		}
		stackShow(stackId) {
			router_default.pushStack(stackId);
		}
		stackHide(stackId) {
			router_default.popStack(stackId);
		}
		/**
		* 渲染层创建映射实例
		* [Render]componentCreated -> [Container]createInstance ->[Service]createInstance
		* @param {*} opts
		*/
		createInstance(opts) {
			const { bridgeId, moduleId, path, query, eventAttr, pageId, parentId, properties, propertyNames, targetInfo, stackId, isCustomTabBar = false, deferInitialData = false } = opts;
			const module = loader_default.getModuleByPath(path);
			if (!module) {
				console.error(`[service] ${path} not exist`);
				return;
			}
			console.log(`[service] create instance ${path}`);
			this.instances[bridgeId] = this.instances[bridgeId] || {};
			if (module.type === ComponentModule.type) {
				const component = new Component(module, {
					bridgeId,
					moduleId,
					path,
					isCustomTabBar,
					query,
					eventAttr,
					pageId,
					parentId,
					properties,
					propertyNames,
					targetInfo
				});
				this.instances[bridgeId][moduleId] = component;
				if (!module.isComponent) router_default.push(component, stackId);
				component.init({ deferInitialData });
				const state = this.getPageState(bridgeId);
				if (!module.isComponent && state.pendingShow && !state.hidden) this.pageShow({
					bridgeId,
					moduleId
				});
				return component;
			} else if (module.type === PageModule.type) {
				const page = new Page(module, {
					bridgeId,
					moduleId,
					path,
					query
				});
				this.instances[bridgeId][moduleId] = page;
				router_default.push(page, stackId);
				page.init({ deferInitialData });
				const state = this.getPageState(bridgeId);
				if (state.pendingShow && !state.hidden) this.pageShow({
					bridgeId,
					moduleId
				});
				return page;
			} else console.error(`[service] ${module.type} instance is not exist.`);
		}
		moduleAttached(opts) {
			const { bridgeId, moduleId, parentId } = opts;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance || instance.__type__ !== ComponentModule.type || !instance.__isComponent__) return;
			if (instance.__componentAttached__ || instance.__componentAttaching__) return;
			if (parentId && this.instances[bridgeId]?.[parentId]) instance.__parentId__ = parentId;
			const parent = this.instances[bridgeId]?.[instance.__parentId__];
			if (parent?.__isComponent__ && !parent.__componentAttached__) {
				instance.__componentAttachPending__ = true;
				return;
			}
			instance.__componentAttachPending__ = false;
			instance.__componentAttaching__ = true;
			try {
				instance.__componentAttached__ = true;
				instance.componentAttached();
				instance.__componentAttaching__ = false;
				if (this.getPageState(bridgeId).shown && !instance.__pageShown__) {
					instance.__pageShown__ = true;
					instance.pageShow();
				}
				const children = Object.values(this.instances[bridgeId] || {}).filter((child) => child?.__parentId__ === moduleId && child.__componentAttachPending__);
				for (const child of children) this.moduleAttached({
					bridgeId,
					moduleId: child.__id__
				});
				if (instance.__pendingReadyOpts__) {
					const pendingReadyOpts = instance.__pendingReadyOpts__;
					delete instance.__pendingReadyOpts__;
					this.moduleReady(pendingReadyOpts);
				}
			} finally {
				instance.__componentAttaching__ = false;
			}
		}
		moduleReady(opts) {
			const { bridgeId, moduleId, propBindings, eventPath } = opts;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance) return;
			if (Array.isArray(eventPath)) instance.__eventPath__ = eventPath;
			if (propBindings && instance.__parentId__) {
				const parent = this.instances[bridgeId]?.[instance.__parentId__];
				if (parent) {
					if (!parent.__childPropsBindings__) parent.__childPropsBindings__ = {};
					parent.__childPropsBindings__[moduleId] = propBindings;
				}
			}
			if (instance.__type__ === ComponentModule.type) {
				if (instance.__isComponent__ && !instance.__componentAttached__) {
					instance.__pendingReadyOpts__ = opts;
					return;
				}
				if (instance.__componentReadied__) return;
				if (Object.values(this.instances[bridgeId] || {}).some((child) => child?.__isComponent__ && child.__componentAttached__ && !child.__componentReadied__ && this.isDescendantInstance(child, instance, bridgeId))) {
					instance.__pendingReadyOpts__ = opts;
					return;
				}
				instance.__componentReadied__ = true;
				instance.componentReadied();
				this.flushPendingEvents(instance);
				instance.flushInitSetDataCallbacks?.();
				const pageInstance = this.getPageInstance(bridgeId);
				if (pageInstance) this.checkAndCallPageReady(bridgeId, pageInstance.__id__);
				let parent = this.instances[bridgeId]?.[instance.__parentId__];
				while (parent?.__isComponent__) {
					if (parent.__pendingReadyOpts__) {
						const pendingReadyOpts = parent.__pendingReadyOpts__;
						delete parent.__pendingReadyOpts__;
						this.moduleReady(pendingReadyOpts);
					}
					parent = this.instances[bridgeId]?.[parent.__parentId__];
				}
			}
		}
		isDescendantInstance(candidate, ancestor, bridgeId) {
			let current = candidate;
			while (current?.__parentId__) {
				if (current.__parentId__ === ancestor.__id__) return true;
				current = this.instances[bridgeId]?.[current.__parentId__];
			}
			return false;
		}
		moduleUnmounted(opts) {
			const { bridgeId, moduleId } = opts;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance) return;
			if (instance.__type__ === ComponentModule.type) {
				if ((!instance.__isComponent__ || instance.__componentAttached__) && !instance.__componentDetached__) {
					instance.componentDetached();
					instance.__componentDetached__ = true;
				}
			}
			delete this.instances[bridgeId][moduleId];
		}
		pageShow(opts) {
			const { bridgeId } = opts;
			const state = this.getPageState(bridgeId);
			state.hidden = false;
			state.pendingShow = true;
			if (!this.instances[bridgeId]) return;
			const pageInstance = this.getPageInstance(bridgeId);
			if (!pageInstance?.initd) return;
			if (state.shown) {
				state.pendingShow = false;
				return;
			}
			state.shown = true;
			state.pendingShow = false;
			const pageInstances = [];
			this.getInstancesInTreeOrder(bridgeId).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) pageInstances.push(instance);
				else if (instance.__type__ === ComponentModule.type) {
					if (!instance.__isComponent__) pageInstances.push(instance);
					else if (instance.__componentAttached__ && !instance.__pageShown__) {
						instance.__pageShown__ = true;
						instance.pageShow();
					}
				}
			});
			pageInstances.forEach((instance) => {
				instance.pageShow();
			});
			if (state.pendingReady) this.pageReady({
				...opts,
				moduleId: pageInstance.__id__
			});
		}
		pageReady(opts) {
			const { bridgeId, moduleId } = opts;
			const state = this.getPageState(bridgeId);
			state.pendingReady = true;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance) return;
			if (state.hidden || !state.shown || state.ready) return;
			instance.__pageReadyPending__ = true;
			instance.flushInitSetDataCallbacks?.();
			this.checkAndCallPageReady(bridgeId, moduleId);
		}
		/**
		* 检查并调用页面的 onReady
		* 确保所有组件的 ready 都已执行完毕
		*/
		/**
		* 获取指定 bridgeId 下的页面实例
		*/
		getPageInstance(bridgeId) {
			const instances = this.instances[bridgeId];
			if (!instances) return null;
			return Object.values(instances).find((instance) => {
				return instance && (instance.__type__ === PageModule.type || instance.__type__ === ComponentModule.type && !instance.__isComponent__);
			});
		}
		checkAndCallPageReady(bridgeId, moduleId) {
			const state = this.getPageState(bridgeId);
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance || !instance.__pageReadyPending__ || !state.shown || state.ready) return;
			const instances = this.instances[bridgeId];
			if (!instances) {
				instance.__pageReadyPending__ = false;
				state.pendingReady = false;
				state.ready = true;
				instance.pageReady();
				return;
			}
			if (Object.values(instances).filter((componentInstance) => {
				return componentInstance && componentInstance.__type__ === ComponentModule.type && componentInstance.__isComponent__ && componentInstance.initd && !componentInstance.__componentReadied__;
			}).length === 0) {
				instance.__pageReadyPending__ = false;
				state.pendingReady = false;
				state.ready = true;
				instance.pageReady();
			}
		}
		pageHide(opts) {
			const { bridgeId } = opts;
			const state = this.getPageState(bridgeId);
			state.hidden = true;
			state.pendingShow = false;
			if (!state.shown) return;
			state.shown = false;
			if (!this.instances[bridgeId]) return;
			const pageInstances = [];
			this.getInstancesInTreeOrder(bridgeId).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) pageInstances.push(instance);
				else if (instance.__type__ === ComponentModule.type) {
					if (!instance.__isComponent__) pageInstances.push(instance);
					else if (instance.__componentAttached__ && instance.__pageShown__) {
						instance.__pageShown__ = false;
						instance.pageHide();
					}
				}
			});
			pageInstances.forEach((instance) => {
				if (!instance) return;
				instance.pageHide();
			});
		}
		pageUnload(opts) {
			const { bridgeId } = opts;
			if (!this.instances[bridgeId]) return;
			const instanceList = this.getInstancesInTreeOrder(bridgeId);
			this.getInstancesInTreeOrder(bridgeId, { postOrder: true }).filter((instance) => instance?.__type__ === ComponentModule.type && instance.__isComponent__).forEach((instance) => {
				if (instance.__componentAttached__ && !instance.__componentDetached__) {
					instance.componentDetached();
					instance.__componentDetached__ = true;
				}
			});
			instanceList.forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === ComponentModule.type && !instance.__isComponent__ && !instance.__componentDetached__) {
					instance.componentDetached();
					instance.__componentDetached__ = true;
				}
				instance.pageUnload();
			});
			router_default.remove(bridgeId);
			delete this.instances[bridgeId];
			this.pageStates.delete(bridgeId);
		}
		getInstancesInTreeOrder(bridgeId, { postOrder = false } = {}) {
			const instances = Object.values(this.instances[bridgeId] || {}).filter(Boolean);
			const byId = new Map(instances.map((instance) => [instance.__id__, instance]));
			const childrenByParentId = /* @__PURE__ */ new Map();
			const roots = [];
			for (const instance of instances) if (instance.__parentId__ && byId.has(instance.__parentId__)) {
				const children = childrenByParentId.get(instance.__parentId__) || [];
				children.push(instance);
				childrenByParentId.set(instance.__parentId__, children);
			} else roots.push(instance);
			const ordered = [];
			const visited = /* @__PURE__ */ new Set();
			const visit = (instance) => {
				if (!instance || visited.has(instance)) return;
				visited.add(instance);
				if (!postOrder) ordered.push(instance);
				for (const child of childrenByParentId.get(instance.__id__) || []) visit(child);
				if (postOrder) ordered.push(instance);
			};
			roots.forEach(visit);
			instances.forEach(visit);
			return ordered;
		}
		pageScroll(opts) {
			const { bridgeId, moduleId, scrollTop } = opts;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance) return;
			instance.pageScrollTop({ scrollTop });
		}
		pagePullDownRefresh({ bridgeId }) {
			this.getPageInstance(bridgeId)?.pagePullDownRefresh();
		}
		pageReachBottom({ bridgeId }) {
			this.getPageInstance(bridgeId)?.pageReachBottom();
		}
		pageShareAppMessage({ bridgeId, ...options }) {
			return this.getPageInstance(bridgeId)?.pageShareAppMessage(options);
		}
		pageTabItemTap({ bridgeId, ...item }) {
			this.getPageInstance(bridgeId)?.pageTabItemTap(item);
		}
		pageResize(opts) {
			const { bridgeId, size } = opts;
			if (!this.instances[bridgeId]) return;
			const pageInstances = [];
			this.getInstancesInTreeOrder(bridgeId).forEach((instance) => {
				if (!instance) return;
				if (instance.__type__ === PageModule.type) pageInstances.push(instance);
				else if (instance.__type__ === ComponentModule.type) {
					if (!instance.__isComponent__) pageInstances.push(instance);
					else if (instance.__componentAttached__) instance.pageResize(size);
				}
			});
			pageInstances.forEach((instance) => instance.pageResize(size));
		}
		componentError(opts) {
			const { bridgeId, moduleId, error } = opts;
			const instance = this.instances[bridgeId]?.[moduleId];
			if (!instance) return;
			if (instance.__type__ === ComponentModule.type) instance.componentError(error);
		}
		componentRouteDone(opts) {
			const { bridgeId } = opts;
			if (!this.instances[bridgeId]) return;
			this.getInstancesInTreeOrder(bridgeId).forEach((instance) => {
				if (instance?.__type__ === ComponentModule.type && (!instance.__isComponent__ || instance.__componentAttached__)) instance.componentRouteDone();
			});
		}
		/**
		* 调用业务 js 方法
		* @param {*} opts
		*/
		async triggerEvent(opts) {
			const { bridgeId, moduleId, methodName, event } = opts;
			if (methodName === void 0) return;
			const instances = this.instances[bridgeId];
			if (!instances) {
				console.warn(`[service] No instances found for bridgeId: ${bridgeId}`);
				return;
			}
			const instance = instances[moduleId];
			if (!instance) {
				console.warn(`[service] triggerEvent ${bridgeId} ${moduleId} ${methodName}, instance is not exist`);
				return;
			}
			if (instance.__type__ === ComponentModule.type && instance.__isComponent__ && !instance.__componentReadied__) return this.queuePendingEvent(instance, {
				instance,
				bridgeId,
				moduleId,
				methodName,
				event
			});
			return this.dispatchEvent({
				instance,
				bridgeId,
				moduleId,
				methodName,
				event
			});
		}
	};
	var runtime_default = new Runtime();
	//#endregion
	//#region src/api/core/life-cycle/index.js
	var life_cycle_exports = /* @__PURE__ */ __exportAll({
		getEnterOptionsSync: () => getEnterOptionsSync,
		getLaunchOptionsSync: () => getLaunchOptionsSync
	});
	/**
	* 获取小程序启动时的参数。与 App.onLaunch 的回调参数一致
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/life-cycle/wx.getLaunchOptionsSync.html
	*/
	function getLaunchOptionsSync() {
		return runtime_default.app?.options;
	}
	/**
	* 获取本次小程序启动时的参数。如果当前是冷启动，则返回值与 App.onLaunch 的回调参数一致；如果当前是热启动，则返回值与 App.onShow 一致。
	* https://developers.weixin.qq.com/miniprogram/dev/api/base/app/life-cycle/wx.getEnterOptionsSync.html
	*/
	function getEnterOptionsSync() {
		return runtime_default.app?.options;
	}
	//#endregion
	//#region src/api/core/location/index.js
	var location_exports = /* @__PURE__ */ __exportAll({
		getLocation: () => getLocation,
		offLocationChange: () => offLocationChange,
		onLocationChange: () => onLocationChange,
		openLocation: () => openLocation,
		startLocationUpdate: () => startLocationUpdate,
		stopLocationUpdate: () => stopLocationUpdate
	});
	/**
	* 获取当前的地理位置、速度。
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.getLocation.html
	*/
	function getLocation(opts) {
		return invokeAPI("getLocation", opts);
	}
	/**
	* 开启小程序进入前台时接收位置消息。
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.startLocationUpdate.html
	*/
	function startLocationUpdate(opts) {
		return invokeAPI("startLocationUpdate", opts);
	}
	/**
	* 使用内置地图查看位置
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.openLocation.html
	*/
	function openLocation(opts) {
		return invokeAPI("openLocation", opts);
	}
	/**
	* 关闭监听实时位置变化，前后台都停止消息接收
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.stopLocationUpdate.html
	*/
	function stopLocationUpdate(opts) {
		return invokeAPI("stopLocationUpdate", opts);
	}
	/**
	* 监听实时地理位置变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.onLocationChange.html
	*/
	function onLocationChange(listener) {
		if (listener) invokeAPI("onLocationChange", { success: callback_default.store(listener, true) });
	}
	/**
	* 移除实时地理位置变化事件的监听函数
	* https://developers.weixin.qq.com/miniprogram/dev/api/location/wx.offLocationChange.html
	* @param {*} listener onLocationChange 传入的监听函数。不传此参数则移除所有监听函数。
	*/
	function offLocationChange(listener) {
		if (listener) {
			const id = callback_default.store(listener, true);
			invokeAPI("offLocationChange", { success: id });
			callback_default.remove(id);
		} else {
			invokeAPI("offLocationChange");
			callback_default.remove();
		}
	}
	//#endregion
	//#region src/api/core/map/index.js
	var map_exports = /* @__PURE__ */ __exportAll({ createMapContext: () => createMapContext });
	function createMapContext(mapId, obj) {
		return new MapContext({
			mapId,
			obj
		});
	}
	var MapContext = class {
		constructor(opts) {
			this.opts = opts;
		}
		addMarkers(data) {
			return this.invoke("addMarkers", data);
		}
		removeMarkers(data) {
			return this.invoke("removeMarkers", data);
		}
		includePoints(data) {
			return this.invoke("includePoints", data);
		}
		setCenterOffset(data) {
			return this.invoke("setCenterOffset", data);
		}
		getCenterLocation(data) {
			return this.invoke("getCenterLocation", data);
		}
		getScale(data) {
			return this.invoke("getScale", data);
		}
		moveToLocation(data) {
			return this.invoke("moveToLocation", data);
		}
		translateMarker(data) {
			return this.invoke("translateMarker", data);
		}
		addArc(data) {
			return this.invoke("addArc", data);
		}
		removeArc(data) {
			return this.invoke("removeArc", data);
		}
		invoke(apiName, data = {}) {
			return invokeAPI(apiName, {
				mapId: this.opts.mapId,
				...data
			});
		}
	};
	//#endregion
	//#region src/api/core/media/image/index.js
	var image_exports = /* @__PURE__ */ __exportAll({
		chooseImage: () => chooseImage,
		compressImage: () => compressImage,
		previewImage: () => previewImage,
		saveImageToPhotosAlbum: () => saveImageToPhotosAlbum
	});
	/**
	* 保存图片到系统相册
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.saveImageToPhotosAlbum.html
	*/
	function saveImageToPhotosAlbum(opts) {
		return invokeAPI("saveImageToPhotosAlbum", opts);
	}
	/**
	* 在新页面中全屏预览图片
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.previewImage.html
	*/
	function previewImage(opts) {
		return invokeAPI("previewImage", opts);
	}
	/**
	* 压缩图片接口，可选压缩质量。
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.compressImage.html
	*/
	function compressImage(opts) {
		return invokeAPI("compressImage", opts);
	}
	/**
	* 从本地相册选择图片或使用相机拍照。
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
	*/
	function chooseImage(opts) {
		return invokeAPI("chooseImage", opts);
	}
	//#endregion
	//#region src/api/core/media/video/index.js
	var video_exports = /* @__PURE__ */ __exportAll({
		chooseMedia: () => chooseMedia,
		chooseVideo: () => chooseVideo,
		createVideoContext: () => createVideoContext
	});
	function createVideoContext(videoId, obj) {
		return new VideoContext({
			videoId,
			obj
		});
	}
	/**
	* 拍摄视频或从手机相册中选视频
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseVideo.html
	*/
	function chooseVideo(opts) {
		return invokeAPI("chooseVideo", opts);
	}
	/**
	* 拍摄或从手机相册中选择图片或视频
	* https://developers.weixin.qq.com/miniprogram/dev/api/media/video/wx.chooseMedia.html
	*/
	function chooseMedia(opts) {
		return invokeAPI("chooseMedia", opts);
	}
	var VideoContext = class {
		constructor(opts) {
			this.opts = opts;
		}
		play() {
			this.invoke("play");
		}
		pause() {
			this.invoke("pause");
		}
		stop() {
			this.invoke("stop");
		}
		seek(position) {
			this.invoke("seek", { position });
		}
		playbackRate(rate) {
			this.invoke("playbackRate", { rate });
		}
		requestFullScreen(data = {}) {
			this.invoke("requestFullScreen", data);
		}
		exitFullScreen() {
			this.invoke("exitFullScreen");
		}
		requestBackgroundPlayback(data = {}) {
			this.invoke("requestBackgroundPlayback", data);
		}
		exitBackgroundPlayback() {
			this.invoke("exitBackgroundPlayback");
		}
		exitPictureInPicture(data = {}) {
			this.invoke("exitPictureInPicture", data);
		}
		showStatusBar() {
			this.invoke("showStatusBar");
		}
		hideStatusBar() {
			this.invoke("hideStatusBar");
		}
		invoke(command, data = {}) {
			invokeAPI("videoContext", {
				type: "native/video",
				id: this.opts.videoId,
				command,
				...data
			}, "render");
		}
	};
	//#endregion
	//#region src/api/core/navigate/index.js
	var navigate_exports = /* @__PURE__ */ __exportAll({
		exitMiniProgram: () => exitMiniProgram,
		navigateBackMiniProgram: () => navigateBackMiniProgram,
		navigateToMiniProgram: () => navigateToMiniProgram,
		restartMiniProgram: () => restartMiniProgram
	});
	/**
	* 重启当前小程序
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.restartMiniProgram.html
	*/
	function restartMiniProgram(opts) {
		return invokeAPI("restartMiniProgram", opts);
	}
	/**
	* 打开另一个小程序
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.navigateToMiniProgram.html
	*/
	function navigateToMiniProgram(opts) {
		return invokeAPI("navigateToMiniProgram", opts);
	}
	/**
	* 返回到上一个小程序。只有在当前小程序是被其他小程序打开时可以调用成功
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.navigateBackMiniProgram.html
	*/
	function navigateBackMiniProgram(opts) {
		return invokeAPI("navigateBackMiniProgram", opts);
	}
	/**
	* 退出当前小程序。必须有点击行为才能调用成功
	* https://developers.weixin.qq.com/miniprogram/dev/api/navigate/wx.exitMiniProgram.html
	*/
	function exitMiniProgram(opts) {
		return invokeAPI("exitMiniProgram", opts);
	}
	//#endregion
	//#region src/api/core/network/download/index.js
	var download_exports = /* @__PURE__ */ __exportAll({ downloadFile: () => downloadFile });
	/**
	* 下载文件资源到本地
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/download/wx.downloadFile.html
	* @param {*} opts
	*/
	function downloadFile(opts) {
		return invokeAPI("downloadFile", opts);
	}
	//#endregion
	//#region src/api/core/network/socket/shared.js
	var ARRAY_BUFFER_BASE64_KEY = "__diminaArrayBufferBase64";
	var BASE64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	var BASE64_LOOKUP = Object.fromEntries([...BASE64_CHARS].map((char, index) => [char, index]));
	function isArrayBuffer(value) {
		return Object.prototype.toString.call(value) === "[object ArrayBuffer]";
	}
	function toArrayBuffer(value) {
		if (isArrayBuffer(value)) return value;
		if (value && isArrayBuffer(value.buffer)) return value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength);
		return null;
	}
	function arrayBufferToBase64(buffer) {
		const bytes = new Uint8Array(buffer);
		let result = "";
		let index = 0;
		for (; index + 2 < bytes.length; index += 3) {
			result += BASE64_CHARS[bytes[index] >> 2];
			result += BASE64_CHARS[(bytes[index] & 3) << 4 | bytes[index + 1] >> 4];
			result += BASE64_CHARS[(bytes[index + 1] & 15) << 2 | bytes[index + 2] >> 6];
			result += BASE64_CHARS[bytes[index + 2] & 63];
		}
		if (index < bytes.length) {
			result += BASE64_CHARS[bytes[index] >> 2];
			if (index + 1 < bytes.length) {
				result += BASE64_CHARS[(bytes[index] & 3) << 4 | bytes[index + 1] >> 4];
				result += `${BASE64_CHARS[(bytes[index + 1] & 15) << 2]}=`;
			} else result += `${BASE64_CHARS[(bytes[index] & 3) << 4]}==`;
		}
		return result;
	}
	function base64ToArrayBuffer(base64) {
		const clean = String(base64 || "").replace(/[\r\n\s]/g, "");
		if (!clean) return /* @__PURE__ */ new ArrayBuffer(0);
		const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
		const length = clean.length * 3 / 4 - padding;
		const bytes = new Uint8Array(length);
		let byteIndex = 0;
		for (let index = 0; index < clean.length; index += 4) {
			const first = BASE64_LOOKUP[clean[index]];
			const second = BASE64_LOOKUP[clean[index + 1]];
			const third = clean[index + 2] === "=" ? 0 : BASE64_LOOKUP[clean[index + 2]];
			const fourth = clean[index + 3] === "=" ? 0 : BASE64_LOOKUP[clean[index + 3]];
			if (byteIndex < length) bytes[byteIndex++] = first << 2 | second >> 4;
			if (byteIndex < length) bytes[byteIndex++] = (second & 15) << 4 | third >> 2;
			if (byteIndex < length) bytes[byteIndex++] = (third & 3) << 6 | fourth;
		}
		return bytes.buffer;
	}
	function encodeSocketMessage(value) {
		const buffer = toArrayBuffer(value);
		return buffer ? { [ARRAY_BUFFER_BASE64_KEY]: arrayBufferToBase64(buffer) } : value;
	}
	function decodeSocketMessageResult(value) {
		if (!value || typeof value !== "object") return value;
		const encoded = value.message;
		if (!encoded || typeof encoded !== "object" || encoded["__diminaArrayBufferBase64"] === void 0) return value;
		return {
			...value,
			message: base64ToArrayBuffer(encoded[ARRAY_BUFFER_BASE64_KEY])
		};
	}
	function createSocketId(type) {
		return `${type}_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
	}
	function invokeSocketMethod(name, socketId, data = {}) {
		return invokeAPI(name, {
			socketId,
			...data,
			keep: true
		});
	}
	function createNativeEvent(onName, offName, baseParams = {}, transform = (value) => value) {
		const listeners = /* @__PURE__ */ new Set();
		let callbackId;
		let afterEmit;
		function stopNative() {
			if (!callbackId) return;
			const currentId = callbackId;
			callbackId = void 0;
			callback_default.remove(currentId);
			invokeAPI(offName, {
				...baseParams,
				callbackId: currentId,
				keep: true
			});
		}
		return {
			on(listener) {
				if (typeof listener !== "function" || listeners.has(listener)) return;
				listeners.add(listener);
				if (callbackId) return;
				callbackId = callback_default.store((value) => {
					const result = transform(value);
					for (const current of [...listeners]) current(result);
					afterEmit?.();
				}, true);
				return invokeAPI(onName, {
					...baseParams,
					callbackId,
					success: callbackId,
					keep: true
				});
			},
			off(listener) {
				if (typeof listener === "function") listeners.delete(listener);
				else listeners.clear();
				if (listeners.size === 0) return stopNative();
			},
			dispose({ notifyNative = false } = {}) {
				listeners.clear();
				if (notifyNative) return stopNative();
				if (callbackId) callback_default.remove(callbackId);
				callbackId = void 0;
			},
			hasListeners() {
				return listeners.size > 0;
			},
			setAfterEmit(handler) {
				afterEmit = handler;
			}
		};
	}
	//#endregion
	//#region src/api/core/network/mdns/index.js
	var mdns_exports = /* @__PURE__ */ __exportAll({
		offLocalServiceDiscoveryStop: () => offLocalServiceDiscoveryStop,
		offLocalServiceFound: () => offLocalServiceFound,
		offLocalServiceLost: () => offLocalServiceLost,
		offLocalServiceResolveFail: () => offLocalServiceResolveFail,
		onLocalServiceDiscoveryStop: () => onLocalServiceDiscoveryStop,
		onLocalServiceFound: () => onLocalServiceFound,
		onLocalServiceLost: () => onLocalServiceLost,
		onLocalServiceResolveFail: () => onLocalServiceResolveFail,
		startLocalServiceDiscovery: () => startLocalServiceDiscovery,
		stopLocalServiceDiscovery: () => stopLocalServiceDiscovery
	});
	var discoveryStopEvent = createNativeEvent("onLocalServiceDiscoveryStop", "offLocalServiceDiscoveryStop");
	var foundEvent = createNativeEvent("onLocalServiceFound", "offLocalServiceFound");
	var lostEvent = createNativeEvent("onLocalServiceLost", "offLocalServiceLost");
	var resolveFailEvent = createNativeEvent("onLocalServiceResolveFail", "offLocalServiceResolveFail");
	function startLocalServiceDiscovery(options = {}) {
		return invokeAPI("startLocalServiceDiscovery", options);
	}
	function stopLocalServiceDiscovery(options = {}) {
		return invokeAPI("stopLocalServiceDiscovery", options);
	}
	function onLocalServiceDiscoveryStop(listener) {
		return discoveryStopEvent.on(listener);
	}
	function offLocalServiceDiscoveryStop(listener) {
		return discoveryStopEvent.off(listener);
	}
	function onLocalServiceFound(listener) {
		return foundEvent.on(listener);
	}
	function offLocalServiceFound(listener) {
		return foundEvent.off(listener);
	}
	function onLocalServiceLost(listener) {
		return lostEvent.on(listener);
	}
	function offLocalServiceLost(listener) {
		return lostEvent.off(listener);
	}
	function onLocalServiceResolveFail(listener) {
		return resolveFailEvent.on(listener);
	}
	function offLocalServiceResolveFail(listener) {
		return resolveFailEvent.off(listener);
	}
	//#endregion
	//#region src/api/core/network/request/index.js
	var request_exports = /* @__PURE__ */ __exportAll({ request: () => request });
	/**
	* 发起 HTTPS 网络请求
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/request/wx.request.html
	* @param {*} opts
	*/
	function request(opts) {
		return invokeAPI("request", opts);
	}
	//#endregion
	//#region src/api/core/network/tcp/index.js
	var tcp_exports = /* @__PURE__ */ __exportAll({ createTCPSocket: () => createTCPSocket });
	var TCPSocket = class {
		constructor(socketId) {
			this.socketId = socketId;
			this.events = {
				bindWifi: createNativeEvent("TCPSocket.onBindWifi", "TCPSocket.offBindWifi", { socketId }),
				close: createNativeEvent("TCPSocket.onClose", "TCPSocket.offClose", { socketId }),
				connect: createNativeEvent("TCPSocket.onConnect", "TCPSocket.offConnect", { socketId }),
				error: createNativeEvent("TCPSocket.onError", "TCPSocket.offError", { socketId }),
				message: createNativeEvent("TCPSocket.onMessage", "TCPSocket.offMessage", { socketId }, decodeSocketMessageResult)
			};
			this.events.close.setAfterEmit(() => {
				for (const event of Object.values(this.events)) event.dispose();
			});
		}
		bindWifi(options = {}) {
			return invokeSocketMethod("TCPSocket.bindWifi", this.socketId, options);
		}
		close() {
			const result = invokeSocketMethod("TCPSocket.close", this.socketId);
			for (const [name, event] of Object.entries(this.events)) if (name !== "close" || !event.hasListeners()) event.dispose();
			return result;
		}
		connect(options = {}) {
			return invokeSocketMethod("TCPSocket.connect", this.socketId, options);
		}
		write(data) {
			return invokeSocketMethod("TCPSocket.write", this.socketId, { data: encodeSocketMessage(data) });
		}
		onBindWifi(listener) {
			return this.events.bindWifi.on(listener);
		}
		offBindWifi(listener) {
			return this.events.bindWifi.off(listener);
		}
		onClose(listener) {
			return this.events.close.on(listener);
		}
		offClose(listener) {
			return this.events.close.off(listener);
		}
		onConnect(listener) {
			return this.events.connect.on(listener);
		}
		offConnect(listener) {
			return this.events.connect.off(listener);
		}
		onError(listener) {
			return this.events.error.on(listener);
		}
		offError(listener) {
			return this.events.error.off(listener);
		}
		onMessage(listener) {
			return this.events.message.on(listener);
		}
		offMessage(listener) {
			return this.events.message.off(listener);
		}
	};
	function createTCPSocket() {
		return new TCPSocket(createSocketId("tcp"));
	}
	//#endregion
	//#region src/api/core/network/udp/index.js
	var udp_exports = /* @__PURE__ */ __exportAll({ createUDPSocket: () => createUDPSocket });
	var UDPSocket = class {
		constructor(socketId) {
			this.socketId = socketId;
			this.events = {
				close: createNativeEvent("UDPSocket.onClose", "UDPSocket.offClose", { socketId }),
				error: createNativeEvent("UDPSocket.onError", "UDPSocket.offError", { socketId }),
				listening: createNativeEvent("UDPSocket.onListening", "UDPSocket.offListening", { socketId }),
				message: createNativeEvent("UDPSocket.onMessage", "UDPSocket.offMessage", { socketId }, decodeSocketMessageResult)
			};
			this.events.close.setAfterEmit(() => {
				for (const event of Object.values(this.events)) event.dispose();
			});
		}
		bind(port = 0) {
			return invokeSocketMethod("UDPSocket.bind", this.socketId, { port });
		}
		close() {
			const result = invokeSocketMethod("UDPSocket.close", this.socketId);
			for (const [name, event] of Object.entries(this.events)) if (name !== "close" || !event.hasListeners()) event.dispose();
			return result;
		}
		connect(options = {}) {
			return invokeSocketMethod("UDPSocket.connect", this.socketId, options);
		}
		send(options = {}) {
			return this.sendWithName("UDPSocket.send", options);
		}
		write(options = {}) {
			return this.sendWithName("UDPSocket.write", options);
		}
		setTTL(ttl) {
			return invokeSocketMethod("UDPSocket.setTTL", this.socketId, { ttl });
		}
		onClose(listener) {
			return this.events.close.on(listener);
		}
		offClose(listener) {
			return this.events.close.off(listener);
		}
		onError(listener) {
			return this.events.error.on(listener);
		}
		offError(listener) {
			return this.events.error.off(listener);
		}
		onListening(listener) {
			return this.events.listening.on(listener);
		}
		offListening(listener) {
			return this.events.listening.off(listener);
		}
		onMessage(listener) {
			return this.events.message.on(listener);
		}
		offMessage(listener) {
			return this.events.message.off(listener);
		}
		sendWithName(name, options) {
			return invokeSocketMethod(name, this.socketId, {
				...options,
				message: encodeSocketMessage(options.message)
			});
		}
	};
	function createUDPSocket() {
		return new UDPSocket(createSocketId("udp"));
	}
	//#endregion
	//#region src/api/core/network/upload/index.js
	var upload_exports = /* @__PURE__ */ __exportAll({ uploadFile: () => uploadFile });
	/**
	*将本地资源上传到服务器
	*https://developers.weixin.qq.com/miniprogram/dev/api/network/upload/wx.uploadFile.html
	*/
	function uploadFile(opts) {
		return invokeAPI("uploadFile", opts);
	}
	//#endregion
	//#region src/api/core/network/websocket/index.js
	var websocket_exports = /* @__PURE__ */ __exportAll({
		closeSocket: () => closeSocket,
		connectSocket: () => connectSocket,
		offSocketClose: () => offSocketClose,
		offSocketError: () => offSocketError,
		offSocketMessage: () => offSocketMessage,
		offSocketOpen: () => offSocketOpen,
		onSocketClose: () => onSocketClose,
		onSocketError: () => onSocketError,
		onSocketMessage: () => onSocketMessage,
		onSocketOpen: () => onSocketOpen,
		sendSocketMessage: () => sendSocketMessage
	});
	function createSocketEvent(onName, offName, baseParams = {}) {
		const listeners = /* @__PURE__ */ new Map();
		return {
			on(listener) {
				if (!isFunction(listener) || listeners.has(listener)) return;
				const callbackId = callback_default.store((value) => listener(value), true);
				listeners.set(listener, callbackId);
				try {
					return invokeAPI(onName, {
						...baseParams,
						callback: callbackId,
						keep: true
					});
				} catch (error) {
					listeners.delete(listener);
					callback_default.remove(callbackId);
					throw error;
				}
			},
			off(listener) {
				if (isFunction(listener)) {
					const callbackId = listeners.get(listener);
					if (!callbackId) return;
					listeners.delete(listener);
					callback_default.remove(callbackId);
					return invokeAPI(offName, {
						...baseParams,
						callback: callbackId,
						keep: true
					});
				}
				for (const callbackId of listeners.values()) callback_default.remove(callbackId);
				listeners.clear();
				return invokeAPI(offName, {
					...baseParams,
					keep: true
				});
			}
		};
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/websocket/SocketTask.html
	* SocketTask 类，用于管理 WebSocket 连接
	*/
	var SocketTask = class {
		constructor(socketId) {
			this.socketId = socketId;
			this._readyState = 0;
			this._events = {
				open: createSocketEvent("onSocketOpen", "offSocketOpen", { socketId }),
				message: createSocketEvent("onSocketMessage", "offSocketMessage", { socketId }),
				error: createSocketEvent("onSocketError", "offSocketError", { socketId }),
				close: createSocketEvent("onSocketClose", "offSocketClose", { socketId })
			};
		}
		/**
		* 通过 WebSocket 连接发送数据
		* @param {Object} opts 
		*/
		send(opts = {}) {
			const { data, success, fail, complete, ...rest } = opts;
			const params = {
				socketId: this.socketId,
				data,
				...rest
			};
			if (isFunction(success)) params.success = callback_default.store(success);
			if (isFunction(fail)) params.fail = callback_default.store(fail);
			if (isFunction(complete)) params.complete = callback_default.store(complete);
			return invokeAPI("sendSocketMessage", params);
		}
		/**
		* 关闭 WebSocket 连接
		* @param {Object} opts 
		*/
		close(opts = {}) {
			const { code = 1e3, reason = "", success, fail, complete, ...rest } = opts;
			const params = {
				socketId: this.socketId,
				code,
				reason,
				...rest
			};
			if (isFunction(success)) params.success = callback_default.store(success);
			if (isFunction(fail)) params.fail = callback_default.store(fail);
			if (isFunction(complete)) params.complete = callback_default.store(complete);
			return invokeAPI("closeSocket", params);
		}
		/**
		* 监听 WebSocket 连接打开事件
		* @param {Function} callback 回调函数
		*/
		onOpen(callbackFn) {
			return this._events.open.on(callbackFn);
		}
		/**
		* 取消监听 WebSocket 连接打开事件
		* @param {Function} callback 回调函数
		*/
		offOpen(callbackFn) {
			return this._events.open.off(callbackFn);
		}
		/**
		* 监听 WebSocket 接受到服务器的消息事件
		* @param {Function} callback 回调函数
		*/
		onMessage(callbackFn) {
			return this._events.message.on(callbackFn);
		}
		/**
		* 取消监听 WebSocket 接受到服务器的消息事件
		* @param {Function} callback 回调函数
		*/
		offMessage(callbackFn) {
			return this._events.message.off(callbackFn);
		}
		/**
		* 监听 WebSocket 错误事件
		* @param {Function} callback 回调函数
		*/
		onError(callbackFn) {
			return this._events.error.on(callbackFn);
		}
		/**
		* 取消监听 WebSocket 错误事件
		* @param {Function} callback 回调函数
		*/
		offError(callbackFn) {
			return this._events.error.off(callbackFn);
		}
		/**
		* 监听 WebSocket 连接关闭事件
		* @param {Function} callback 回调函数
		*/
		onClose(callbackFn) {
			return this._events.close.on(callbackFn);
		}
		/**
		* 取消监听 WebSocket 连接关闭事件
		* @param {Function} callback 回调函数
		*/
		offClose(callbackFn) {
			return this._events.close.off(callbackFn);
		}
		/**
		* 获取 WebSocket 连接状态
		* @returns {number} 连接状态
		*/
		get readyState() {
			return this._readyState;
		}
		/**
		* WebSocket 的连接状态常量
		*/
		static get CONNECTING() {
			return 0;
		}
		static get OPEN() {
			return 1;
		}
		static get CLOSING() {
			return 2;
		}
		static get CLOSED() {
			return 3;
		}
	};
	var globalSocketEvents = {
		open: createSocketEvent("onSocketOpen", "offSocketOpen"),
		message: createSocketEvent("onSocketMessage", "offSocketMessage"),
		error: createSocketEvent("onSocketError", "offSocketError"),
		close: createSocketEvent("onSocketClose", "offSocketClose")
	};
	/**
	* 创建一个 WebSocket 连接
	* https://developers.weixin.qq.com/miniprogram/dev/api/network/websocket/wx.connectSocket.html
	* @param {Object} opts 配置对象
	* @param {string} opts.url 开发者服务器 wss 接口地址
	* @param {Object} [opts.header] HTTP Header，Header 中不能设置 Referer
	* @param {Array<string>} [opts.protocols] 子协议数组
	* @param {boolean} [opts.tcpNoDelay] 建立 TCP 连接的时候的 TCP_NODELAY 设置
	* @param {boolean} [opts.perMessageDeflate] 是否开启压缩扩展
	* @param {number} [opts.timeout] 超时时间，单位为毫秒
	* @param {boolean} [opts.forceCellularNetwork] 强制使用蜂窝网络发送请求
	* @param {Function} [opts.success] 接口调用成功的回调函数
	* @param {Function} [opts.fail] 接口调用失败的回调函数
	* @param {Function} [opts.complete] 接口调用结束的回调函数（调用成功、失败都会执行）
	* @returns {SocketTask} WebSocket 任务对象
	*/
	function connectSocket(opts = {}) {
		const { url, header = {}, protocols = [], tcpNoDelay = false, perMessageDeflate = false, timeout, forceCellularNetwork = false, success, fail, complete, ...rest } = opts;
		if (!url) {
			const error = /* @__PURE__ */ new Error("url is required");
			if (isFunction(fail)) fail(error);
			if (isFunction(complete)) complete(error);
			throw error;
		}
		const socketId = `socket_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
		const socketTask = new SocketTask(socketId);
		const params = {
			socketId,
			url,
			header,
			protocols,
			tcpNoDelay,
			perMessageDeflate,
			timeout,
			forceCellularNetwork,
			...rest
		};
		if (isFunction(success)) params.success = callback_default.store((res) => {
			socketTask._readyState = SocketTask.OPEN;
			success(res);
		});
		if (isFunction(fail)) params.fail = callback_default.store((error) => {
			socketTask._readyState = SocketTask.CLOSED;
			fail(error);
		});
		if (isFunction(complete)) params.complete = callback_default.store(complete);
		invokeAPI("connectSocket", params);
		return socketTask;
	}
	/**
	* 通过 WebSocket 连接发送数据（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Object} opts 
	*/
	function sendSocketMessage(opts) {
		return invokeAPI("sendSocketMessage", opts);
	}
	/**
	* 关闭 WebSocket 连接（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Object} opts 
	*/
	function closeSocket(opts) {
		return invokeAPI("closeSocket", opts);
	}
	/**
	* 监听 WebSocket 连接打开事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketOpen(callbackFn) {
		return globalSocketEvents.open.on(callbackFn);
	}
	function offSocketOpen(callbackFn) {
		return globalSocketEvents.open.off(callbackFn);
	}
	/**
	* 监听 WebSocket 接受到服务器的消息事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketMessage(callbackFn) {
		return globalSocketEvents.message.on(callbackFn);
	}
	function offSocketMessage(callbackFn) {
		return globalSocketEvents.message.off(callbackFn);
	}
	/**
	* 监听 WebSocket 错误事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketError(callbackFn) {
		return globalSocketEvents.error.on(callbackFn);
	}
	function offSocketError(callbackFn) {
		return globalSocketEvents.error.off(callbackFn);
	}
	/**
	* 监听 WebSocket 连接关闭事件（全局方法，不推荐使用）
	* @deprecated 推荐使用 SocketTask 的方式管理 WebSocket 连接
	* @param {Function} callback 
	*/
	function onSocketClose(callbackFn) {
		return globalSocketEvents.close.on(callbackFn);
	}
	function offSocketClose(callbackFn) {
		return globalSocketEvents.close.off(callbackFn);
	}
	//#endregion
	//#region src/api/core/open-api/account-info/index.js
	var account_info_exports = /* @__PURE__ */ __exportAll({ getAccountInfoSync: () => getAccountInfoSync });
	/**
	* 获取当前账号信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/account-info/wx.getAccountInfoSync.html
	*/
	function getAccountInfoSync() {
		return invokeAPI("getAccountInfoSync");
	}
	//#endregion
	//#region src/api/core/open-api/authorize/index.js
	var authorize_exports = /* @__PURE__ */ __exportAll({ authorize: () => authorize });
	/**
	* 提前向用户发起授权请求。调用后会立刻弹窗询问用户是否同意授权小程序使用某项功能或获取用户的某些数据，但不会实际调用对应接口。如果用户之前已经同意授权，则不会出现弹窗，直接返回成功。
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/authorize/wx.authorize.html
	*/
	function authorize(opts) {
		return invokeAPI("authorize", opts);
	}
	//#endregion
	//#region src/api/core/open-api/index.js
	var open_api_exports = /* @__PURE__ */ __exportAll({ login: () => login$1 });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/login/wx.login.html
	*/
	function login$1(opts) {
		return invokeAPI("login", opts);
	}
	//#endregion
	//#region src/api/core/open-api/login/index.js
	var login_exports = /* @__PURE__ */ __exportAll({ login: () => login });
	/**
	* 调用接口获取登录凭证
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/login/wx.login.html
	* @param {*} opts
	*/
	function login(opts) {
		return invokeAPI("login", opts);
	}
	//#endregion
	//#region src/api/core/open-api/privacy/index.js
	var privacy_exports = /* @__PURE__ */ __exportAll({ getPrivacySetting: () => getPrivacySetting });
	function getPrivacySetting(opts) {
		return invokeAPI("getPrivacySetting", opts);
	}
	//#endregion
	//#region src/api/core/open-api/setting/index.js
	var setting_exports = /* @__PURE__ */ __exportAll({
		getSetting: () => getSetting,
		openSetting: () => openSetting
	});
	/**
	* 调起客户端小程序设置界面，返回用户设置的操作结果
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/setting/wx.openSetting.html
	*/
	function openSetting(opts) {
		return invokeAPI("openSetting", opts);
	}
	/**
	* 获取用户的当前设置
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/setting/wx.getSetting.html
	*/
	function getSetting(opts) {
		return invokeAPI("getSetting", opts);
	}
	//#endregion
	//#region src/api/core/open-api/user-info/index.js
	var user_info_exports = /* @__PURE__ */ __exportAll({ getUserInfo: () => getUserInfo });
	/**
	* 获取用户信息
	* https://developers.weixin.qq.com/miniprogram/dev/api/open-api/user-info/wx.getUserInfo.html
	* @param {*} opts
	*/
	function getUserInfo(opts) {
		return invokeAPI("getUserInfo", opts);
	}
	//#endregion
	//#region src/api/core/payment/index.js
	var payment_exports = /* @__PURE__ */ __exportAll({ requestPayment: () => requestPayment });
	/**
	* 发起支付
	* https://developers.weixin.qq.com/miniprogram/dev/api/payment/wx.requestPayment.html
	*/
	function requestPayment(opts) {
		return invokeAPI("requestPayment", opts);
	}
	//#endregion
	//#region src/api/core/share/index.js
	var share_exports = /* @__PURE__ */ __exportAll({
		hideShareMenu: () => hideShareMenu,
		showShareImageMenu: () => showShareImageMenu,
		showShareMenu: () => showShareMenu
	});
	/**
	* 显示当前页面的转发按钮
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.showShareMenu.html
	*/
	function showShareMenu(opts) {
		return invokeAPI("shareShareMenu", opts);
	}
	/**
	* 打开分享图片弹窗，可以将图片发送给朋友、收藏或下载
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.showShareImageMenu.html
	*/
	function showShareImageMenu(opts) {
		return invokeAPI("showShareImageMenu", opts);
	}
	/**
	* 隐藏当前页面的转发按钮
	* https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.hideShareMenu.html
	*/
	function hideShareMenu(opts) {
		return invokeAPI("hideShareMenu", opts);
	}
	//#endregion
	//#region src/api/core/storage/index.js
	var storage_exports = /* @__PURE__ */ __exportAll({
		clearStorage: () => clearStorage,
		clearStorageSync: () => clearStorageSync,
		getStorage: () => getStorage,
		getStorageInfo: () => getStorageInfo,
		getStorageInfoSync: () => getStorageInfoSync,
		getStorageSync: () => getStorageSync,
		removeStorage: () => removeStorage,
		removeStorageSync: () => removeStorageSync,
		setStorage: () => setStorage,
		setStorageSync: () => setStorageSync
	});
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.setStorageSync.html
	*/
	function setStorageSync(...opts) {
		return invokeAPI("setStorageSync", opts);
	}
	/**
	* 从本地缓存中同步获取指定 key 的内容。
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageSync.html
	*/
	function getStorageSync(opts) {
		return invokeAPI("getStorageSync", opts);
	}
	/**
	*
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.removeStorageSync.html
	*/
	function removeStorageSync(opts) {
		return invokeAPI("removeStorageSync", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.clearStorageSync.html
	*/
	function clearStorageSync() {
		return invokeAPI("clearStorageSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.setStorage.html
	*/
	function setStorage(opts) {
		return invokeAPI("setStorage", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorage.html
	*/
	function getStorage(opts) {
		return invokeAPI("getStorage", opts);
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.removeStorage.html
	*/
	function removeStorage(opts) {
		return invokeAPI("removeStorage", opts);
	}
	function clearStorage() {
		return invokeAPI("clearStorage");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageInfoSync.html
	*/
	function getStorageInfoSync() {
		return invokeAPI("getStorageInfoSync");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/storage/wx.getStorageInfo.html
	*/
	function getStorageInfo(opts) {
		return invokeAPI("getStorageInfo", opts);
	}
	//#endregion
	//#region src/api/core/ui/animation/index.js
	var animation_exports = /* @__PURE__ */ __exportAll({ createAnimation: () => createAnimation });
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/wx.createAnimation.html
	* @returns { Animation } 动画对象
	*/
	function createAnimation(opts = {}) {
		return new Animation(opts);
	}
	var Animation = class {
		constructor({ duration = 400, timingFunction = "linear", delay = 0, transformOrigin = "50% 50% 0" } = {}) {
			this.actions = [];
			this.currentTransform = {};
			this.currentStepAnimates = [];
			this.option = {
				transition: {
					duration,
					timingFunction,
					delay
				},
				transformOrigin
			};
		}
		/**
		* 导出动画队列。export 方法每次调用后会清掉之前的动画操作。
		* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.export.html
		*/
		export() {
			const actions = this.actions;
			this.actions = [];
			return { actions };
		}
		/**
		* 表示一组动画完成。可以在一组动画中调用任意多个动画方法，一组动画中的所有动画会同时开始，一组动画完成后才会进行下一组动画。
		* https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.step.html
		*/
		step(option = {}) {
			for (const stepAnimate of this.currentStepAnimates) if (stepAnimate.type === "style") this.currentTransform[`${stepAnimate.type}.${stepAnimate.args[0]}`] = stepAnimate;
			else this.currentTransform[stepAnimate.type] = stepAnimate;
			this.actions.push({
				animates: Object.keys(this.currentTransform).reduce((prev, current) => {
					return [].concat(...prev, [this.currentTransform[current]]);
				}, []),
				option: {
					transformOrigin: option.transformOrigin !== void 0 ? option.transformOrigin : this.option.transformOrigin,
					transition: {
						duration: option.duration !== void 0 ? option.duration : this.option.transition.duration,
						timingFunction: option.timingFunction !== void 0 ? option.timingFunction : this.option.transition.timingFunction,
						delay: option.delay !== void 0 ? option.delay : this.option.transition.delay
					}
				}
			});
			this.currentStepAnimates = [];
			return this;
		}
		backgroundColor(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["background-color", value]
			});
			return this;
		}
		bottom(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["bottom", suffixPixel(value)]
			});
			return this;
		}
		height(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["height", suffixPixel(value)]
			});
			return this;
		}
		left(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["left", suffixPixel(value)]
			});
			return this;
		}
		matrix(a = 1, b = 0, c = 0, d = 1, tx = 1, ty = 1) {
			this.currentStepAnimates.push({
				type: "matrix",
				args: [
					a,
					b,
					c,
					d,
					tx,
					ty
				]
			});
			return this;
		}
		matrix3d(a1 = 1, b1 = 0, c1 = 0, d1 = 0, a2 = 0, b2 = 1, c2 = 0, d2 = 0, a3 = 0, b3 = 0, c3 = 1, d3 = 0, a4 = 0, b4 = 0, c4 = 0, d4 = 1) {
			this.currentStepAnimates.push({
				type: "matrix3d",
				args: [
					a1,
					b1,
					c1,
					d1,
					a2,
					b2,
					c2,
					d2,
					a3,
					b3,
					c3,
					d3,
					a4,
					b4,
					c4,
					d4
				]
			});
			return this;
		}
		opacity(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["opacity", value]
			});
			return this;
		}
		right(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["right", suffixPixel(value)]
			});
			return this;
		}
		rotate(angle = 0) {
			this.currentStepAnimates.push({
				type: "rotate",
				args: [angle]
			});
			return this;
		}
		rotate3d(x = 0, y = 0, z = 0, angle = 0) {
			this.currentStepAnimates.push({
				type: "rotate3d",
				args: [
					x,
					y,
					z,
					angle
				]
			});
			return this;
		}
		rotateX(angle) {
			this.currentStepAnimates.push({
				type: "rotateX",
				args: [angle]
			});
			return this;
		}
		rotateY(angle) {
			this.currentStepAnimates.push({
				type: "rotateY",
				args: [angle]
			});
			return this;
		}
		rotateZ(angle) {
			this.currentStepAnimates.push({
				type: "rotateZ",
				args: [angle]
			});
			return this;
		}
		scale(x = 1, y = 1) {
			this.currentStepAnimates.push({
				type: "scale",
				args: [x, y]
			});
			return this;
		}
		scale3d(sx = 1, sy = 1, sz = 1) {
			this.currentStepAnimates.push({
				type: "scale3d",
				args: [
					sx,
					sy,
					sz
				]
			});
			return this;
		}
		scaleX(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleX",
				args: [scale]
			});
			return this;
		}
		scaleY(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleY",
				args: [scale]
			});
			return this;
		}
		scaleZ(scale = 1) {
			this.currentStepAnimates.push({
				type: "scaleZ",
				args: [scale]
			});
			return this;
		}
		skew(ax = 0, ay = 0) {
			this.currentStepAnimates.push({
				type: "skew",
				args: [ax, ay]
			});
			return this;
		}
		skewX(angle = 0) {
			this.currentStepAnimates.push({
				type: "skewX",
				args: [angle]
			});
			return this;
		}
		skewY(angle = 0) {
			this.currentStepAnimates.push({
				type: "skewY",
				args: [angle]
			});
			return this;
		}
		top(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["top", suffixPixel(value)]
			});
			return this;
		}
		translate(tx = 0, ty = 0) {
			this.currentStepAnimates.push({
				type: "translate",
				args: [tx, ty]
			});
			return this;
		}
		translate3d(tx = 0, ty = 0, tz = 0) {
			this.currentStepAnimates.push({
				type: "translate3d",
				args: [
					tx,
					ty,
					tz
				]
			});
			return this;
		}
		translateX(translation = 0) {
			this.currentStepAnimates.push({
				type: "translateX",
				args: [translation]
			});
			return this;
		}
		translateY(translation = 0) {
			this.currentStepAnimates.push({
				type: "translateY",
				args: [translation]
			});
			return this;
		}
		width(value) {
			this.currentStepAnimates.push({
				type: "style",
				args: ["width", suffixPixel(value)]
			});
			return this;
		}
	};
	//#endregion
	//#region src/api/core/ui/background/index.js
	var background_exports = /* @__PURE__ */ __exportAll({
		setBackgroundColor: () => setBackgroundColor,
		setBackgroundTextStyle: () => setBackgroundTextStyle
	});
	/**
	* 动态设置下拉背景字体、loading 图的样式
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/background/wx.setBackgroundTextStyle.html
	*/
	function setBackgroundTextStyle(opts) {
		return invokeAPI("setBackgroundTextStyle", opts);
	}
	/**
	* 动态设置窗口的背景色
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/background/wx.setBackgroundColor.html
	*/
	function setBackgroundColor(opts) {
		return invokeAPI("setBackgroundColor", opts);
	}
	//#endregion
	//#region src/api/core/ui/canvas/index.js
	var canvas_exports = /* @__PURE__ */ __exportAll({
		canvasToTempFilePath: () => canvasToTempFilePath,
		createCanvasContext: () => createCanvasContext,
		createContext: () => createContext,
		createOffscreenCanvas: () => createOffscreenCanvas,
		drawCanvas: () => drawCanvas
	});
	/**
	* 创建绘图上下文
	* 兼容旧版 wx.createContext。
	*/
	function createContext() {
		return new CanvasContext();
	}
	/**
	* 创建 canvas 的绘图上下文
	* https://developers.weixin.qq.com/miniprogram/dev/api/canvas/wx.createCanvasContext.html
	*/
	function createCanvasContext(canvasId, component) {
		return new CanvasContext(canvasId, resolveModuleId(component));
	}
	/**
	* 兼容旧版 wx.drawCanvas。
	*/
	function drawCanvas(opts = {}) {
		const params = {
			...opts,
			moduleId: opts.moduleId || resolveModuleId(opts.component)
		};
		delete params.component;
		invokeAPI("drawCanvas", params, "render");
	}
	/**
	* https://developers.weixin.qq.com/miniprogram/dev/api/canvas/wx.canvasToTempFilePath.html
	*/
	function canvasToTempFilePath(opts = {}, component) {
		const params = {
			...opts,
			moduleId: opts.moduleId || resolveModuleId(component || opts.component)
		};
		delete params.component;
		return invokeAPI("canvasToTempFilePath", params, "render");
	}
	function resolveModuleId(component) {
		return component?.__id__ || router_default.getPageInfo()?.id;
	}
	var CanvasContext = class {
		constructor(canvasId = "", moduleId = null) {
			this.canvasId = canvasId;
			this.moduleId = moduleId;
			this.actions = [];
		}
		pushAction(type, ...args) {
			this.actions.push({
				type,
				args
			});
			return this;
		}
		getActions() {
			return this.actions.slice();
		}
		draw(reserve = false, callback) {
			if (!this.canvasId) return;
			drawCanvas({
				canvasId: this.canvasId,
				moduleId: this.moduleId,
				actions: this.getActions(),
				reserve,
				success: callback
			});
			this.actions = [];
		}
		beginPath() {
			return this.pushAction("beginPath");
		}
		closePath() {
			return this.pushAction("closePath");
		}
		moveTo(x, y) {
			return this.pushAction("moveTo", x, y);
		}
		lineTo(x, y) {
			return this.pushAction("lineTo", x, y);
		}
		rect(x, y, width, height) {
			return this.pushAction("rect", x, y, width, height);
		}
		arc(x, y, radius, startAngle, endAngle, counterclockwise = false) {
			return this.pushAction("arc", x, y, radius, startAngle, endAngle, counterclockwise);
		}
		quadraticCurveTo(cpx, cpy, x, y) {
			return this.pushAction("quadraticCurveTo", cpx, cpy, x, y);
		}
		bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
			return this.pushAction("bezierCurveTo", cp1x, cp1y, cp2x, cp2y, x, y);
		}
		fill() {
			return this.pushAction("fill");
		}
		stroke() {
			return this.pushAction("stroke");
		}
		clearRect(x, y, width, height) {
			return this.pushAction("clearRect", x, y, width, height);
		}
		fillText(text, x, y, maxWidth) {
			return this.pushAction("fillText", text, x, y, maxWidth);
		}
		drawImage(src, ...rest) {
			return this.pushAction("drawImage", src, ...rest);
		}
		save() {
			return this.pushAction("save");
		}
		restore() {
			return this.pushAction("restore");
		}
		translate(x, y) {
			return this.pushAction("translate", x, y);
		}
		rotate(angle) {
			return this.pushAction("rotate", angle);
		}
		scale(x, y) {
			return this.pushAction("scale", x, y);
		}
		setShadow(offsetX, offsetY, blur, color) {
			return this.pushAction("setShadow", offsetX, offsetY, blur, color);
		}
		setFillStyle(value) {
			return this.pushAction("setFillStyle", value);
		}
		setStrokeStyle(value) {
			return this.pushAction("setStrokeStyle", value);
		}
		setGlobalAlpha(value) {
			return this.pushAction("setGlobalAlpha", value);
		}
		setLineCap(value) {
			return this.pushAction("setLineCap", value);
		}
		setLineJoin(value) {
			return this.pushAction("setLineJoin", value);
		}
		setLineWidth(value) {
			return this.pushAction("setLineWidth", value);
		}
		setMiterLimit(value) {
			return this.pushAction("setMiterLimit", value);
		}
		setFontSize(value) {
			return this.pushAction("setFontSize", value);
		}
	};
	//#endregion
	//#region src/api/core/ui/custom-component/index.js
	var custom_component_exports = /* @__PURE__ */ __exportAll({ nextTick: () => nextTick });
	var nextTickCallbackList = [];
	var nextTickTimer = null;
	function callNextTick() {
		const cbs = nextTickCallbackList;
		nextTickCallbackList = [];
		nextTickTimer = null;
		for (let i = 0; i < cbs.length; i++) cbs[i]();
	}
	/**
	* 延迟一部分操作到下一个时间片再执行
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/custom-component/wx.nextTick.html
	*/
	function nextTick(callback) {
		if (isFunction(callback)) {
			nextTickCallbackList.push(callback);
			if (!nextTickTimer) nextTickTimer = setTimeout(callNextTick, 0);
		}
	}
	//#endregion
	//#region src/api/core/ui/interaction/index.js
	var interaction_exports = /* @__PURE__ */ __exportAll({
		disableAlertBeforeUnload: () => disableAlertBeforeUnload,
		enableAlertBeforeUnload: () => enableAlertBeforeUnload,
		hideLoading: () => hideLoading,
		hideToast: () => hideToast,
		showActionSheet: () => showActionSheet,
		showLoading: () => showLoading,
		showModal: () => showModal,
		showToast: () => showToast
	});
	/**
	* 显示消息提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showToast.html
	*/
	function showToast(opts) {
		return invokeAPI("showToast", opts);
	}
	/**
	* 隐藏消息提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.hideToast.html
	*/
	function hideToast(opts) {
		return invokeAPI("hideToast", opts);
	}
	/**
	* 显示模态对话框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showModal.html
	*/
	function showModal(opts) {
		return invokeAPI("showModal", opts);
	}
	/**
	* 显示 loading 提示框。需主动调用 wx.hideLoading 才能关闭提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showLoading.html
	*/
	function showLoading(opts) {
		return invokeAPI("showLoading", opts);
	}
	/**
	* 显示操作菜单
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.showActionSheet.html
	*/
	function showActionSheet(opts) {
		return invokeAPI("showActionSheet", opts);
	}
	/**
	* 隐藏 loading 提示框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.hideLoading.html
	*/
	function hideLoading(opts) {
		return invokeAPI("hideLoading", opts);
	}
	/**
	* 开启小程序页面返回询问对话框
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/interaction/wx.enableAlertBeforeUnload.html
	*/
	function enableAlertBeforeUnload(opts) {
		return invokeAPI("enableAlertBeforeUnload", opts);
	}
	/**
	* 关闭小程序页面返回询问对话框
	*/
	function disableAlertBeforeUnload(opts) {
		return invokeAPI("disableAlertBeforeUnload", opts);
	}
	//#endregion
	//#region src/api/core/ui/menu/index.js
	var menu_exports = /* @__PURE__ */ __exportAll({
		getMenuButtonBoundingClientRect: () => getMenuButtonBoundingClientRect,
		offMenuButtonBoundingClientRectWeightChange: () => offMenuButtonBoundingClientRectWeightChange,
		onMenuButtonBoundingClientRectWeightChange: () => onMenuButtonBoundingClientRectWeightChange
	});
	var menuRectChangeCallbacks = /* @__PURE__ */ new Set();
	host_env_default.onUpdate((patch) => {
		if (!patch.menuRect) return;
		menuRectChangeCallbacks.forEach((callback) => callback(patch.menuRect));
	});
	/**
	* 获取菜单按钮（右上角胶囊按钮）的布局位置信息。坐标信息以屏幕左上角为原点。
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/menu/wx.getMenuButtonBoundingClientRect.html
	*/
	function getMenuButtonBoundingClientRect() {
		return invokeAPI("getMenuButtonBoundingClientRect");
	}
	function onMenuButtonBoundingClientRectWeightChange(callback) {
		if (isFunction(callback)) menuRectChangeCallbacks.add(callback);
	}
	function offMenuButtonBoundingClientRectWeightChange(callback) {
		if (isFunction(callback)) menuRectChangeCallbacks.delete(callback);
		else menuRectChangeCallbacks.clear();
	}
	//#endregion
	//#region src/api/core/ui/navigation-bar/index.js
	var navigation_bar_exports = /* @__PURE__ */ __exportAll({
		hideHomeButton: () => hideHomeButton,
		hideNavigationBarLoading: () => hideNavigationBarLoading,
		setNavigationBarColor: () => setNavigationBarColor,
		setNavigationBarTitle: () => setNavigationBarTitle,
		showNavigationBarLoading: () => showNavigationBarLoading
	});
	/**
	* 在当前页面显示导航条加载动画
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.showNavigationBarLoading.html
	*/
	function showNavigationBarLoading(opts) {
		return invokeAPI("showNavigationBarLoading", opts);
	}
	/**
	* 动态设置当前页面的标题
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.setNavigationBarTitle.html
	*/
	function setNavigationBarTitle(opts) {
		return invokeAPI("setNavigationBarTitle", opts);
	}
	/**
	* 设置页面导航条颜色
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.setNavigationBarColor.html
	*/
	function setNavigationBarColor(opts) {
		return invokeAPI("setNavigationBarColor", opts);
	}
	/**
	* 在当前页面隐藏导航条加载动画
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.hideNavigationBarLoading.html
	*/
	function hideNavigationBarLoading(opts) {
		return invokeAPI("hideNavigationBarLoading", opts);
	}
	/**
	* 隐藏当前页面导航条左侧的返回首页按钮
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/navigation-bar/wx.hideHomeButton.html
	*/
	function hideHomeButton(opts) {
		return invokeAPI("hideHomeButton", opts);
	}
	//#endregion
	//#region src/api/core/ui/pull-down-refresh/index.js
	var pull_down_refresh_exports = /* @__PURE__ */ __exportAll({
		startPullDownRefresh: () => startPullDownRefresh,
		stopPullDownRefresh: () => stopPullDownRefresh
	});
	/**
	* 停止当前页面下拉刷新
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/pull-down-refresh/wx.stopPullDownRefresh.html
	*/
	function stopPullDownRefresh(opts) {
		return invokeAPI("stopPullDownRefresh", opts);
	}
	/**
	*	开始下拉刷新。调用后触发下拉刷新动画，效果与用户手动下拉刷新一致
	*	https://developers.weixin.qq.com/miniprogram/dev/api/ui/pull-down-refresh/wx.startPullDownRefresh.html
	*/
	function startPullDownRefresh(opts) {
		return invokeAPI("startPullDownRefresh", opts);
	}
	//#endregion
	//#region src/api/core/ui/scroll/index.js
	var scroll_exports = /* @__PURE__ */ __exportAll({ pageScrollTo: () => pageScrollTo });
	/**
	* 界面 / 滚动 / wx.pageScrollTo
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/scroll/wx.pageScrollTo.html
	*/
	function pageScrollTo(opts) {
		return invokeAPI("pageScrollTo", opts);
	}
	//#endregion
	//#region src/api/core/ui/tab-bar/index.js
	var tab_bar_exports = /* @__PURE__ */ __exportAll({
		hideTabBar: () => hideTabBar,
		hideTabBarRedDot: () => hideTabBarRedDot,
		removeTabBarBadge: () => removeTabBarBadge,
		setTabBarBadge: () => setTabBarBadge,
		setTabBarItem: () => setTabBarItem,
		setTabBarStyle: () => setTabBarStyle,
		showTabBar: () => showTabBar,
		showTabBarRedDot: () => showTabBarRedDot
	});
	/**
	* 动态设置 tabBar 整体样式
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarStyle.html
	*/
	function setTabBarStyle(opts) {
		return invokeAPI("setTabBarStyle", opts);
	}
	/**
	* 动态设置 tabBar 某一项的内容
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarItem.html
	*/
	function setTabBarItem(opts) {
		return invokeAPI("setTabBarItem", opts);
	}
	/**
	* 显示 tabBar
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.showTabBar.html
	*/
	function showTabBar(opts) {
		return invokeAPI("showTabBar", opts);
	}
	/**
	* 隐藏 tabBar
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.hideTabBar.html
	*/
	function hideTabBar(opts) {
		return invokeAPI("hideTabBar", opts);
	}
	/**
	* 为 tabBar 某一项的右上角添加文本
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.setTabBarBadge.html
	*/
	function setTabBarBadge(opts) {
		return invokeAPI("setTabBarBadge", opts);
	}
	/**
	* 移除 tabBar 某一项右上角的文本
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.removeTabBarBadge.html
	*/
	function removeTabBarBadge(opts) {
		return invokeAPI("removeTabBarBadge", opts);
	}
	/**
	* 显示 tabBar 某一项右上角的红点
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.showTabBarRedDot.html
	*/
	function showTabBarRedDot(opts) {
		return invokeAPI("showTabBarRedDot", opts);
	}
	/**
	* 隐藏 tabBar 某一项右上角的红点
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/tab-bar/wx.hideTabBarRedDot.html
	*/
	function hideTabBarRedDot(opts) {
		return invokeAPI("hideTabBarRedDot", opts);
	}
	//#endregion
	//#region src/api/core/ui/window/index.js
	var window_exports = /* @__PURE__ */ __exportAll({ onWindowResize: () => onWindowResize });
	/**
	* 监听窗口尺寸变化事件
	* https://developers.weixin.qq.com/miniprogram/dev/api/ui/window/wx.onWindowResize.html
	*/
	function onWindowResize(listener) {
		if (listener) invokeAPI("onWindowResize", { success: listener });
	}
	//#endregion
	//#region src/api/index.js
	var apiInfo = /* #__PURE__ */ Object.assign({
		"./core/base/app-event/index.js": app_event_exports,
		"./core/base/index.js": base_exports,
		"./core/base/performance/index.js": performance_exports,
		"./core/base/subpackage/index.js": subpackage_exports,
		"./core/base/system/index.js": system_exports,
		"./core/base/update/index.js": update_exports,
		"./core/camera/index.js": camera_exports,
		"./core/data-analysis/index.js": data_analysis_exports,
		"./core/device/bluetooth/index.js": bluetooth_exports,
		"./core/device/bluetooth-ble/index.js": bluetooth_ble_exports,
		"./core/device/clipboard/index.js": clipboard_exports,
		"./core/device/contact/index.js": contact_exports,
		"./core/device/keyboard/index.js": keyboard_exports,
		"./core/device/memory/index.js": memory_exports,
		"./core/device/network/index.js": network_exports,
		"./core/device/phone/index.js": phone_exports,
		"./core/device/scan/index.js": scan_exports,
		"./core/device/screen/index.js": screen_exports,
		"./core/device/vibrate/index.js": vibrate_exports,
		"./core/ext/index.js": ext_exports,
		"./core/file/index.js": file_exports,
		"./core/life-cycle/index.js": life_cycle_exports,
		"./core/location/index.js": location_exports,
		"./core/map/index.js": map_exports,
		"./core/media/image/index.js": image_exports,
		"./core/media/video/index.js": video_exports,
		"./core/navigate/index.js": navigate_exports,
		"./core/network/download/index.js": download_exports,
		"./core/network/mdns/index.js": mdns_exports,
		"./core/network/request/index.js": request_exports,
		"./core/network/tcp/index.js": tcp_exports,
		"./core/network/udp/index.js": udp_exports,
		"./core/network/upload/index.js": upload_exports,
		"./core/network/websocket/index.js": websocket_exports,
		"./core/open-api/account-info/index.js": account_info_exports,
		"./core/open-api/authorize/index.js": authorize_exports,
		"./core/open-api/index.js": open_api_exports,
		"./core/open-api/login/index.js": login_exports,
		"./core/open-api/privacy/index.js": privacy_exports,
		"./core/open-api/setting/index.js": setting_exports,
		"./core/open-api/user-info/index.js": user_info_exports,
		"./core/payment/index.js": payment_exports,
		"./core/route/index.js": route_exports,
		"./core/share/index.js": share_exports,
		"./core/storage/index.js": storage_exports,
		"./core/ui/animation/index.js": animation_exports,
		"./core/ui/background/index.js": background_exports,
		"./core/ui/canvas/index.js": canvas_exports,
		"./core/ui/custom-component/index.js": custom_component_exports,
		"./core/ui/interaction/index.js": interaction_exports,
		"./core/ui/menu/index.js": menu_exports,
		"./core/ui/navigation-bar/index.js": navigation_bar_exports,
		"./core/ui/pull-down-refresh/index.js": pull_down_refresh_exports,
		"./core/ui/scroll/index.js": scroll_exports,
		"./core/ui/tab-bar/index.js": tab_bar_exports,
		"./core/ui/window/index.js": window_exports,
		"./core/wxml/intersection-observer/index.js": intersection_observer_exports,
		"./core/wxml/media-query-observer/index.js": media_query_observer_exports,
		"./core/wxml/selector-query/index.js": selector_query_exports
	});
	var api = {};
	for (const f of Object.values(apiInfo)) for (const [k, v] of Object.entries(f)) api[k] = v;
	function registerEnumerableApiNames(names) {
		for (const name of names || []) {
			if (typeof name !== "string" || Object.prototype.hasOwnProperty.call(api, name) || name in Object.prototype) continue;
			Object.defineProperty(api, name, {
				value: (...args) => invokeAPI(name, ...args),
				writable: true,
				enumerable: true,
				configurable: true
			});
		}
	}
	/**
	* 外部挂载 API，内部转发不存在 API
	* [Render]invokeAPI -> [Container]invokeAPI -> [Service]invokeAPI -> [Container]invokeAPI
	*/
	var globalApi = new Proxy(api, {
		get(target, prop, receiver) {
			const origMethod = Reflect.get(target, prop, receiver);
			if (typeof origMethod === "function") return origMethod;
			if (origMethod !== void 0 || prop === "webpackJsonp") return origMethod;
			return (...args) => {
				return invokeAPI(prop, ...args);
			};
		},
		set(target, prop, value, receiver) {
			return Reflect.set(target, prop, value, receiver);
		}
	});
	//#endregion
	//#region src/core/env.js
	var Env = class {
		constructor() {
			this.init();
		}
		init() {
			let customNamespaces = globalThis.__diminaApiNamespaces || [];
			let registeredApis = globalThis.__diminaRegisteredApis || [];
			if (globalThis.name) try {
				const config = JSON.parse(globalThis.name);
				if (customNamespaces.length === 0) customNamespaces = config.apiNamespaces || [];
				if (registeredApis.length === 0) registeredApis = config.registeredApis || [];
			} catch (e) {}
			registerEnumerableApiNames(registeredApis);
			for (const name of [
				"dd",
				"wx",
				...customNamespaces
			]) globalThis[name] = globalApi;
			globalThis.modRequire = modRequire;
			globalThis.modDefine = modDefine;
			globalThis.global = {};
			/**
			* https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/app.html
			*/
			globalThis.App = (moduleInfo = {}) => {
				loader_default.createAppModule(moduleInfo);
				runtime_default.createApp();
			};
			globalThis.Page = (moduleInfo) => {
				loader_default.createModule(moduleInfo, globalThis.__extraInfo, PageModule.type);
			};
			globalThis.Component = (moduleInfo) => {
				loader_default.createModule(moduleInfo, globalThis.__extraInfo, ComponentModule.type);
			};
			/**
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/Behavior.html
			*/
			globalThis.Behavior = (behaviorInfo) => {
				return behaviorInfo;
			};
			/**
			* 获取到小程序全局唯一的 App 实例
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/getApp.html
			*/
			globalThis.getApp = (options) => runtime_default.getApp(options);
			/**
			* 获取当前页面栈。数组中第一个元素为首页，最后一个元素为当前页面
			* https://developers.weixin.qq.com/miniprogram/dev/reference/api/getCurrentPages.html
			*/
			globalThis.getCurrentPages = () => router_default.stack();
		}
	};
	var env_default = new Env();
	//#endregion
	//#region src/index.js
	var actionMap = {
		navigateBack,
		navigateTo,
		reLaunch,
		redirectTo,
		switchTab
	};
	/**
	* 逻辑层消息通道
	*/
	var Service = class {
		constructor() {
			console.log("[service] init");
			this.env = env_default;
			this.message = message_default;
			this.init();
		}
		init() {
			this.message.on("loadResource", (msg) => {
				const { appId, bridgeId, pagePath, root = ".", baseUrl = "/", hostEnv: hostEnvSnapshot, query, resourceLoadId, scene } = msg;
				if (hostEnvSnapshot) host_env_default.init(hostEnvSnapshot);
				runtime_default.setAppLaunchOptions({
					scene,
					pagePath,
					query
				});
				loader_default.loadResource({
					appId,
					bridgeId,
					pagePath,
					root,
					baseUrl,
					resourceLoadId
				});
			});
			this.message.on("hostEnvUpdate", (patch) => {
				host_env_default.update(patch);
			});
			this.message.on("t", async (msg) => {
				const { bridgeId, moduleId, methodName, event, success } = msg;
				if (methodName === void 0) return;
				const data = await runtime_default.triggerEvent({
					bridgeId,
					moduleId,
					methodName,
					event
				});
				if (data !== void 0) this.message.send({
					type: "triggerCallback",
					target: "render",
					body: {
						bridgeId,
						moduleId,
						success,
						data
					}
				});
			});
			this.message.on("triggerCallback", (msg) => {
				const { id, args } = msg;
				callback_default.invoke(id, args);
			});
			this.message.on("componentInvokeAPI", (msg) => {
				const { apiName, bridgeId, callbacks = {}, params = {} } = msg;
				let successId;
				let failId;
				const sendToRender = (renderCallbackId, data) => {
					if (!renderCallbackId) return;
					this.message.send({
						type: "triggerCallback",
						target: "render",
						body: {
							bridgeId,
							data,
							success: renderCallbackId
						}
					});
				};
				if (callbacks.success) successId = callback_default.store((data) => sendToRender(callbacks.success, data));
				if (callbacks.fail) failId = callback_default.store((data) => sendToRender(callbacks.fail, data));
				const completeId = callback_default.store((data) => {
					sendToRender(callbacks.complete, data);
					callback_default.remove(successId);
					callback_default.remove(failId);
				});
				this.message.invoke({
					type: "invokeAPI",
					target: "container",
					body: {
						name: apiName,
						bridgeId,
						params: {
							...params,
							complete: completeId,
							fail: failId,
							success: successId
						}
					}
				});
			});
			this.message.on("resourceLoadFailed", ({ bridgeId, pagePath, errors = [] }) => {
				console.error(`[service] resourceLoadFailed: bridgeId: ${bridgeId}, pagePath: ${pagePath}, errors: ${errors.join("; ")}`);
			});
			this.onAppMsg();
			this.onModuleMsg();
		}
		onAppMsg() {
			this.message.on("resourceLoaded", (msg) => {
				const { bridgeId, pagePath, query, stackId } = msg;
				const module = loader_default.getModuleByPath(pagePath);
				if (!module) {
					console.error(`[service] resourceLoaded: module not found, pagePath: ${pagePath}`);
					return;
				}
				const initialProps = loader_default.getPropsByPath(module.usingComponents);
				const pageId = `page_${uuid()}`;
				const page = runtime_default.createInstance({
					bridgeId,
					moduleId: pageId,
					path: pagePath,
					query,
					stackId,
					deferInitialData: true
				});
				message_default.send({
					type: "firstRender",
					target: "render",
					body: {
						bridgeId,
						pageId,
						pagePath,
						initialProps,
						query
					}
				});
				page?.sendInitialData();
			});
			this.message.on("appShow", () => {
				runtime_default.appShow();
			});
			this.message.on("appHide", () => {
				runtime_default.appHide();
			});
			this.message.on("stackShow", ({ stackId }) => {
				runtime_default.stackShow(stackId);
			});
			this.message.on("stackHide", ({ stackId }) => {
				runtime_default.stackHide(stackId);
			});
		}
		/**
		* https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/page-life-cycle.html
		* https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
		*/
		onModuleMsg() {
			this.message.on("mC", (msg) => {
				runtime_default.createInstance(msg);
			});
			this.message.on("mA", (msg) => {
				runtime_default.moduleAttached(msg);
			});
			this.message.on("mR", (msg) => {
				runtime_default.moduleReady(msg);
			});
			this.message.on("mU", (msg) => {
				runtime_default.moduleUnmounted(msg);
			});
			this.message.on("pageUnload", (msg) => {
				runtime_default.pageUnload(msg);
			});
			this.message.on("pageShow", (msg) => {
				runtime_default.pageShow(msg);
			});
			this.message.on("pageReady", (msg) => {
				runtime_default.pageReady(msg);
			});
			this.message.on("pageHide", (msg) => {
				runtime_default.pageHide(msg);
			});
			this.message.on("pagePullDownRefresh", (msg) => {
				runtime_default.pagePullDownRefresh(msg);
			});
			this.message.on("pageReachBottom", (msg) => {
				runtime_default.pageReachBottom(msg);
			});
			this.message.on("pageShareAppMessage", (msg) => {
				const result = runtime_default.pageShareAppMessage(msg);
				if (msg?.success) this.message.send({
					type: "triggerCallback",
					target: "container",
					body: {
						bridgeId: msg.bridgeId,
						id: msg.success,
						args: [result],
						data: result
					}
				});
			});
			this.message.on("pageScroll", (msg) => {
				runtime_default.pageScroll(msg);
			});
			this.message.on("pageResize", (msg) => {
				runtime_default.pageResize(msg);
			});
			this.message.on("onTabItemTap", (msg) => {
				runtime_default.pageTabItemTap(msg);
			});
			this.message.on("pageRouteDone", (msg) => {
				const { bridgeId } = msg;
				runtime_default.componentRouteDone({ bridgeId });
			});
			this.message.on("componentError", (msg) => {
				runtime_default.componentError(msg);
			});
			this.message.on("h5SdkAction", async (msg = {}) => {
				const actionName = msg?.name?.replace(/h5/i, "");
				const { url } = msg?.params?.data?.params || {};
				msg.params && (msg.params.data = {
					...msg.params?.data,
					...msg.params?.data?.params || {}
				});
				if (actionName === "postMessage" && msg.parentWebViewId) {
					const { moduleId, attrs, params } = msg;
					const event = { detail: { data: [params?.data?.params?.data] } };
					const methodName = attrs.message;
					const parentWebViewId = msg.parentWebViewId;
					const data = await runtime_default.triggerEvent({
						bridgeId: parentWebViewId,
						moduleId,
						methodName,
						event
					});
					if (data !== void 0) this.message.send({
						type: "triggerCallback",
						target: "service",
						body: {
							bridgeId: parentWebViewId,
							moduleId,
							success: params?.success,
							data
						}
					});
				}
				actionMap[actionName]?.({
					url,
					...msg.params
				});
			});
		}
	};
	//#endregion
	return new Service();
})();
